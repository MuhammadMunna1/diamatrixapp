#!/bin/sh
set -eu
APP_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$APP_DIR"
PORT="${PORT:-8080}"
# Export engine dependencies: install/update them on first run without requiring a manual step.
if [ ! -d node_modules/exceljs ] || [ ! -d node_modules/jspdf ]; then
  echo "Installing DiaMatrix Excel/PDF export dependencies..."
  npm install --no-audit --no-fund
fi
node server/tools/preview.mjs stop >/dev/null 2>&1 || true
if curl -sf -o /dev/null --max-time 2 "http://127.0.0.1:${PORT}/"; then
  echo "DiaMatrix is already running on port ${PORT}."
  exit 0
fi
nohup npm run dev -- --port "$PORT" >"${TMPDIR:-/tmp}/diamatrix-app.log" 2>&1 &
echo $! >"${TMPDIR:-/tmp}/diamatrix-app.pid"
sleep 1
if curl -sf -o /dev/null --max-time 3 "http://127.0.0.1:${PORT}/"; then
  echo "DiaMatrix started: http://0.0.0.0:${PORT}/"
  exit 0
fi
echo "DiaMatrix failed to start. Check ${TMPDIR:-/tmp}/diamatrix-app.log" >&2
exit 1
