# DiaMatrix — Diamond Blue palette (diamond-blue-v3)

Matched to the Operations Cockpit design reference.

- Diamond cyan (primary) `#14B4E8`, bright cyan `#3AC6FF`
- Deep navy `#0B2545` / `#09203F`
- Ice page bg `#F6FAFD`, border `#D3E8F6`, muted text `#4F6B88`

Logo: DW swirl + diamond (public/diamatrix-mark.svg, diamatrix-wordmark.svg, favicon/icon PNGs), used on the
"Securing session…" splash, login, header, sidebar and About. Default theme: light (Diamond Light).
