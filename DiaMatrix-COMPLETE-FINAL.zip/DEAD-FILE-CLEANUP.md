# DiaMatrix Dead/Duplicate File Cleanup

This cleanup was performed against the current Configuration & Security Hardening project baseline.

## Removed dead source files
- `src/client/lumina/components/DataImportModal.tsx` — no source import/reference found.
- `src/client/lumina/components/SpaceshipRing3D.tsx` — no source import/reference found.
- `src/client/lumina/utils/supabaseClient.ts` — no source import/reference found; the active app-data/auth path uses the current server/runtime configuration instead.
- `src/client/lib/multiplayer/index.ts` and `src/client/lib/multiplayer/p2p.ts` — no application import/reference found.

## Removed duplicate/unreferenced assets
- Duplicate `public/lumina-favicon.png` / `public/lumina-logo-icon.png` pair (identical SHA-256 content) — neither was referenced by the application.
- Unreferenced legacy Lumina/branding image variants that had no source/CSS reference.
- Unreferenced sample CSV/XLSX files that had no application link; the actively linked sample workbooks remain.

## Preserved
- All actively referenced DiaMatrix logos/assets.
- `public/lumina-login-reveal-poster.jpg` and `public/lumina-login-reveal.mp4`, which are referenced by the application.
- The four actively linked sample workbooks used by the upload UI.
- All source files referenced by the application, route tree, security middleware, auth, reports, filters, execution-report exports, and print/export flows.

## Verification
- Searched source/server/script references before deletion.
- Checked for exact duplicate file content with SHA-256.
- Confirmed removed source filenames are no longer referenced by `src`, `server`, or `scripts`.
- Confirmed the archive does not contain `.env.local`, `.env`, or runtime `server/data/auth-users.json`.

This is a conservative cleanup: files without evidence of being dead were retained.
