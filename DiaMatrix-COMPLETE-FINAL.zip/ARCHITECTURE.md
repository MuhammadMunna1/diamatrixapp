# DiaMatrix Client / Server Architecture

## Boundary

DiaMatrix now has three explicit application layers:

- `src/client/` — React UI, browser hooks, client-side auth client, and Lumina report UI.
- `src/shared/` — dependency-free contracts/constants safe for both sides.
- `src/server/` — database, Better Auth server, server functions, runtime configuration, and server-only connector access.

Deployment adapters remain under the root `server/` directory because Nitro auto-registers that directory. They are server infrastructure, not UI code.

Database migrations live under `server/migrations/`. The `auth/` subfolder is intentionally outside the active top-level migration glob so auth schema remains opt-in.

## Rules

1. `src/client/**` must never import `src/server/**`, Node-only modules, `pg`, PGlite, or Better Auth server APIs.
2. `src/server/**` owns secrets, database connections, authentication internals, and server-only environment variables.
3. `src/shared/**` must remain browser-safe and dependency-light.
4. `server/**` is deployment/runtime infrastructure only.
5. Run `npm run check:architecture` after structural changes.
6. Run `npm run typecheck` and `npm run build` before production deployment.
