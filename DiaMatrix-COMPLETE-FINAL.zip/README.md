# DiaMatrix

## Standard application structure

DiaMatrix follows a conventional TanStack Start / Vite application layout. Runtime application code is separated from deployment scripts, server code, and public assets.

```text
.
├── src/                 # application source (client, shared, routes, server adapters)
├── server/              # server-only runtime, middleware, data, migrations
│   ├── data/            # runtime/template data only
│   ├── middleware/      # server middleware
│   ├── migrations/      # database migrations
│   └── tools/           # build, checks, migration and maintenance tooling
├── public/              # static browser assets
├── package.json         # package manifest
├── vite.config.ts       # Vite configuration
├── vercel.json          # deployment configuration
└── startup.sh           # platform-required workspace startup entrypoint
```

`startup.sh` intentionally remains at the repository root because the development/runtime platform invokes `/workspace/startup.sh` directly. It is not application source code.

Secrets and runtime authentication state are never committed. Use `.env.example` and `server/data/auth-users.example.json` only as templates.
