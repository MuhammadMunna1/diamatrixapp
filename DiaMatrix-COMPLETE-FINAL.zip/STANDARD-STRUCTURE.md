# Standard Structure Audit

The project has been normalized around a conventional Vite/TanStack Start layout.

- `src/` is the application source boundary.
- `server/` owns server-only middleware, database migrations and server data/templates.
- `public/` owns static browser assets.
- `server/tools/` owns operational tooling and checks.
- Root files are limited to package/build/deployment configuration and platform-required metadata.
- `startup.sh` is intentionally root-level because the hosting workspace requires the fixed `/workspace/startup.sh` entrypoint.
- Runtime auth data belongs under `server/data/` and is ignored by Git.

This removes the previous standalone root `data/` bucket and avoids mixing runtime data with application source.
