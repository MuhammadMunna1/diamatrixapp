import React, { useState, useMemo, useRef, useEffect } from 'react';
import { RedistributionReport, AllocationMode } from '../types';
import {
  FileSpreadsheet,
  Download,
  Filter,
  Search,
  CheckCircle2,
  TableProperties,
  ArrowRight,
  TrendingUp,
  Package,
  PackagePlus
} from 'lucide-react';
import { RefillDemandReport } from './RefillDemandReport';
import { getReportDimension } from '../utils/reportDimension';
import {
  getBranchDisplayName,
  isOnlineBranch,
  isExcludedOutlet,
  isWarehouseBranchCode,
} from '../utils/dataIdentityEngine';
import {
  exportStyledExcelReport,
  exportAoaStyledExcel,
  exportStyledRowsExcel,
  exportDistributionNowExcel,
  distributionModeLabel,
  exportReportPdf,
  printExecutionReport,
} from '../utils/styledReportExport';

interface ExcelReportSheetViewProps {
  report: RedistributionReport;
  allocationMode: AllocationMode;
  onAllocationModeChange: (mode: AllocationMode) => void;
  onSelectBranch?: (branch: string) => void;
  onSelectWeight?: (weight: string) => void;
}

export const ExcelReportSheetView: React.FC<ExcelReportSheetViewProps> = ({
  report,
  allocationMode,
  onAllocationModeChange,
  onSelectBranch,
  onSelectWeight
}) => {
  const [activeSheetTab, setActiveSheetTab] = useState<'report_breakdown' | 'refill_demand' | 'matrix' | 'branch_summary' | 'transfer_orders' | 'unmet_demand'>('report_breakdown');
  const [searchTerm, setSearchTerm] = useState('');
  const [showOnlyWithAction, setShowOnlyWithAction] = useState(false);
  /** Branch-wise (default) vs Item/Product-wise allocation matrix */
  const [matrixViewMode, setMatrixViewMode] = useState<'branch' | 'item'>('branch');

  // Retail outlets only — DWL stock-only; Online / FAIR / BAC excluded
  const branches = report.matrix.branches.filter(
    (b) =>
      !isWarehouseBranchCode(b) &&
      !isOnlineBranch(b) &&
      !isExcludedOutlet(b) &&
      b !== 'WHL',
  );
  const hasDesignBreakdown = report.matrix.weights.some((w) => String(w).includes(' · '));
  /** Split composite key "0.05 · NP7SD1" → design first, carat beside it */
  const splitItemKey = (key: string): { carat: string; design: string } => {
    const parts = String(key || '').split(' · ');
    if (parts.length >= 2) {
      return { carat: parts[0].trim(), design: parts.slice(1).join(' · ').trim() };
    }
    return { carat: String(key || '').trim(), design: '' };
  };
  const itemLabel = hasDesignBreakdown
    ? 'Design Name'
    : report.categoryConfig?.itemLabel || 'Item / Particular';
  const itemUnit = report.categoryConfig?.itemUnit || 'units';
  const reportDimension = getReportDimension(report);
  const dimensionLabel = reportDimension.label;

  const weights = report.matrix.weights.filter(w => {
    const ws = report.weightSummaries.find(s => s.weight === w);
    if (!ws) return false;
    if (showOnlyWithAction) {
      return ws.moveInNeeded > 0 || ws.moveOutNeeded > 0 || ws.unmetShortage > 0;
    }
    return ws.soldQty > 0 || ws.currentStock > 0;
  });

  // Virtualize the large allocation matrix without changing the underlying data.
  const matrixViewportRef = useRef<HTMLDivElement | null>(null);
  const [matrixScrollTop, setMatrixScrollTop] = useState(0);
  const MATRIX_ROW_HEIGHT = 38;
  const MATRIX_VIEWPORT_HEIGHT = 550;
  const MATRIX_OVERSCAN = 8;
  const virtualWindow = useMemo(() => {
    const start = Math.max(0, Math.floor(matrixScrollTop / MATRIX_ROW_HEIGHT) - MATRIX_OVERSCAN);
    const visibleCount = Math.ceil(MATRIX_VIEWPORT_HEIGHT / MATRIX_ROW_HEIGHT) + MATRIX_OVERSCAN * 2;
    const end = Math.min(weights.length, start + visibleCount);
    return { start, end, items: weights.slice(start, end) };
  }, [weights, matrixScrollTop]);

  useEffect(() => {
    setMatrixScrollTop(0);
    matrixViewportRef.current?.scrollTo({ top: 0 });
  }, [weights.length, matrixViewMode]);

  /** Software-format coloured Excel (borders, green/red moves, wrap) */
  const handleExportFullExcelWorkbook = () => {
    exportStyledExcelReport(
      report,
      report.period || 'Current period',
      allocationMode
    );
  };

  const handleExportPdfFromMatrix = () => {
    exportReportPdf(
      report,
      report.period || 'Current period',
      allocationMode
    );
  };

  // Export Sales-Driven Distribution: Diamond Solitaire Earrings side-by-side branch comparison matrix
  const handlePrintExecutionReport = () => {
    printExecutionReport(report, allocationMode);
  };

  const handleExportDistributionNow = () => {
    exportDistributionNowExcel(report, allocationMode).catch((error) => {
      console.error(error);
      window.alert(`Excel export failed: ${error instanceof Error ? error.message : 'Please try again.'}`);
    });
  };

  const handleExportSalesDrivenDistributionMatrix = () => {
    // Build plain rows only; all styling (gridlines, Move IN / Overstock fills,
    // logo + date-range header) is done by the shared styledReportExport engine.
    const targetBranches = branches.length > 0 ? branches : [
      'Bashundhara City', 'Baily Road', 'Baitul Mukarram', 'Bogura', 'Barishal', 'Chuadanga', 'Chittagong #01'
    ];
    const targetCarats = weights.length > 0 ? weights : ['0.02','0.03','0.04','0.05','0.06','0.07','0.08','0.09','0.10','0.11','0.12'];
    const lead = hasDesignBreakdown ? 3 : 2;

    const row1: (string | number)[] = hasDesignBreakdown ? ['Design Name', dimensionLabel, 'DWL'] : [dimensionLabel === 'Amount' ? 'Amount' : 'Particulars Name', 'DWL'];
    targetBranches.forEach((b) => row1.push(getBranchDisplayName(b), '', '', '', ''));
    row1.push('Total Stock', 'Total Sold', 'Refill Demand');
    const row2: (string | number)[] = hasDesignBreakdown ? ['', '', 'Stock'] : ['', 'Stock'];
    targetBranches.forEach(() => row2.push('SOLD QTY', 'Current Stock', 'Average', 'Contribution %', 'Move IN/OUT'));
    row2.push('', '', '');

    const headerMerges: [number, number, number, number][] = [];
    let col = lead + 1;
    targetBranches.forEach(() => { headerMerges.push([1, col, 1, col + 4]); col += 5; });
    [0, 1, 2].forEach((i) => headerMerges.push([1, col + i, 2, col + i]));

    const rows: (string | number)[][] = targetCarats.map((carat) => {
      const dwlStock = Number(report.matrix.cells['DWL']?.[carat]?.stock || 0);
      const { carat: caratOnly, design } = splitItemKey(carat);
      const values: (string | number)[] = hasDesignBreakdown ? [design || '—', caratOnly, dwlStock] : [carat, dwlStock];
      let totalStock = dwlStock;
      let totalSold = 0;
      const soldForItem = targetBranches.reduce((acc, br) => acc + Number(report.matrix.cells[br]?.[carat]?.sold || 0), 0);
      targetBranches.forEach((b) => {
        const cell = report.matrix.cells[b]?.[carat];
        const sold = Number(cell?.sold || 0);
        const stock = Number(cell?.stock || 0);
        const avg = cell?.sales3M ? Math.round(Number(cell.sales3M) / 3) : Math.round(sold / 3);
        const contrib = soldForItem > 0 ? `${((sold / soldForItem) * 100).toFixed(1)}%` : '0%';
        totalStock += stock;
        totalSold += sold;
        values.push(sold, stock, avg, contrib, Number(cell?.netMove || 0));
      });
      const refill = Number(report.weightSummaries.find((w) => w.weight === carat)?.unmetShortage || (totalSold > totalStock ? totalSold - totalStock : 0));
      values.push(totalStock, totalSold, refill);
      return values;
    });

    const movementCols = targetBranches.map((_, bi) => lead + bi * 5 + 5);
    const branchGroups = targetBranches.map((_, bi) => ({ startCol: lead + bi * 5 + 1, span: 5 }));
    for (let c = 1; c <= lead - 1; c++) headerMerges.push([1, c, 2, c]);
    const refillCol = lead + targetBranches.length * 5 + 3;

    void exportStyledRowsExcel([{
      name: 'Distribution Matrix',
      title: `Sales-Driven Allocation Matrix — ${report.categoryConfig?.itemTypeNoun || 'Uploaded inventory'}`,
      period: report.period || undefined,
      modeLabel: distributionModeLabel(allocationMode),
      headerRows: [row1, row2],
      headerMerges,
      rows,
      movementCols,
      refillCols: [refillCol],
      branchGroups,
      freezeCols: lead,
      columnWidths: [22, 12, 12],
    }], 'Sales_Driven_Distribution_Report.xlsx').catch((error) => {
      console.error(error);
      window.alert('Excel export failed. Please try again.');
    });
  };

  return (
    <div className="space-y-4 dm-3d-report" data-dmx-report-print-root="true">
      
      {/* DWL Analytical Reports Header & Summary */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 sm:p-5 shadow-sm space-y-4">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-3 pb-3 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-slate-800 border border-slate-700 text-teal-400 flex items-center justify-center font-bold shadow-sm">
              <TableProperties className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-black text-slate-900 dark:text-white tracking-tight">
                  DWL Analytical Reports Hub
                </h2>
                <span className="text-[10px] px-2.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-teal-700 dark:text-teal-300 font-mono font-bold border border-slate-200 dark:border-slate-700 uppercase">
                  Enterprise
                </span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Comprehensive multi-outlet stock allocation matrix, transfer manifests, and procurement order sheets.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={handleExportFullExcelWorkbook}
              className="dmx-print-hide inline-flex items-center gap-2 px-3.5 py-2 text-xs font-bold rounded-lg bg-teal-700 hover:bg-teal-600 text-white transition-all shadow-sm active:scale-95 cursor-pointer"
              title="Coloured Excel — borders, green/red moves (opens in Excel / Sheets)"
            >
              <Download className="w-4 h-4" />
              <span>Export Excel (Styled)</span>
            </button>

            <button
              onClick={handleExportDistributionNow}
              className="dmx-print-hide inline-flex items-center gap-2 px-3.5 py-2 text-xs font-bold rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white transition-all shadow-sm active:scale-95 cursor-pointer"
              title="distribution_now.xlsx — one sheet per outlet"
            >
              <Download className="w-4 h-4" />
              <span>Outlet-wise (.XLSX)</span>
            </button>

            <button
              onClick={handleExportPdfFromMatrix}
              className="dmx-print-hide inline-flex items-center gap-2 px-3.5 py-2 text-xs font-bold rounded-lg bg-red-600 hover:bg-red-500 text-white transition-all shadow-sm active:scale-95 cursor-pointer"
              title="Print / Save as PDF"
            >
              <FileSpreadsheet className="w-4 h-4" />
              <span>Export PDF</span>
            </button>

            <button
              onClick={handlePrintExecutionReport}
              className="dmx-print-hide inline-flex items-center gap-2 px-3.5 py-2 text-xs font-bold rounded-lg bg-slate-700 hover:bg-slate-600 text-white transition-all shadow-sm active:scale-95 cursor-pointer"
              title="Print report — A4 Portrait"
            >
              <FileSpreadsheet className="w-4 h-4" />
              <span>Print A4</span>
            </button>
          </div>
        </div>

        <div className="rounded-lg border border-slate-200 bg-slate-50 p-2.5">
          <div className="mb-2 text-[10px] font-black uppercase tracking-wide text-slate-500">Matrix allocation criteria — select to rebuild the full report</div>
          <div className="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-3 gap-2">
            {([
              ['contribution', '① Sales Contribution', 'Full pool (DWL+branches) by sales share'],
              ['baseline', '② 3M Baseline', 'Average sales × 3 + scale factor'],
              ['hybrid', '③ Hybrid', 'Higher of contribution vs baseline'],
              ['liquidity', '④ Capital Liquidity', 'Sales ÷ aging; scale down if >90 days'],
              ['demand_backup', '⑤ Demand-Backup', '3M base + 20% HP bonus + stock-out safety'],
              ['coverage', '⑥ Universal Coverage', 'Every outlet ≥1 pc; rest by sales share'],
            ] as [AllocationMode, string, string][]).map(([mode, label, detail]) => (
              <button key={mode} onClick={() => onAllocationModeChange(mode)} className={`rounded-md border px-3 py-2 text-left ${allocationMode === mode ? 'border-teal-700 bg-teal-700 text-white' : 'border-slate-200 bg-white text-slate-700 hover:border-teal-400'}`}>
                <span className="block text-xs font-black">{label}</span><span className={`block mt-0.5 text-[10px] ${allocationMode === mode ? 'text-teal-100' : 'text-slate-500'}`}>{detail}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Quick Summary Ribbon (ERP Style) */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2 pt-1">
          <div className="p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/60">
            <span className="text-[10px] font-semibold text-slate-400 uppercase block">Total Stock</span>
            <span className="text-sm font-bold text-slate-800 dark:text-white">{report.totalCurrentStock} {itemUnit}</span>
          </div>
          <div className="p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/60">
            <span className="text-[10px] font-semibold text-slate-400 uppercase block">Sales Demand</span>
            <span className="text-sm font-bold text-teal-600 dark:text-teal-400">{report.totalSold} {itemUnit}</span>
          </div>
          <div className="p-2.5 rounded-lg bg-teal-50/50 dark:bg-teal-950/30 border border-teal-200/70 dark:border-teal-800/50">
            <span className="text-[10px] font-semibold text-teal-700 dark:text-teal-400 uppercase block">Deficit Move-In</span>
            <span className="text-sm font-bold text-teal-700 dark:text-teal-300">+{report.totalMoveIn} {itemUnit}</span>
          </div>
          <div className="p-2.5 rounded-lg bg-red-50/50 dark:bg-red-950/30 border border-red-200/70 dark:border-red-800/50">
            <span className="text-[10px] font-semibold text-red-700 dark:text-red-400 uppercase block">Surplus Move-Out</span>
            <span className="text-sm font-bold text-red-700 dark:text-red-300">-{report.totalMoveOut} {itemUnit}</span>
          </div>
          <div className="p-2.5 rounded-lg bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/60">
            <span className="text-[10px] font-semibold text-slate-400 uppercase block">Transfer Orders</span>
            <span className="text-sm font-bold text-indigo-600 dark:text-indigo-400">{report.transferOrders.length} routes</span>
          </div>
          <div className="p-2.5 rounded-lg bg-amber-50/50 dark:bg-amber-950/30 border border-amber-200/70 dark:border-amber-800/50">
            <span className="text-[10px] font-semibold text-amber-800 dark:text-amber-400 uppercase block">New Buy Needed</span>
            <span className="text-sm font-bold text-amber-700 dark:text-amber-300">{report.totalNewStockToBuy} {itemUnit}</span>
          </div>
        </div>

        {/* Excel Sheet Tabs (ERP Module Sheet Tabs) */}
        <div className="flex items-center justify-between gap-2 pt-2 flex-wrap">
          <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-lg text-xs overflow-x-auto max-w-full">
            <button
              onClick={() => setActiveSheetTab('report_breakdown')}
              className={`px-3 py-1.5 rounded-md font-bold transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                activeSheetTab === 'report_breakdown'
                  ? 'bg-amber-600 !text-white shadow-sm ring-1 ring-amber-400/40'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <TableProperties className="w-3.5 h-3.5" />
              <span>Sheet 1: Report Breakdown</span>
            </button>

            <button
              onClick={() => setActiveSheetTab('refill_demand')}
              className={`px-3 py-1.5 rounded-md font-bold transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                activeSheetTab === 'refill_demand'
                  ? 'bg-amber-600 !text-white shadow-sm ring-1 ring-amber-400/40'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <PackagePlus className="w-3.5 h-3.5" />
              <span>Sheet 2: Refill Demand ({report.totalNewStockToBuy} {itemUnit})</span>
            </button>

            <button
              onClick={() => setActiveSheetTab('matrix')}
              className={`px-3 py-1.5 rounded-md font-bold transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                activeSheetTab === 'matrix'
                  ? 'bg-teal-700 !text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              <span>Sheet 3: Allocation Matrix (Branch + Item)</span>
            </button>

            <button
              onClick={() => setActiveSheetTab('branch_summary')}
              className={`px-3 py-1.5 rounded-md font-bold transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                activeSheetTab === 'branch_summary'
                  ? 'bg-teal-700 !text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <span>Sheet 4: Branch 360 Summary</span>
            </button>

            <button
              onClick={() => setActiveSheetTab('transfer_orders')}
              className={`px-3 py-1.5 rounded-md font-bold transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                activeSheetTab === 'transfer_orders'
                  ? 'bg-teal-700 !text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <span>Sheet 5: Transfer Orders ({report.transferOrders.length})</span>
            </button>

            <button
              onClick={() => setActiveSheetTab('unmet_demand')}
              className={`px-3 py-1.5 rounded-md font-bold transition-all flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                activeSheetTab === 'unmet_demand'
                  ? 'bg-teal-700 !text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <span>Sheet 6: Demand &amp; Procurement</span>
            </button>
          </div>

          <div className="flex items-center gap-2 text-xs">
            <label className="flex items-center gap-1.5 text-slate-600 dark:text-slate-400 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={showOnlyWithAction}
                onChange={(e) => setShowOnlyWithAction(e.target.checked)}
                className="rounded text-emerald-600 focus:ring-emerald-500"
              />
              <span>Show only rows with action</span>
            </label>
          </div>
        </div>
      </div>

      {/* Sheet 1: Report Breakdown (Side-by-Side Multi-Branch Comparison Matrix) */}
      {activeSheetTab === 'report_breakdown' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-sm overflow-hidden space-y-3 p-4 sm:p-5">
          {/* Executive Title & Period Block (Matching Corporate Format) */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-3 border-b border-slate-200 dark:border-slate-800">
            <div>
              <div className="inline-block border-2 border-slate-800 dark:border-slate-600 bg-[#cfe2f3] dark:bg-slate-800/90 text-slate-900 dark:text-white px-3.5 py-1.5 rounded-sm font-black text-sm sm:text-base shadow-sm">
                Sales-Driven Allocation Matrix:{' '}
                <span className="font-extrabold text-slate-950 dark:text-teal-300">
                  {report.categoryConfig?.itemTypeNoun || 'Uploaded inventory'}
                </span>
              </div>
              <div className="text-xs font-bold font-mono text-slate-800 dark:text-slate-200 mt-1.5 flex items-center gap-2">
                <span className="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 border border-slate-300 dark:border-slate-700">
                  Active Period: {report.period || '—'}
                </span>
                <span className="text-[11px] text-slate-500 font-normal">
                  {hasDesignBreakdown
                    ? `Style breakdown active — Design Name first, ${dimensionLabel} beside (from uploaded style sheets)`
                    : `Category level — rows = ${dimensionLabel.toLowerCase()} only (upload style sheets for design breakdown)`}
                </span>
              </div>
            </div>

            <button
              onClick={handleExportSalesDrivenDistributionMatrix}
              className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-bold rounded-lg bg-blue-600 hover:bg-blue-700 text-white transition-all shadow-sm active:scale-95 cursor-pointer shrink-0"
              title="Download exact Excel matrix file (.xlsx)"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export Report Breakdown (.XLSX)</span>
            </button>
          </div>

          {/* Side-by-Side Horizontal Branch Matrix Table */}
          <div ref={matrixViewportRef} onScroll={(e) => setMatrixScrollTop(e.currentTarget.scrollTop)} className="overflow-auto border-2 border-slate-400 dark:border-slate-700 rounded-lg max-h-[640px] scrollbar-thin">
            <table className="w-full text-left text-sm border-collapse font-sans select-text font-bold">
              <thead className="sticky top-0 z-20 shadow-sm border-b-2 border-slate-700 dark:border-slate-500">
                {/* Row 4: Branch Grouping — dark bg + white bold text */}
                <tr className="bg-[#0B3D5C] dark:bg-[#0B3D5C] text-white text-center font-bold">
                  {hasDesignBreakdown ? (
                    <>
                      <th
                        rowSpan={2}
                        className="py-2.5 px-3 border border-slate-600 text-center font-black sticky left-0 bg-[#0B3D5C] text-white z-30 min-w-[110px] tracking-tight"
                      >
                        Design Name
                      </th>
                      <th
                        rowSpan={2}
                        className="py-2.5 px-2 border border-slate-600 text-center font-black sticky left-[110px] bg-[#0B3D5C] text-white z-30 min-w-[70px] tracking-tight"
                      >
                        {dimensionLabel}
                      </th>
                    </>
                  ) : (
                    <th
                      rowSpan={2}
                      className="py-2.5 px-3 border border-slate-600 text-center font-black sticky left-0 bg-[#0B3D5C] text-white z-30 min-w-[130px] tracking-tight"
                    >
                      {itemLabel}
                    </th>
                  )}
                  <th
                    className="py-2 px-3 border border-slate-600 text-center font-black text-sm bg-[#0B3D5C] text-white min-w-[65px]"
                  >
                    DWL
                  </th>
                  {(branches.length > 0 ? branches : ['Bashundhara', 'Baily-Road', 'Baitul Mukarram', 'Bogura', 'Barishal', 'Chuadanga', 'Chittagong - #01']).map((b) => (
                    <th
                      key={`grp-${b}`}
                      colSpan={5}
                      className="py-2 px-3 border-x-2 border-y border-slate-500 text-center font-black text-sm bg-[#0B3D5C] text-white tracking-tight"
                    >
                      {getBranchDisplayName(b)}
                    </th>
                  ))}
                  <th
                    rowSpan={2}
                    className="py-2 px-3 border border-slate-600 text-center font-bold italic bg-[#0B3D5C] text-white min-w-[85px]"
                  >
                    Total Stock
                  </th>
                  <th
                    rowSpan={2}
                    className="py-2 px-3 border border-slate-600 text-center font-bold italic bg-[#0B3D5C] text-white min-w-[85px]"
                  >
                    Total Sold
                  </th>
                  <th
                    rowSpan={2}
                    className="py-2 px-3 border border-amber-700 text-center font-bold italic bg-amber-700 text-white min-w-[95px]"
                  >
                    Refill Demand
                  </th>
                </tr>

                {/* Row 5: Metric Columns per Branch — sub-header, slightly lighter navy + white text */}
                <tr className="bg-[#134E6F] text-white text-xs font-bold text-center border-b-2 border-slate-600">
                  <th className="py-1.5 px-2 border border-slate-600">
                    Stock
                  </th>
                  {(branches.length > 0 ? branches : ['Bashundhara', 'Baily-Road', 'Baitul Mukarram', 'Bogura', 'Barishal', 'Chuadanga', 'Chittagong - #01']).map((b) => (
                    <React.Fragment key={`sub-${b}`}>
                      <th className="py-1.5 px-2 border border-slate-600 min-w-[65px]">
                        SOLD QTY
                      </th>
                      <th className="py-1.5 px-2 border border-slate-600 min-w-[70px]">
                        Current Stock
                      </th>
                      <th className="py-1.5 px-2 border border-slate-600 min-w-[55px]">
                        Average
                      </th>
                      <th className="py-1.5 px-2 border border-slate-600 min-w-[75px]">
                        Contribution %
                      </th>
                      <th className="py-1.5 px-2 border-r-2 border-l border-y border-slate-500 min-w-[75px] bg-[#0F766E] text-white">
                        Move IN/OUT
                      </th>
                    </React.Fragment>
                  ))}
                </tr>
              </thead>

              {/* Row 6+: Particulars Data Matrix */}
              <tbody className="divide-y divide-slate-300 dark:divide-slate-800 bg-white dark:bg-slate-900">
                {(weights.length > 0 ? weights : ['0.02', '0.03', '0.04', '0.05', '0.06', '0.07', '0.08', '0.09', '0.10', '0.11', '0.12']).map((carat) => {
                  const dwlStock = report.matrix.cells['DWL']?.[carat]?.stock || 0;
                  const currentBranches = branches.length > 0 ? branches : ['Bashundhara', 'Baily-Road', 'Baitul Mukarram', 'Bogura', 'Barishal', 'Chuadanga', 'Chittagong - #01'];

                  let rowTotalStock = dwlStock;
                  let rowTotalSold = 0;

                  const totalSoldForCarat = currentBranches.reduce(
                    (acc, br) => acc + (report.matrix.cells[br]?.[carat]?.sold || 0),
                    0
                  );

                  const { carat: caratOnly, design } = splitItemKey(carat);
                  return (
                    <tr key={carat} className="hover:bg-slate-50/90 dark:hover:bg-slate-800/60 transition-colors">
                      {/* Design Name first, Carat in separate column when style breakdown active */}
                      {hasDesignBreakdown ? (
                        <>
                          <td className="py-1.5 px-3 font-mono text-sm font-extrabold text-slate-900 dark:text-white sticky left-0 bg-white dark:bg-slate-900 z-10 border border-slate-300 dark:border-slate-700 text-center min-w-[110px]">
                            {design || '—'}
                          </td>
                          <td className="py-1.5 px-2 font-mono text-sm font-bold text-slate-800 dark:text-slate-200 sticky left-[110px] bg-white dark:bg-slate-900 z-10 border border-slate-300 dark:border-slate-700 text-center min-w-[70px]">
                            {caratOnly}
                          </td>
                        </>
                      ) : (
                        <td className="py-1.5 px-3 font-mono text-sm font-extrabold text-slate-900 dark:text-white sticky left-0 bg-white dark:bg-slate-900 z-10 border border-slate-300 dark:border-slate-700 text-center">
                          {carat}
                        </td>
                      )}

                      {/* DWL Stock */}
                      <td className="py-1.5 px-2 text-right font-mono text-sm border border-slate-300 dark:border-slate-700 font-bold text-slate-900 dark:text-white">
                        {dwlStock}
                      </td>

                      {/* 5 Distinct Metrics for each branch */}
                      {currentBranches.map((b) => {
                        const cell = report.matrix.cells[b]?.[carat];
                        const sold = cell?.sold || 0;
                        const stock = cell?.stock || 0;
                        const avg = cell?.sales3M ? Math.round(cell.sales3M / 3) : Math.round(sold / 3);
                        const contrib = totalSoldForCarat > 0 ? `${((sold / totalSoldForCarat) * 100).toFixed(0)}%` : '0%';
                        const move = cell?.netMove || 0;

                        rowTotalStock += stock;
                        rowTotalSold += sold;

                        return (
                          <React.Fragment key={`cell-${b}-${carat}`}>
                            <td className="py-1.5 px-2 text-right font-mono text-sm border border-slate-300 dark:border-slate-700 font-bold text-slate-900 dark:text-white">
                              {sold}
                            </td>
                            <td className="py-1.5 px-2 text-right font-mono text-sm border border-slate-300 dark:border-slate-700 font-bold text-slate-800 dark:text-slate-200">
                              {stock}
                            </td>
                            <td className="py-1.5 px-2 text-right font-mono text-sm border border-slate-300 dark:border-slate-700 font-bold text-slate-700 dark:text-slate-300">
                              {avg}
                            </td>
                            <td className="py-1.5 px-2 text-right font-mono text-sm border border-slate-300 dark:border-slate-700 font-bold text-slate-800 dark:text-slate-200">
                              {contrib}
                            </td>
                            <td
                              className={`py-1.5 px-2 text-right font-mono text-sm border-x-2 border-y border-slate-400 dark:border-slate-700 font-extrabold ${
                                move > 0
                                  ? 'bg-[#C6EFCE] text-[#006100] dark:bg-emerald-900/40 dark:text-emerald-300'
                                  : move < 0
                                  ? 'bg-[#FFC7CE] text-[#9C0006] dark:bg-red-900/40 dark:text-red-300'
                                  : 'text-slate-600 dark:text-slate-400 bg-white dark:bg-slate-900'
                              }`}
                            >
                              {move > 0 ? `+${move}` : move}
                            </td>
                          </React.Fragment>
                        );
                      })}

                      {/* Total Stock */}
                      <td className="py-1 px-3 text-right font-mono text-xs border border-slate-300 dark:border-slate-700 font-extrabold text-slate-900 dark:text-white bg-slate-50 dark:bg-slate-800/40">
                        {rowTotalStock}
                      </td>

                      {/* Total Sold */}
                      <td className="py-1 px-3 text-right font-mono text-xs border border-slate-300 dark:border-slate-700 font-extrabold text-blue-600 dark:text-blue-400 bg-slate-50 dark:bg-slate-800/40">
                        {rowTotalSold}
                      </td>

                      {/* Refill Demand */}
                      {(() => {
                        const refillQty = report.weightSummaries.find(w => w.weight === carat)?.unmetShortage || (rowTotalSold > rowTotalStock ? rowTotalSold - rowTotalStock : 0);
                        return (
                          <td className={`py-1 px-3 text-right font-mono text-xs border border-slate-300 dark:border-slate-700 font-black ${
                            refillQty > 0
                              ? 'bg-amber-100 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300'
                              : 'text-slate-400 dark:text-slate-600 bg-slate-50 dark:bg-slate-800/40'
                          }`}>
                            {refillQty > 0 ? `+${refillQty}` : '0'}
                          </td>
                        );
                      })()}
                    </tr>
                  );
                })}
              </tbody>

              {/* Total Row */}
              <tfoot className="bg-[#e7e6e6] dark:bg-slate-800 font-bold border-t-2 border-slate-400 dark:border-slate-600">
                <tr>
                  {hasDesignBreakdown ? (
                    <>
                      <td className="py-2 px-3 text-slate-900 dark:text-white font-black border border-slate-400 dark:border-slate-700 sticky left-0 bg-[#e7e6e6] dark:bg-slate-800 z-10 text-center" colSpan={2}>
                        Total
                      </td>
                    </>
                  ) : (
                    <td className="py-2 px-3 text-slate-900 dark:text-white font-black border border-slate-400 dark:border-slate-700 sticky left-0 bg-[#e7e6e6] dark:bg-slate-800 z-10 text-center">
                      Total
                    </td>
                  )}
                  <td className="py-2 px-2 text-right font-mono font-black border border-slate-400 dark:border-slate-700 text-slate-900 dark:text-white">
                    {(weights.length > 0 ? weights : ['0.02', '0.03', '0.04', '0.05', '0.06', '0.07', '0.08', '0.09', '0.10', '0.11', '0.12']).reduce(
                      (acc, c) => acc + (report.matrix.cells['DWL']?.[c]?.stock || 0),
                      0
                    )}
                  </td>
                  {(branches.length > 0 ? branches : ['Bashundhara', 'Baily-Road', 'Baitul Mukarram', 'Bogura', 'Barishal', 'Chuadanga', 'Chittagong - #01']).map((b) => {
                    const currentWeights = weights.length > 0 ? weights : ['0.02', '0.03', '0.04', '0.05', '0.06', '0.07', '0.08', '0.09', '0.10', '0.11', '0.12'];
                    const branchSold = currentWeights.reduce((acc, c) => acc + (report.matrix.cells[b]?.[c]?.sold || 0), 0);
                    const branchStock = currentWeights.reduce((acc, c) => acc + (report.matrix.cells[b]?.[c]?.stock || 0), 0);
                    const branchMove = currentWeights.reduce((acc, c) => acc + (report.matrix.cells[b]?.[c]?.netMove || 0), 0);

                    return (
                      <React.Fragment key={`foot-${b}`}>
                        <td className="py-2 px-2 text-right font-mono font-black border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white">
                          {branchSold}
                        </td>
                        <td className="py-2 px-2 text-right font-mono font-black border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white">
                          {branchStock}
                        </td>
                        <td className="py-2 px-2 text-right font-mono font-black border border-slate-300 dark:border-slate-700 text-slate-500">
                          -
                        </td>
                        <td className="py-2 px-2 text-right font-mono font-black border border-slate-300 dark:border-slate-700 text-slate-500">
                          -
                        </td>
                        <td className="py-2 px-2 text-right font-mono font-black border-x-2 border-y border-slate-400 dark:border-slate-600 bg-[#bfbfbf] dark:bg-slate-700 text-slate-900 dark:text-white">
                          {branchMove > 0 ? `+${branchMove}` : branchMove}
                        </td>
                      </React.Fragment>
                    );
                  })}
                  <td className="py-2 px-3 text-right font-mono font-black border border-slate-400 dark:border-slate-700 text-slate-900 dark:text-white">
                    {report.totalCurrentStock}
                  </td>
                  <td className="py-2 px-3 text-right font-mono font-black border border-slate-400 dark:border-slate-700 text-blue-600 dark:text-blue-400">
                    {report.totalSold}
                  </td>
                  <td className="py-2 px-3 text-right font-mono font-black border border-slate-400 dark:border-slate-700 bg-amber-200/60 dark:bg-amber-950/60 text-amber-800 dark:text-amber-300">
                    {report.totalNewStockToBuy}
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>
      )}

      {/* Sheet 2: Refill Demand & Outlet Stock Requisitions */}
      {activeSheetTab === 'refill_demand' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 sm:p-5 shadow-sm">
          <RefillDemandReport
            report={report}
            onSelectBranch={onSelectBranch}
            onSelectWeight={onSelectWeight}
          />
        </div>
      )}

      {/* Sheet 3: Matrix View — Branch-wise + Item/Product-wise */}
      {activeSheetTab === 'matrix' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-sm overflow-hidden">
          <div className="bg-slate-100 dark:bg-slate-800/80 px-4 py-2.5 border-b border-slate-200 dark:border-slate-700 flex flex-wrap items-center justify-between gap-2 text-xs">
            <span className="font-mono text-slate-700 dark:text-slate-300 font-semibold">
              Formula: [Sold &gt; Stock = Move IN] • [Stock &gt; Sold = Move OUT]
            </span>
            <div className="flex flex-wrap items-center gap-3">
              {/* View mode toggle: Branch-wise vs Item/Product-wise */}
              <div className="inline-flex rounded-lg border border-slate-300 dark:border-slate-600 overflow-hidden shadow-sm">
                <button
                  type="button"
                  onClick={() => setMatrixViewMode('branch')}
                  className={`px-3 py-1 text-[11px] font-bold transition-colors cursor-pointer ${
                    matrixViewMode === 'branch'
                      ? 'bg-teal-700 text-white'
                      : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700'
                  }`}
                >
                  Branch-wise
                </button>
                <button
                  type="button"
                  onClick={() => setMatrixViewMode('item')}
                  className={`px-3 py-1 text-[11px] font-bold transition-colors cursor-pointer border-l border-slate-300 dark:border-slate-600 ${
                    matrixViewMode === 'item'
                      ? 'bg-teal-700 text-white'
                      : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-700'
                  }`}
                >
                  Item / Product-wise
                </button>
              </div>
              <span className="flex items-center gap-1">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span> Move IN
              </span>
              <span className="flex items-center gap-1">
                <span className="w-2.5 h-2.5 rounded-full bg-red-500"></span> Move OUT
              </span>
            </div>
          </div>

          {matrixViewMode === 'branch' ? (
            /* ===== BRANCH-WISE MATRIX (items as rows, branches as columns) ===== */
            <div className="overflow-x-auto max-h-[550px]">
              <table className="w-full text-left text-xs border-collapse font-sans">
                <thead className="sticky top-0 bg-slate-200 dark:bg-slate-850 z-20 shadow-sm border-b border-slate-300 dark:border-slate-700">
                  <tr>
                    {hasDesignBreakdown ? (
                      <>
                        <th className="py-2 px-3 font-bold text-slate-900 dark:text-white sticky left-0 bg-slate-200 dark:bg-slate-850 z-30 border-r border-slate-300 dark:border-slate-700 min-w-[100px]">
                          Design Name
                        </th>
                        <th className="py-2 px-2 font-bold text-slate-900 dark:text-white sticky left-[100px] bg-slate-200 dark:bg-slate-850 z-30 border-r border-slate-300 dark:border-slate-700 min-w-[60px]">
                          {dimensionLabel}
                        </th>
                      </>
                    ) : (
                      <th className="py-2 px-3 font-bold text-slate-900 dark:text-white sticky left-0 bg-slate-200 dark:bg-slate-850 z-30 border-r border-slate-300 dark:border-slate-700 min-w-[130px]">
                        Particulars ({itemLabel})
                      </th>
                    )}
                    {branches.map(b => (
                      <th
                        key={b}
                        onClick={() => onSelectBranch && onSelectBranch(b)}
                        title={`Click to view Branch ${b} detailed report`}
                        className="py-2 px-2 font-semibold text-slate-800 dark:text-slate-300 text-center min-w-[80px] border-r border-slate-300 dark:border-slate-700 text-[10px] whitespace-nowrap cursor-pointer hover:bg-blue-500/20 hover:text-blue-300 transition-colors"
                      >
                        {b}
                      </th>
                    ))}
                    <th className="py-2 px-3 font-bold text-center bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 min-w-[70px]">
                      Move IN
                    </th>
                    <th className="py-2 px-3 font-bold text-center bg-red-100 dark:bg-red-950 text-red-800 dark:text-red-300 min-w-[75px]">
                      Move OUT
                    </th>
                    <th className="py-2 px-3 font-bold text-center bg-amber-100 dark:bg-amber-950 text-amber-900 dark:text-amber-300 min-w-[80px]">
                      New Buy
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {virtualWindow.start > 0 && (
                    <tr aria-hidden><td colSpan={branches.length + (hasDesignBreakdown ? 2 : 1) + 3} style={{ height: virtualWindow.start * MATRIX_ROW_HEIGHT, padding: 0, border: 0 }} /></tr>
                  )}
                  {virtualWindow.items.map(w => {
                    const ws = report.weightSummaries.find(s => s.weight === w);
                    const { carat: cOnly, design: dName } = splitItemKey(w);

                    return (
                      <tr key={w} className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40">
                        {hasDesignBreakdown ? (
                          <>
                            <td
                              onClick={() => onSelectWeight && onSelectWeight(w)}
                              title={`Click to view enterprise store availability for ${dName} ${cOnly}`}
                              className="py-1.5 px-3 font-mono font-bold text-slate-900 dark:text-white sticky left-0 bg-white dark:bg-slate-900 z-10 border-r border-slate-200 dark:border-slate-800 cursor-pointer hover:text-blue-400 hover:bg-blue-50/50 dark:hover:bg-blue-950/30 transition-colors min-w-[100px]"
                            >
                              {dName || '—'}
                            </td>
                            <td
                              onClick={() => onSelectWeight && onSelectWeight(w)}
                              className="py-1.5 px-2 font-mono font-semibold text-slate-700 dark:text-slate-300 sticky left-[100px] bg-white dark:bg-slate-900 z-10 border-r border-slate-200 dark:border-slate-800 cursor-pointer min-w-[60px] text-center"
                            >
                              {itemUnit === 'ct' ? `${cOnly} ct` : cOnly}
                            </td>
                          </>
                        ) : (
                          <td
                            onClick={() => onSelectWeight && onSelectWeight(w)}
                            title={`Click to view enterprise store availability for ${w} ct`}
                            className="py-1.5 px-3 font-mono font-bold text-slate-900 dark:text-white sticky left-0 bg-white dark:bg-slate-900 z-10 border-r border-slate-200 dark:border-slate-800 cursor-pointer hover:text-blue-400 hover:bg-blue-50/50 dark:hover:bg-blue-950/30 transition-colors"
                          >
                            {itemUnit === 'ct' ? `${w} ct` : w}
                          </td>
                        )}

                        {branches.map(b => {
                          const cell = report.matrix.cells[b]?.[w];
                          const netMove = cell ? cell.netMove : 0;

                          return (
                            <td
                              key={b}
                              className={`py-1 px-2 text-center font-mono font-bold text-xs border-r border-slate-100 dark:border-slate-800 ${
                                netMove > 0
                                  ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 font-extrabold'
                                  : netMove < 0
                                  ? 'bg-red-50 dark:bg-red-950/40 text-red-600 dark:text-red-400 font-extrabold'
                                  : 'text-slate-400/80'
                              }`}
                            >
                              {netMove > 0 ? `+${netMove}` : netMove < 0 ? `${netMove}` : '0'}
                            </td>
                          );
                        })}

                        <td className="py-1 px-3 text-center font-mono font-bold text-emerald-600 bg-emerald-50/50 dark:bg-emerald-950/20">
                          {ws?.moveInNeeded || 0}
                        </td>
                        <td className="py-1 px-3 text-center font-mono font-bold text-red-600 bg-red-50/50 dark:bg-red-950/20">
                          {ws?.moveOutNeeded || 0}
                        </td>
                        <td className="py-1 px-3 text-center font-mono font-bold text-amber-600 bg-amber-50/50 dark:bg-amber-950/20">
                          {ws?.unmetShortage || 0}
                        </td>
                      </tr>
                    );
                  })}
                  {virtualWindow.end < weights.length && (
                    <tr aria-hidden><td colSpan={branches.length + (hasDesignBreakdown ? 2 : 1) + 3} style={{ height: (weights.length - virtualWindow.end) * MATRIX_ROW_HEIGHT, padding: 0, border: 0 }} /></tr>
                  )}
                </tbody>
              </table>
            </div>
          ) : (
            /* ===== ITEM / PRODUCT-WISE ALLOCATION MATRIX =====
               Each product first, then every branch under it with Stock / Sold / Move In / Move Out / Net / Status */
            <div className="overflow-x-auto max-h-[550px]">
              <table className="w-full text-left text-xs border-collapse font-sans">
                <thead className="sticky top-0 bg-slate-200 dark:bg-slate-850 z-20 shadow-sm border-b border-slate-300 dark:border-slate-700">
                  <tr>
                    <th className="py-2 px-3 font-bold text-slate-900 dark:text-white sticky left-0 bg-slate-200 dark:bg-slate-850 z-30 border-r border-slate-300 dark:border-slate-700 min-w-[140px]">
                      Item / Product
                    </th>
                    <th className="py-2 px-3 font-bold text-slate-900 dark:text-white border-r border-slate-300 dark:border-slate-700 min-w-[110px]">
                      Branch
                    </th>
                    <th className="py-2 px-2 font-bold text-center text-slate-800 dark:text-slate-200 border-r border-slate-300 dark:border-slate-700 min-w-[70px]">
                      Stock
                    </th>
                    <th className="py-2 px-2 font-bold text-center text-slate-800 dark:text-slate-200 border-r border-slate-300 dark:border-slate-700 min-w-[70px]">
                      Sold
                    </th>
                    <th className="py-2 px-2 font-bold text-center bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-300 min-w-[70px]">
                      Move IN
                    </th>
                    <th className="py-2 px-2 font-bold text-center bg-red-100 dark:bg-red-950 text-red-800 dark:text-red-300 min-w-[75px]">
                      Move OUT
                    </th>
                    <th className="py-2 px-2 font-bold text-center text-slate-800 dark:text-slate-200 border-r border-slate-300 dark:border-slate-700 min-w-[65px]">
                      Net
                    </th>
                    <th className="py-2 px-3 font-bold text-center text-slate-800 dark:text-slate-200 min-w-[90px]">
                      Status
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {weights.map(w => {
                    const ws = report.weightSummaries.find(s => s.weight === w);
                    const { carat: cOnly, design: dName } = splitItemKey(w);
                    const itemDisplay = hasDesignBreakdown
                      ? `${dName || '—'} · ${itemUnit === 'ct' ? `${cOnly} ct` : cOnly}`
                      : itemUnit === 'ct' ? `${w} ct` : w;

                    // Collect branch rows for this item (optionally only those with action)
                    const branchRows = branches
                      .map(b => {
                        const cell = report.matrix.cells[b]?.[w];
                        if (!cell) return null;
                        const stock = cell.stock || 0;
                        const sold = cell.sold || 0;
                        const moveIn = cell.moveIn || 0;
                        const moveOut = cell.moveOut || 0;
                        const netMove = cell.netMove || 0;
                        if (showOnlyWithAction && moveIn === 0 && moveOut === 0 && netMove === 0) return null;
                        let status = 'Balanced';
                        if (netMove > 0) status = 'Shortage';
                        else if (netMove < 0) status = 'Overstock';
                        if (b === 'DWL' || String(b).toUpperCase().includes('WAREHOUSE') || String(b).toUpperCase() === 'DWL') {
                          status = 'Warehouse';
                        }
                        return { b, stock, sold, moveIn, moveOut, netMove, status };
                      })
                      .filter(Boolean) as Array<{
                        b: string;
                        stock: number;
                        sold: number;
                        moveIn: number;
                        moveOut: number;
                        netMove: number;
                        status: string;
                      }>;

                    if (branchRows.length === 0) return null;

                    return (
                      <React.Fragment key={w}>
                        {/* Item header row */}
                        <tr className="bg-slate-50 dark:bg-slate-800/70">
                          <td
                            colSpan={8}
                            onClick={() => onSelectWeight && onSelectWeight(w)}
                            className="py-1.5 px-3 font-bold text-slate-900 dark:text-white cursor-pointer hover:text-teal-600 dark:hover:text-teal-300 sticky left-0 z-10"
                          >
                            <span className="inline-flex items-center gap-2">
                              <span className="text-[10px] uppercase tracking-wider text-slate-500 dark:text-slate-400 font-semibold">Item</span>
                              <span className="font-mono">{itemDisplay}</span>
                              {ws && (
                                <span className="text-[10px] font-normal text-slate-500 dark:text-slate-400">
                                  · Total Stock {ws.currentStock} · Sold {ws.soldQty}
                                  {ws.moveInNeeded > 0 && <span className="text-emerald-600 ml-1">· IN {ws.moveInNeeded}</span>}
                                  {ws.moveOutNeeded > 0 && <span className="text-red-600 ml-1">· OUT {ws.moveOutNeeded}</span>}
                                  {ws.unmetShortage > 0 && <span className="text-amber-600 ml-1">· Buy {ws.unmetShortage}</span>}
                                </span>
                              )}
                            </span>
                          </td>
                        </tr>
                        {branchRows.map(row => (
                          <tr
                            key={`${w}-${row.b}`}
                            className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40"
                          >
                            <td className="py-1 px-3 sticky left-0 bg-white dark:bg-slate-900 z-10 border-r border-slate-100 dark:border-slate-800 text-slate-400 dark:text-slate-500 text-[10px]">
                              {/* empty under sticky item col for visual indent */}
                            </td>
                            <td
                              onClick={() => onSelectBranch && onSelectBranch(row.b)}
                              className="py-1.5 px-3 font-semibold text-slate-800 dark:text-slate-200 cursor-pointer hover:text-blue-600 dark:hover:text-blue-300 border-r border-slate-100 dark:border-slate-800"
                            >
                              {row.b}
                            </td>
                            <td className="py-1 px-2 text-center font-mono text-slate-700 dark:text-slate-300 border-r border-slate-100 dark:border-slate-800">
                              {row.stock}
                            </td>
                            <td className="py-1 px-2 text-center font-mono text-slate-700 dark:text-slate-300 border-r border-slate-100 dark:border-slate-800">
                              {row.sold}
                            </td>
                            <td className={`py-1 px-2 text-center font-mono font-bold border-r border-slate-100 dark:border-slate-800 ${
                              row.moveIn > 0 ? 'text-emerald-700 dark:text-emerald-300' : 'text-slate-400'
                            }`}>
                              {row.moveIn > 0 ? `+${row.moveIn}` : '0'}
                            </td>
                            <td className={`py-1 px-2 text-center font-mono font-bold border-r border-slate-100 dark:border-slate-800 ${
                              row.moveOut > 0 ? 'text-red-700 dark:text-red-300' : 'text-slate-400'
                            }`}>
                              {row.moveOut > 0 ? `-${row.moveOut}` : '0'}
                            </td>
                            <td className={`py-1 px-2 text-center font-mono font-bold border-r border-slate-100 dark:border-slate-800 ${
                              row.netMove > 0
                                ? 'text-emerald-600 dark:text-emerald-400'
                                : row.netMove < 0
                                ? 'text-red-600 dark:text-red-400'
                                : 'text-slate-400'
                            }`}>
                              {row.netMove > 0 ? `+${row.netMove}` : row.netMove}
                            </td>
                            <td className="py-1 px-3 text-center">
                              <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold ${
                                row.status === 'Shortage'
                                  ? 'bg-emerald-100 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-300'
                                  : row.status === 'Overstock'
                                  ? 'bg-red-100 dark:bg-red-950/50 text-red-700 dark:text-red-300'
                                  : row.status === 'Warehouse'
                                  ? 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300'
                                  : 'bg-slate-100 dark:bg-slate-800 text-slate-500'
                              }`}>
                                {row.status === 'Shortage' ? '📉 Shortage' : row.status === 'Overstock' ? '⚠️ Overstock' : row.status === 'Warehouse' ? '🏢 Warehouse' : '✓ Balanced'}
                              </span>
                            </td>
                          </tr>
                        ))}
                      </React.Fragment>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* Sheet 2: Branch Summary */}
      {activeSheetTab === 'branch_summary' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-800 text-white font-semibold text-[11px] border-b border-slate-700">
                  <th className="py-2.5 px-3">Branch Name</th>
                  <th className="py-2.5 px-3 text-center">Total Sold</th>
                  <th className="py-2.5 px-3 text-center">Current Stock</th>
                  <th className="py-2.5 px-3 text-center text-emerald-400">Move IN (Shortage)</th>
                  <th className="py-2.5 px-3 text-center text-red-400">Move OUT (Surplus)</th>
                  <th className="py-2.5 px-3 text-center">Net Change</th>
                  <th className="py-2.5 px-3 text-center">Variants Needing Action</th>
                  <th className="py-2.5 px-3 text-right">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {report.branchSummaries.map(b => (
                  <tr key={b.branch} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                    <td
                      onClick={() => onSelectBranch && onSelectBranch(b.branch)}
                      title={`Click to open Branch ${b.branch} detailed report`}
                      className="py-2 px-3 font-semibold text-slate-900 dark:text-white cursor-pointer hover:text-blue-400 hover:underline"
                    >
                      {b.branch}
                    </td>
                    <td className="py-2 px-3 text-center font-mono font-bold text-slate-900 dark:text-white">
                      {b.totalSold}
                    </td>
                    <td className="py-2 px-3 text-center font-mono font-bold text-slate-700 dark:text-slate-300">
                      {b.totalCurrentStock}
                    </td>
                    <td className="py-2 px-3 text-center font-mono font-bold text-emerald-600">
                      {b.totalMoveIn > 0 ? `+${b.totalMoveIn}` : '0'}
                    </td>
                    <td className="py-2 px-3 text-center font-mono font-bold text-red-600">
                      {b.totalMoveOut > 0 ? `-${b.totalMoveOut}` : '0'}
                    </td>
                    <td className="py-2 px-3 text-center font-mono font-bold">
                      {b.netChange > 0 ? `+${b.netChange}` : b.netChange < 0 ? `${b.netChange}` : '0'}
                    </td>
                    <td className="py-2 px-3 text-center font-mono">
                      {b.variantsNeedingAction}
                    </td>
                    <td className="py-2 px-3 text-right font-medium">
                      <span className={`text-[10px] px-2 py-0.5 rounded font-bold ${
                        b.status === 'OVERSTOCKED'
                          ? 'bg-red-500/15 text-red-600 border border-red-400/30'
                          : b.status === 'SHORTAGE'
                          ? 'bg-emerald-500/15 text-emerald-600 border border-emerald-400/30'
                          : 'bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
                      }`}>
                        {b.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot className="bg-emerald-50 dark:bg-slate-850 font-bold border-t-2 border-slate-300 dark:border-slate-700">
                <tr>
                  <td className="py-2.5 px-3 text-slate-900 dark:text-white font-extrabold">Grand Total</td>
                  <td className="py-2.5 px-3 text-center font-mono font-extrabold text-blue-600 dark:text-blue-400">{report.totalSold}</td>
                  <td className="py-2.5 px-3 text-center font-mono font-extrabold text-slate-900 dark:text-white">{report.totalCurrentStock}</td>
                  <td className="py-2.5 px-3 text-center font-mono font-extrabold text-emerald-600">{report.totalMoveIn}</td>
                  <td className="py-2.5 px-3 text-center font-mono font-extrabold text-red-600">{report.totalMoveOut}</td>
                  <td className="py-2.5 px-3 text-center font-mono font-extrabold">{report.netStockPosition}</td>
                  <td className="py-2.5 px-3 text-center font-mono font-extrabold">
                    {report.branchSummaries.reduce((a, b) => a + b.variantsNeedingAction, 0)}
                  </td>
                  <td className="py-2.5 px-3 text-right text-[11px] text-slate-500">Across {report.branchSummaries.length} Branches</td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>
      )}

      {/* Sheet 3: Movement Summary (Transfer Orders) */}
      {activeSheetTab === 'transfer_orders' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-sm overflow-hidden">
          <div className="p-3 bg-slate-50 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-700 flex items-center justify-between text-xs">
            <span className="font-semibold text-slate-700 dark:text-slate-300">
              Only movements with definite Move OUT donor and Move IN receiver
            </span>
            <span className="font-mono text-emerald-600 font-bold">
              {report.transferOrders.length} Active Transfer Orders
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-800 text-white font-semibold text-[11px] border-b border-slate-700">
                  <th className="py-2.5 px-3">Order ID</th>
                  {hasDesignBreakdown ? (
                    <>
                      <th className="py-2.5 px-3">Design Name</th>
                      <th className="py-2.5 px-3">{dimensionLabel}</th>
                    </>
                  ) : (
                    <th className="py-2.5 px-3">{itemLabel}</th>
                  )}
                  <th className="py-2.5 px-3 text-red-400">Move OUT (Donor)</th>
                  <th className="py-2.5 px-3 text-emerald-400">Move IN (Receiver)</th>
                  <th className="py-2.5 px-3 text-center">Qty</th>
                  <th className="py-2.5 px-3">Redistribution Rationale</th>
                  <th className="py-2.5 px-3 text-right">Priority</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {report.transferOrders.map(t => {
                  const { carat: tCarat, design: tDesign } = splitItemKey(t.weight);
                  return (
                  <tr key={t.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                    <td className="py-2.5 px-3 font-mono font-bold text-slate-500">{t.id}</td>
                    {hasDesignBreakdown ? (
                      <>
                        <td
                          onClick={() => onSelectWeight && onSelectWeight(t.weight)}
                          className="py-2.5 px-3 font-mono font-bold text-slate-900 dark:text-white cursor-pointer hover:text-blue-400 hover:underline"
                        >
                          {tDesign || '—'}
                        </td>
                        <td className="py-2.5 px-3 font-mono text-slate-700 dark:text-slate-300">
                          {reportDimension.isAmount ? tCarat : (itemUnit === 'ct' ? `${tCarat} ct` : tCarat)}
                        </td>
                      </>
                    ) : (
                      <td
                        onClick={() => onSelectWeight && onSelectWeight(t.weight)}
                        title={`Click to view enterprise store availability for ${t.weight} ct`}
                        className="py-2.5 px-3 font-mono font-bold text-slate-900 dark:text-white cursor-pointer hover:text-blue-400 hover:underline"
                      >
                        {reportDimension.isAmount ? t.weight : (itemUnit === 'ct' ? `${t.weight} ct` : t.weight)}
                      </td>
                    )}
                    <td
                      onClick={() => onSelectBranch && onSelectBranch(t.fromBranch)}
                      title={`Click to open Branch ${t.fromBranch} report`}
                      className="py-2.5 px-3 font-semibold text-red-600 cursor-pointer hover:underline"
                    >
                      {t.fromBranch}
                    </td>
                    <td
                      onClick={() => onSelectBranch && onSelectBranch(t.toBranch)}
                      title={`Click to open Branch ${t.toBranch} report`}
                      className="py-2.5 px-3 font-semibold text-emerald-600 cursor-pointer hover:underline"
                    >
                      {t.toBranch}
                    </td>
                    <td className="py-2.5 px-3 text-center font-mono font-bold">{t.qty} {itemUnit}</td>
                    <td className="py-2.5 px-3 text-slate-600 dark:text-slate-300">{t.reason}</td>
                    <td className="py-2.5 px-3 text-right">
                      <span className={`text-[10px] px-2 py-0.5 rounded font-bold ${
                        t.priority === 'CRITICAL' ? 'bg-red-500/20 text-red-600' : 'bg-blue-500/20 text-blue-600'
                      }`}>
                        {t.priority}
                      </span>
                    </td>
                  </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Sheet 4: Unmet Demand & Procurement */}
      {activeSheetTab === 'unmet_demand' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-sm overflow-hidden">
          <div className="p-3 bg-amber-50 dark:bg-amber-950/20 border-b border-amber-200 dark:border-amber-900/40 flex items-center justify-between text-xs">
            <span className="font-semibold text-amber-900 dark:text-amber-200">
              Demand that cannot be resolved through intra-company transfers (Total: {report.totalNewStockToBuy} {itemUnit})
            </span>
            <span className="font-mono text-amber-700 dark:text-amber-400 font-bold">
              Immediate Procurement Requisition
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="bg-slate-800 text-white font-semibold text-[11px] border-b border-slate-700">
                  {hasDesignBreakdown ? (
                    <>
                      <th className="py-2.5 px-3">Design Name</th>
                      <th className="py-2.5 px-3">{dimensionLabel}</th>
                    </>
                  ) : (
                    <th className="py-2.5 px-3">{itemLabel}</th>
                  )}
                  <th className="py-2.5 px-3 text-center">New Stock to Buy</th>
                  <th className="py-2.5 px-3 text-center">Sold Demand</th>
                  <th className="py-2.5 px-3 text-center">Available Stock</th>
                  <th className="py-2.5 px-3">Procurement Rationale</th>
                  <th className="py-2.5 px-3 text-right">Urgency</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {report.procurementOrders.map(p => {
                  const { carat: pCarat, design: pDesign } = splitItemKey(p.weight);
                  return (
                  <tr key={p.weight} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                    {hasDesignBreakdown ? (
                      <>
                        <td className="py-2.5 px-3 font-mono font-bold text-slate-900 dark:text-white">
                          {pDesign || '—'}
                        </td>
                        <td className="py-2.5 px-3 font-mono text-slate-700 dark:text-slate-300">
                          {reportDimension.isAmount ? pCarat : (itemUnit === 'ct' ? `${pCarat} ct` : pCarat)}
                        </td>
                      </>
                    ) : (
                      <td className="py-2.5 px-3 font-mono font-bold text-slate-900 dark:text-white">
                        {reportDimension.isAmount ? p.weight : (itemUnit === 'ct' ? `${p.weight} ct` : p.weight)}
                      </td>
                    )}
                    <td className="py-2.5 px-3 text-center font-mono font-bold text-amber-600">Buy {p.qtyToBuy} {itemUnit}</td>
                    <td className="py-2.5 px-3 text-center font-mono font-bold text-blue-600 dark:text-blue-400">{p.soldDemand} sold</td>
                    <td className="py-2.5 px-3 text-center font-mono text-slate-500">{p.availableStock} in stock</td>
                    <td className="py-2.5 px-3 text-slate-600 dark:text-slate-300">{p.rationale}</td>
                    <td className="py-2.5 px-3 text-right">
                      <span className="text-[10px] px-2 py-0.5 rounded font-bold bg-amber-500/20 text-amber-700 dark:text-amber-300 border border-amber-400/40">
                        {p.urgency}
                      </span>
                    </td>
                  </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

    </div>
  );
};
