import React from 'react';
import { AppTheme, applyThemeToDocument, getStoredSettings, saveStoredSettings } from '../utils/settingsEngine';

const THEMES: { id: AppTheme; label: string; tip: string; swatch: string }[] = [
  {
    id: 'cosmic',
    label: 'Executive Dark',
    tip: 'Deep navy night · diamond-blue accent',
    swatch: 'linear-gradient(135deg,#06142B 0%,#0B2545 55%,#14B4E8 100%)',
  },
  {
    id: 'light',
    label: 'Diamond Light',
    tip: 'Ice-white surfaces · diamond-blue accent',
    swatch: 'linear-gradient(135deg,#F6FAFD 0%,#CFE6F5 40%,#14B4E8 70%,#0B2545 100%)',
  },
  {
    id: 'royal-gold',
    label: 'Royal Gold',
    tip: 'Black walnut · brushed gold · luxury executive',
    swatch: 'linear-gradient(135deg,#100C07 0%,#33260F 48%,#D6A745 100%)',
  },
  {
    id: 'platinum-gold',
    label: 'Platinum Gold',
    tip: 'Platinum ivory · champagne gold · premium light',
    swatch: 'linear-gradient(135deg,#FFFFFF 0%,#F4F1EA 45%,#D7BE7A 78%,#8D6A1C 100%)',
  },
];

interface ThemeSwitcherProps {
  theme: AppTheme;
  onThemeChange: (theme: AppTheme) => void;
  compact?: boolean;
}

export const ThemeSwitcher: React.FC<ThemeSwitcherProps> = ({
  theme,
  onThemeChange,
  compact = true,
}) => {
  const select = (next: AppTheme) => {
    if (next === theme) return;
    applyThemeToDocument(next);
    const current = getStoredSettings();
    saveStoredSettings({ ...current, theme: next });
    onThemeChange(next);
  };

  return (
    <div className="theme-switcher" role="group" aria-label="Color theme" title="Quick theme: light / executive dark. More themes are available in Settings → Theme & Appearance">
      {THEMES.map((t) => (
        <button
          key={t.id}
          type="button"
          className={(t.id === 'light' ? theme === 'light' : theme !== 'light') ? 'active' : ''}
          title={t.tip}
          aria-label={t.tip}
          aria-pressed={t.id === 'light' ? theme === 'light' : theme !== 'light'}
          onClick={() => select(t.id)}
          style={{ background: t.swatch }}
        >
          {!compact && <span className="sr-only">{t.label}</span>}
        </button>
      ))}
    </div>
  );
};
