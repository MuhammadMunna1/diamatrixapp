import React from 'react';
import { BRAND } from '../brand';

/**
 * Opening screen — D logo spins while securing session.
 */
export const LuminaSplash: React.FC<{ message?: string }> = ({
  message = 'Securing session…',
}) => {
  return (
    <div
      className="min-h-screen flex flex-col items-center justify-center px-6 relative overflow-hidden bg-[#F6FAFD]"
      style={{
        background:
          'radial-gradient(ellipse 120% 80% at 50% 45%, #ffffff 0%, #F1F8FD 54%, #D9EBF7 100%)',
      }}
    >
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            'radial-gradient(ellipse 70% 50% at 50% 40%, rgba(14, 165, 233,0.10) 0%, transparent 55%),' +
            'radial-gradient(circle at 20% 30%, rgba(20,180,232,0.07) 0%, transparent 40%)',
        }}
      />
      <div className="relative flex flex-col items-center z-10">
        <div
          className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-[55%] w-64 h-64 rounded-full blur-3xl opacity-50 pointer-events-none"
          style={{
            background:
              'radial-gradient(circle, rgba(14, 165, 233,0.4) 0%, transparent 70%)',
          }}
        />
        <img
          src="/diamatrix-mark.svg"
          alt={BRAND.short}
          className="relative w-44 sm:w-56 h-auto object-contain dmx-logo-3d dmx-logo-spin session-super-spin"
        />
        <h1
          className="mt-6 text-2xl sm:text-3xl font-bold tracking-[0.28em] text-[#0B2545]"
        >
          {BRAND.short.toUpperCase()}
        </h1>
        <p className="mt-2 text-[11px] sm:text-xs text-center max-w-sm text-[#0C94D0]">
          {BRAND.tagline}
        </p>
        <p className="mt-1 text-[10px] font-semibold uppercase tracking-[.18em] text-slate-400">by {BRAND.company}</p>
        <div className="mt-8 flex flex-col items-center gap-3">
          {/* Same rotation period as logo (session-super-spin = 0.55s) */}
          <div
            className="w-9 h-9 rounded-full border-2 border-[#14B4E8]/25 border-t-[#14B4E8] session-loader-spin"
            aria-hidden
          />
          <p className="text-[12px] text-slate-400 font-medium tracking-wide">{message}</p>
        </div>
      </div>
      <p className="absolute bottom-6 text-[10px] text-slate-600 tracking-wider">
        {BRAND.full} · v{BRAND.version}
      </p>
      <style>{`
        @keyframes diamatrix-float {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-6px); }
        }
        @media (prefers-reduced-motion: reduce) {
          img, .session-loader-spin { animation: none !important; }
        }
        /* Logo + loader share one period so they feel locked together */
        .session-super-spin { animation-duration: 0.55s !important; }
        .session-loader-spin {
          animation: diamatrix-spin 0.55s linear infinite;
        }
        @keyframes diamatrix-spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  );
};
