import React, { useEffect, useMemo, useState } from 'react';
import {
  Sparkles,
  RefreshCw,
  Download,
  AlertTriangle,
  TrendingUp,
  Package,
  ArrowRightLeft,
  ShoppingCart,
  Building2,
  CheckCircle2,
  Loader2,
  FileText,
} from 'lucide-react';
import { RedistributionReport } from '../types';
import * as XLSX from 'xlsx';
import { BRAND } from '../brand';

interface AICrossmatchReportViewProps {
  report: RedistributionReport;
  onSwitchToManual?: () => void;
}

type Section = {
  id: string;
  title: string;
  body: string;
  severity?: 'info' | 'warn' | 'critical' | 'ok';
};

/**
 * AI Mode — Crossmatch Report
 * Uses the same redistribution engine metrics (contribution / baseline / hybrid logic)
 * and produces an international-format executive analysis.
 * Optional Gemini narrative when API is available; otherwise deterministic engine summary.
 */

/** Stable hash for transfer / branch rows — prevents multi-month duplicate lines. */
function crossmatchRowHash(parts: Array<string | number | undefined | null>): string {
  return parts
    .map((p) => String(p ?? '')
      .trim()
      .toLowerCase()
      .replace(/\s+/g, ' '))
    .join('|');
}

function dedupeByHash<T>(items: T[] | undefined | null, keyFn: (item: T) => string): T[] {
  if (!items?.length) return [];
  const seen = new Set<string>();
  const out: T[] = [];
  for (const item of items) {
    const key = keyFn(item);
    if (!key || seen.has(key)) continue;
    seen.add(key);
    out.push(item);
  }
  return out;
}

/** Merge velocity-aging branch metrics without double-counting the same outlet. */
function dedupeBranchMetrics<T extends { branch: string; totalSold?: number; totalCurrentStock?: number }>(
  rows: T[] | undefined | null,
): T[] {
  if (!rows?.length) return [];
  const map = new Map<string, T>();
  for (const row of rows) {
    const key = crossmatchRowHash([row.branch]);
    const prev = map.get(key);
    if (!prev) {
      map.set(key, { ...row });
      continue;
    }
    // Keep stronger demand signal; prefer higher stock when equal demand (avoid skew)
    const prevSold = Number(prev.totalSold) || 0;
    const nextSold = Number(row.totalSold) || 0;
    const prevStock = Number(prev.totalCurrentStock) || 0;
    const nextStock = Number(row.totalCurrentStock) || 0;
    if (nextSold > prevSold || (nextSold === prevSold && nextStock > prevStock)) {
      map.set(key, { ...row });
    }
  }
  return Array.from(map.values());
}

export const AICrossmatchReportView: React.FC<AICrossmatchReportViewProps> = ({
  report,
  onSwitchToManual,
}) => {
  const [aiNarrative, setAiNarrative] = useState<string>('');
  const [loadingAi, setLoadingAi] = useState(false);
  const [aiError, setAiError] = useState('');

  /** View-model with de-duplicated multi-month rows (hash-stable). */
  const viewReport = useMemo(() => {
    const transferOrders = dedupeByHash(
      report.transferOrders,
      (t) =>
        crossmatchRowHash([t.fromBranch, t.toBranch, t.weight, t.qty, t.priority]),
    );
    return {
      ...report,
      topShortageBranches: dedupeBranchMetrics(report.topShortageBranches),
      topOverstockedBranches: dedupeBranchMetrics(report.topOverstockedBranches),
      transferOrders,
      totalCurrentStock: Math.max(0, Number(report.totalCurrentStock) || 0),
      totalSold: Math.max(0, Number(report.totalSold) || 0),
      totalNewStockToBuy: Math.max(0, Number(report.totalNewStockToBuy) || 0),
    };
  }, [report]);

  const engineSections = useMemo((): Section[] => {
    const period = report.period || 'Current period';
    // Multi-month integrity: dedupe branch / transfer rows by composite hash
    const shortageBranches = dedupeBranchMetrics(report.topShortageBranches);
    const overstockBranches = dedupeBranchMetrics(report.topOverstockedBranches);
    const transferOrders = dedupeByHash(
      report.transferOrders,
      (t) =>
        crossmatchRowHash([
          t.fromBranch,
          t.toBranch,
          t.weight,
          t.qty,
          t.priority,
        ]),
    );
    const topShort = shortageBranches[0];
    const topOver = overstockBranches[0];
    const topSold = report.top5BestSellingWeights?.[0];
    const topSlow = report.top5SlowMovingWeights?.[0];
    const transfers = transferOrders.length;
    const buy = Math.max(0, Number(report.totalNewStockToBuy) || 0);
    const totalStock = Math.max(0, Number(report.totalCurrentStock) || 0);
    const totalSold = Math.max(0, Number(report.totalSold) || 0);
    const sellThrough =
      totalStock + totalSold > 0 ? (totalSold / (totalStock + totalSold)) * 100 : 0;

    const sections: Section[] = [
      {
        id: 'exec',
        title: 'Executive Summary',
        severity: 'info',
        body:
          `Period **${period}**. Network holds **${report.totalCurrentStock.toLocaleString()}** pcs against **${report.totalSold.toLocaleString()}** units sold ` +
          `(sell-through ~**${sellThrough.toFixed(1)}%**). ` +
          `Engine recommends **${transfers}** intra-branch transfers and **${buy.toLocaleString()}** pcs new procurement. ` +
          `Allocation mode follows sales contribution with warehouse (DWL) as central buffer.`,
      },
      {
        id: 'shortage',
        title: 'Shortage Hotspots',
        severity: topShort && topShort.totalSold > 0 && topShort.totalCurrentStock === 0 ? 'critical' : 'warn',
        body: topShort
          ? `**${topShort.branch}** shows demand of **${topShort.totalSold}** sold with stock **${topShort.totalCurrentStock}**. ` +
            `Priority: move-in from overstocked outlets or DWL before lost sales escalate.`
          : 'No critical shortage branch detected in the current filter slice.',
      },
      {
        id: 'overstock',
        title: 'Overstock / Capital Lock',
        severity: topOver && topOver.totalCurrentStock > 0 && topOver.totalSold === 0 ? 'warn' : 'info',
        body: topOver
          ? `**${topOver.branch}** holds **${topOver.totalCurrentStock}** pcs with **${topOver.totalSold}** period sales. ` +
            `Eligible as donor for transfer orders where contribution share is lower than stock share.`
          : 'Overstock profile is balanced relative to sales share.',
      },
      {
        id: 'velocity',
        title: 'Product Velocity Crossmatch',
        severity: 'info',
        body:
          (topSold
            ? `Best seller: **${topSold.weight}** — sold **${topSold.soldQty}**, stock **${topSold.currentStock}**. `
            : '') +
          (topSlow
            ? `Slow / idle: **${topSlow.weight}** — sold **${topSlow.soldQty}**, stock **${topSlow.currentStock}** (rotate or mark for exhibition).`
            : ''),
      },
      {
        id: 'transfers',
        title: 'Transfer Manifest (Engine)',
        severity: transfers > 0 ? 'ok' : 'info',
        body:
          transfers > 0
            ? `**${transfers}** recommended lines. Top routes: ` +
              report.transferOrders
                .slice(0, 5)
                .map((t) => `${t.fromBranch}→${t.toBranch} (${t.weight} ×${t.qty})`)
                .join('; ') +
              (transfers > 5 ? '…' : '') +
              '. Execute high-priority first to protect contribution share at receiving outlets.'
            : 'No transfer lines under current filters — network stock already aligned with sales contribution.',
      },
      {
        id: 'procure',
        title: 'Procurement Gap',
        severity: buy > 0 ? 'warn' : 'ok',
        body:
          buy > 0
            ? `New buy **${buy.toLocaleString()}** pcs across ${report.procurementOrders?.length || 0} SKU/range lines. ` +
              `Focus on high-sold zero-stock ranges so DWL buffer is not the only cover.`
            : 'No procurement gap after redistribution — company stock covers period demand.',
      },
      {
        id: 'logic',
        title: 'Logic Applied (Manual Engine Parity)',
        severity: 'info',
        body:
          'Crossmatch uses the same rules as Apply & Distribution: ' +
          '(1) Sales contribution share across retail outlets, (2) period baseline coverage from upload window, ' +
          '(3) hybrid compression when target exceeds available stock, (4) DWL warehouse excluded from retail share, ' +
          '(5) trailing-S outlet codes merged (BCTS→BCT). AI narrative below interprets these numbers; it does not replace the matrix.',
      },
    ];
    return sections;
  }, [report]);

  const buildMetricsContext = () => ({
    period: report.period,
    totalSold: report.totalSold,
    totalStock: report.totalCurrentStock,
    totalMoveIn: report.totalMoveIn,
    totalMoveOut: report.totalMoveOut,
    netStockPosition: report.netStockPosition,
    newStockToBuy: report.totalNewStockToBuy,
    transferCount: report.transferOrders?.length || 0,
    topShortage: report.topShortageBranches?.slice(0, 5).map((b) => ({
      branch: b.branch,
      stock: b.totalCurrentStock,
      sold: b.totalSold,
    })),
    topOverstock: report.topOverstockedBranches?.slice(0, 5).map((b) => ({
      branch: b.branch,
      stock: b.totalCurrentStock,
      sold: b.totalSold,
    })),
    topWeights: report.top5BestSellingWeights?.slice(0, 5).map((w) => ({
      weight: w.weight,
      sold: w.soldQty,
      stock: w.currentStock,
    })),
    transfers: report.transferOrders?.slice(0, 12).map((t) => ({
      from: t.fromBranch,
      to: t.toBranch,
      weight: t.weight,
      qty: t.qty,
      priority: t.priority,
    })),
  });

  const runAiNarrative = async () => {
    setLoadingAi(true);
    setAiError('');
    try {
      const res = await fetch('/api/gemini/analyze', {
        method: 'POST',
        credentials: 'include',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt:
            `You are ${BRAND.aiName} for ${BRAND.company}. Write a concise international-standard crossmatch briefing ` +
            '(max 350 words) for jewelry retail multi-outlet stock vs sold. Use the metrics JSON. ' +
            'Structure: (1) Network health (2) Priority actions this week (3) Transfer & buy recommendations (4) Risks. ' +
            'Use outlet codes and range/carat keys exactly as given. No markdown tables. Professional tone.',
          metricsContext: buildMetricsContext(),
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'AI request failed');
      setAiNarrative(data.analysis || data.message || '');
    } catch (e: any) {
      setAiError(e.message || 'AI narrative unavailable — engine sections below remain authoritative.');
      setAiNarrative('');
    } finally {
      setLoadingAi(false);
    }
  };

  useEffect(() => {
    runAiNarrative();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [report.period, report.totalSold, report.totalCurrentStock, report.transferOrders?.length]);

  const handleExport = () => {
    const rows: (string | number)[][] = [
      [`${BRAND.full} — AI Crossmatch Report`],
      ['Period', report.period],
      ['Generated', new Date().toISOString()],
      [],
      ['Section', 'Severity', 'Content'],
      ...engineSections.map((s) => [s.title, s.severity || 'info', s.body.replace(/\*\*/g, '')]),
      [],
      ['AI Narrative'],
      [aiNarrative || '(not generated)'],
      [],
      ['Transfer ID', 'From', 'To', 'Weight/Range', 'Qty', 'Priority'],
      ...(report.transferOrders || []).map((t) => [
        t.id,
        t.fromBranch,
        t.toBranch,
        t.weight,
        t.qty,
        t.priority,
      ]),
    ];
    const ws = XLSX.utils.aoa_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'AI_Crossmatch');
    XLSX.writeFile(wb, `AI_Crossmatch_${Date.now()}.xlsx`);
  };

  const severityStyle = (s?: string) => {
    switch (s) {
      case 'critical':
        return 'border-red-300 bg-red-50';
      case 'warn':
        return 'border-amber-300 bg-amber-50';
      case 'ok':
        return 'border-emerald-300 bg-emerald-50';
      default:
        return 'border-slate-200 bg-white';
    }
  };

  const renderBold = (text: string) => {
    const parts = text.split(/\*\*(.*?)\*\*/g);
    return parts.map((p, i) =>
      i % 2 === 1 ? (
        <strong key={i} className="font-semibold text-slate-900">
          {p}
        </strong>
      ) : (
        <span key={i}>{p}</span>
      )
    );
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="bg-white border border-[#d0d7de] px-4 py-3 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-violet-600 to-indigo-600 text-white flex items-center justify-center shadow-sm">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-[#0f2744] tracking-tight">
              {BRAND.short} AI Crossmatch
            </h2>
            <p className="text-[11px] text-[#6a6d70] mt-0.5 max-w-xl">
              {BRAND.full} · AI Mode · Period:{' '}
              <strong className="text-[#32363a]">{report.period}</strong>
              {' · '}
              {BRAND.tagline}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {onSwitchToManual && (
            <button
              type="button"
              onClick={onSwitchToManual}
              className="h-8 px-3 text-[12px] font-semibold border border-[#89919a] bg-white text-[#32363a] hover:bg-[#f5f6f7]"
            >
              ← Manual Matrix Mode
            </button>
          )}
          <button
            type="button"
            onClick={runAiNarrative}
            disabled={loadingAi}
            className="h-8 px-3 text-[12px] font-semibold border border-violet-300 bg-violet-50 text-violet-800 hover:bg-violet-100 inline-flex items-center gap-1.5 disabled:opacity-50"
          >
            {loadingAi ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <RefreshCw className="w-3.5 h-3.5" />}
            Refresh AI
          </button>
          <button
            type="button"
            onClick={handleExport}
            className="h-8 px-3 text-[12px] font-semibold bg-[#0B6FB8] text-white border border-[#0B6FB8] hover:bg-[#0B8BD6] inline-flex items-center gap-1.5"
          >
            <Download className="w-3.5 h-3.5" />
            Export
          </button>
        </div>
      </div>

      {/* KPI strip */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
        {[
          { label: 'Sold (period)', value: report.totalSold, icon: TrendingUp, color: 'text-blue-700' },
          { label: 'Stock on hand', value: report.totalCurrentStock, icon: Package, color: 'text-emerald-700' },
          { label: 'Move IN', value: report.totalMoveIn, icon: ArrowRightLeft, color: 'text-teal-700' },
          { label: 'Move OUT', value: report.totalMoveOut, icon: ArrowRightLeft, color: 'text-amber-700' },
          { label: 'Transfers', value: report.transferOrders?.length || 0, icon: Building2, color: 'text-indigo-700' },
          { label: 'New buy', value: report.totalNewStockToBuy, icon: ShoppingCart, color: 'text-red-700' },
        ].map((k) => (
          <div key={k.label} className="bg-white border border-[#d0d7de] px-3 py-2">
            <div className="text-[10px] font-semibold text-[#6a6d70] uppercase tracking-wide flex items-center gap-1">
              <k.icon className={`w-3 h-3 ${k.color}`} />
              {k.label}
            </div>
            <div className="text-lg font-bold text-[#29445F] font-mono tabular-nums">
              {Number(k.value).toLocaleString()}
            </div>
          </div>
        ))}
      </div>

      {/* AI narrative */}
      <div className="bg-gradient-to-br from-violet-50 to-indigo-50 border border-violet-200/80 rounded-lg px-4 py-3">
        <div className="flex items-center gap-2 mb-2">
          <FileText className="w-4 h-4 text-violet-700" />
          <h3 className="text-sm font-bold text-violet-900">AI Narrative Briefing</h3>
          {loadingAi && <span className="text-[10px] text-violet-600">Generating…</span>}
        </div>
        {aiError && (
          <p className="text-[12px] text-amber-800 bg-amber-50 border border-amber-200 rounded px-2 py-1.5 mb-2">
            {aiError}
          </p>
        )}
        {aiNarrative ? (
          <div className="text-[13px] text-slate-800 leading-relaxed whitespace-pre-wrap">{aiNarrative}</div>
        ) : (
          !loadingAi && (
            <p className="text-[12px] text-slate-500">
              Narrative pending — engine crossmatch sections below are still valid for decisions.
            </p>
          )
        )}
      </div>

      {/* Engine sections */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
        {engineSections.map((s) => (
          <div key={s.id} className={`border rounded-lg px-3.5 py-3 ${severityStyle(s.severity)}`}>
            <div className="flex items-center gap-2 mb-1.5">
              {s.severity === 'critical' || s.severity === 'warn' ? (
                <AlertTriangle
                  className={`w-3.5 h-3.5 ${s.severity === 'critical' ? 'text-red-600' : 'text-amber-600'}`}
                />
              ) : s.severity === 'ok' ? (
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
              ) : (
                <Sparkles className="w-3.5 h-3.5 text-slate-500" />
              )}
              <h4 className="text-[13px] font-bold text-slate-900">{s.title}</h4>
            </div>
            <p className="text-[12px] text-slate-700 leading-relaxed">{renderBold(s.body)}</p>
          </div>
        ))}
      </div>

      {/* Transfer table preview */}
      {(viewReport.transferOrders?.length || 0) > 0 && (
        <div className="bg-white border border-[#d0d7de] overflow-hidden">
          <div className="px-3 py-2 bg-[#f6f8fa] border-b border-[#d0d7de] text-[11px] font-semibold text-[#32363a]">
            Priority transfer lines (first 15)
          </div>
          <div className="overflow-x-auto max-h-[280px]">
            <table className="w-full text-[11px] border-collapse">
              <thead className="sticky top-0 bg-[#f6f8fa]">
                <tr>
                  {['From', 'To', 'Range / Weight', 'Qty', 'Priority', 'Reason'].map((h) => (
                    <th
                      key={h}
                      className="border border-[#e6e8eb] px-2 py-1.5 text-left font-semibold text-[#32363a]"
                    >
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {viewReport.transferOrders.slice(0, 15).map((t) => (
                  <tr key={t.id} className="hover:bg-[#f8fafc]">
                    <td className="border border-[#e6e8eb] px-2 py-1 font-mono font-semibold">{t.fromBranch}</td>
                    <td className="border border-[#e6e8eb] px-2 py-1 font-mono font-semibold text-emerald-800">
                      {t.toBranch}
                    </td>
                    <td className="border border-[#e6e8eb] px-2 py-1 font-mono">{t.weight}</td>
                    <td className="border border-[#e6e8eb] px-2 py-1 text-right font-mono">{t.qty}</td>
                    <td className="border border-[#e6e8eb] px-2 py-1">
                      <span
                        className={`px-1.5 py-0.5 text-[10px] font-bold ${
                          t.priority === 'HIGH'
                            ? 'bg-red-100 text-red-800'
                            : 'bg-slate-100 text-slate-700'
                        }`}
                      >
                        {t.priority}
                      </span>
                    </td>
                    <td className="border border-[#e6e8eb] px-2 py-1 text-slate-600 max-w-[220px] truncate">
                      {t.reason}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
