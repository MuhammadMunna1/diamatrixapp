import React, { useMemo } from 'react';
import {
  Building2,
  FileSpreadsheet,
  PackagePlus,
  Clock,
  ChevronRight,
  TrendingUp,
  Bell,
} from 'lucide-react';
import {
} from 'recharts';
import { RedistributionReport, SalesTimeframe } from '../types';
import { BRAND } from '../brand';

interface NetSuiteHomeDashboardProps {
  report: RedistributionReport;
  onNavigateView: (view: any, report?: any) => void;
  onSelectBranch?: (branch: string) => void;
  onSelectWeight?: (weight: string) => void;
  selectedTimeframe: SalesTimeframe;
  onTimeframeChange: (tf: SalesTimeframe) => void;
  onOpenDailyUpload: () => void;
}

/* Diamond-blue tokens (from the Operations Cockpit design) */
const CYAN = '#14B4E8';
const NAVY = '#0B2545';
const NAVY_DEEP = '#09203F';
const MUTED = '#4F6B88';
const BORDER = '#D3E8F6';
const GREEN = '#15803D';

const TF_OPTIONS: SalesTimeframe[] = ['1M', '3M', '6M', '9M', '1Y', '2Y'];

/**
 * Heatmap scale: use explicit performance bands so adjacent values remain
 * visually distinct instead of collapsing into a narrow continuous shade.
 * Higher sales = darker / stronger blue.
 */
function heatColor(t: number): string {
  const stops = [
    { at: 0.00, color: '#E6F0FA' },
    { at: 0.10, color: '#C7DDF2' },
    { at: 0.20, color: '#9FC3E5' },
    { at: 0.35, color: '#6FA5D8' },
    { at: 0.50, color: '#4C8CCA' },
    { at: 0.65, color: '#2A75D3' },
    { at: 0.80, color: '#1B5D9B' },
    { at: 1.00, color: '#0F4C81' },
  ];

  const value = Math.min(1, Math.max(0, t));
  for (let i = 1; i < stops.length; i += 1) {
    if (value <= stops[i].at) {
      const prev = stops[i - 1];
      const next = stops[i];
      const local = (value - prev.at) / (next.at - prev.at);
      const hex = (channel: number) => channel.toString(16).padStart(2, '0');
      const parse = (color: string) => [
        parseInt(color.slice(1, 3), 16),
        parseInt(color.slice(3, 5), 16),
        parseInt(color.slice(5, 7), 16),
      ];
      const from = parse(prev.color);
      const to = parse(next.color);
      const rgb = from.map((channel, index) => Math.round(channel + (to[index] - channel) * local));
      return `#${hex(rgb[0])}${hex(rgb[1])}${hex(rgb[2])}`;
    }
  }

  return stops[stops.length - 1].color;
}

const Sparkle: React.FC<{ className?: string; size?: number }> = ({ className = '', size = 14 }) => (
  <svg aria-hidden width={size} height={size} viewBox="0 0 24 24" className={`absolute ${className}`} fill={CYAN}>
    <path d="M12 0c.8 6.4 5.6 11.2 12 12-6.4.8-11.2 5.6-12 12-.8-6.4-5.6-11.2-12-12C6.4 11.2 11.2 6.4 12 0z" />
  </svg>
);

const Panel: React.FC<{ className?: string; children: React.ReactNode }> = ({ className = '', children }) => (
  <section
    className={`rounded-2xl bg-white ${className}`}
    style={{ border: `1px solid ${BORDER}`, boxShadow: '0 10px 30px rgba(20, 180, 232, 0.10)' }}
  >
    {children}
  </section>
);

export const NetSuiteHomeDashboard: React.FC<NetSuiteHomeDashboardProps> = ({
  report,
  onNavigateView,
  onSelectBranch,
  onSelectWeight,
  selectedTimeframe,
  onTimeframeChange,
  onOpenDailyUpload,
}) => {
  const totalStock = report.totalCurrentStock || 0;
  const totalSold = report.totalSold || 0;
  const totalMoveIn = report.totalMoveIn || 0;
  const totalMoveOut = report.totalMoveOut || 0;
  const branches = useMemo(() => (report.branchSummaries || []).filter((b) => !b.isWarehouse), [report.branchSummaries]);
  const activeBranches = branches.length;
  const alerts = report.actionAlerts?.length || 0;
  const shortageCount = report.topShortageBranches?.length || 0;
  const overstockCount = report.topOverstockedBranches?.length || 0;
  const skusToBuy = (report.procurementOrders || []).length;
  const sellThrough = (totalSold + totalStock) > 0 ? Math.round((totalSold / (totalSold + totalStock)) * 1000) / 10 : 0;
  const noun = report.categoryConfig?.itemTypeNoun || 'item';

  const rankedBranches = useMemo(() => [...branches].sort((a, b) => b.totalSold - a.totalSold), [branches]);
  const topItems = useMemo(
    () => (report.top5BestSellingWeights || []).length
      ? report.top5BestSellingWeights.slice(0, 6)
      : (report.weightSummaries || []).slice(0, 6),
    [report.top5BestSellingWeights, report.weightSummaries]
  );

  /* Branch × item heatmap from the real allocation matrix */
  const heat = useMemo(() => {
    const allowed = new Set((report.weightSummaries || []).filter(w => w.soldQty > 0 || w.currentStock > 0).map(w => w.weight));
    const cols = (report.matrix?.weights || []).filter(w => allowed.has(w)).slice(0, 8);
    const rows = rankedBranches.slice(0, 5).map((b) => b.branch);
    let max = 0;
    const cells = rows.map((r) =>
      cols.map((c) => {
        const v = report.matrix?.cells?.[r]?.[c];
        const sold = v?.sold || 0;
        if (sold > max) max = sold;
        return { sold, stock: v?.stock || 0 };
      })
    );
    return { cols, rows, cells, max: max || 1 };
  }, [report, rankedBranches]);

  const recentMoves = useMemo(() => (report.transferOrders || []).slice(0, 5), [report.transferOrders]);

  const insights = useMemo(() => {
    const out: string[] = [];
    const lead = rankedBranches[0];
    if (lead && totalSold > 0) {
      out.push(`${lead.branch} leads with ${Math.round((lead.totalSold / totalSold) * 100)}% of units sold in ${selectedTimeframe}`);
    }
    const best = topItems[0];
    if (best && totalSold > 0) {
      out.push(`${best.weight} is the best-selling ${noun.toLowerCase()} — ${Math.round((best.soldQty / totalSold) * 100)}% of sales`);
    }
    out.push(
      shortageCount
        ? `${shortageCount} outlets are short on stock — ${totalMoveIn.toLocaleString()} pcs recommended to move in`
        : 'No outlets are short on stock right now'
    );
    out.push(
      skusToBuy
        ? `Refill demand: ${skusToBuy} SKUs need new buying${overstockCount ? `, ${overstockCount} outlets overstocked` : ''}`
        : `Refill demand is clear${overstockCount ? ` · ${overstockCount} outlets overstocked` : ''}`
    );
    return out;
  }, [rankedBranches, topItems, totalSold, selectedTimeframe, noun, shortageCount, totalMoveIn, skusToBuy, overstockCount]);

  const kpis = [
    { label: 'Total Stock', value: totalStock.toLocaleString(), delta: `${activeBranches} active outlets`, onClick: () => onNavigateView('reports', 'excel_sheet') },
    { label: 'Units Sold', value: totalSold.toLocaleString(), delta: `Selected period · ${selectedTimeframe}`, onClick: () => onNavigateView('reports', 'excel_sheet') },
    { label: 'Sell-through (Sold ÷ Sold + Closing Stock)', value: `${sellThrough}%`, delta: `Selected period · ${selectedTimeframe}`,  onClick: () => onNavigateView('reports', 'movement_summary') },
  ];

  const shortcuts = [
    { title: 'Allocation Matrix', detail: 'Branch stock targets', icon: FileSpreadsheet, view: 'reports', report: 'excel_sheet' },
    { title: 'Refill Demand', detail: 'Buy recommendations', icon: PackagePlus, view: 'reports', report: 'refill_demand' },
    { title: 'Showrooms', detail: `${activeBranches} active outlets`, icon: Building2, view: 'reports', report: 'branches' },
    { title: 'Movement & Aging', detail: 'Inventory health', icon: Clock, view: 'movement_aging', report: undefined },
  ];

  return (
    <div
      className="w-full min-h-[calc(100vh-52px)]"
      style={{ background: 'linear-gradient(180deg, #F6FAFD 0%, #EAF4FB 100%)', color: NAVY }}
    >
      <div className="mx-auto max-w-[1500px] space-y-5 p-4 sm:p-6">
        {/* Title row */}
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <h1 className="font-display text-3xl font-semibold tracking-tight sm:text-5xl" style={{ color: NAVY_DEEP }}>
              Operations Cockpit
            </h1>
            <p className="mt-1.5 text-sm" style={{ color: MUTED }}>
              {BRAND.short} • Live — {report.period} · Sales {selectedTimeframe}
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <div className="flex overflow-hidden rounded-xl border bg-white" style={{ borderColor: BORDER }}>
              {TF_OPTIONS.map((tf) => (
                <button
                  key={tf}
                  type="button"
                  onClick={() => onTimeframeChange(tf)}
                  className={`px-3 py-2 text-[11px] font-bold transition-colors ${selectedTimeframe === tf ? '' : 'hover:bg-[#E6F4FC]'}`}
                  style={selectedTimeframe === tf ? { background: `linear-gradient(90deg, ${CYAN}, #3AC6FF)`, color: '#FFFFFF' } : { color: MUTED }}
                >
                  {tf}
                </button>
              ))}
            </div>
            <button
              type="button"
              title="Open alerts"
              onClick={() => onNavigateView('reports', 'movement_summary')}
              className="relative rounded-xl border bg-white p-2.5 hover:bg-[#E6F4FC]"
              style={{ borderColor: BORDER, color: CYAN }}
            >
              <Bell className="h-4 w-4" />
              {alerts > 0 && (
                <span className="absolute -right-1 -top-1 rounded-full px-1.5 text-[9px] font-bold" style={{ background: CYAN, color: '#FFFFFF' }}>{alerts}</span>
              )}
            </button>
            <button
              type="button"
              onClick={onOpenDailyUpload}
              className="inline-flex items-center gap-2 rounded-xl px-4 py-2.5 text-xs font-bold shadow-md hover:brightness-105"
              style={{ color: '#FFFFFF', background: `linear-gradient(90deg, ${CYAN}, #3AC6FF)`, boxShadow: '0 6px 16px rgba(20,180,232,0.35)' }}
            >
              <PackagePlus className="h-4 w-4" /> Daily Intake
            </button>
          </div>
        </div>

        {/* KPI cards */}
        <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
          {kpis.map((k) => (
            <button key={k.label} type="button" onClick={k.onClick} className="text-left">
              <Panel className="relative overflow-hidden px-5 py-5 text-center transition-transform hover:-translate-y-0.5">
                <Sparkle className="right-4 top-3" size={16} />
                <Sparkle className="left-3 top-8 opacity-70" size={9} />
                <Sparkle className="bottom-3 left-4" size={13} />
                <div className="text-sm font-medium tracking-wide" style={{ color: NAVY }}>{k.label}</div>
                <div className="mt-1 text-5xl font-extrabold tabular-nums leading-tight sm:text-6xl" style={{ color: CYAN }}>{k.value}</div>
                <div className="mt-1 inline-flex items-center gap-1.5 text-sm" style={{ color: GREEN }}>
                  <TrendingUp className="h-4 w-4" /> {k.delta}
                </div>
              </Panel>
            </button>
          ))}
        </div>

        {/* Trend + heatmap/insights */}
        <div className="grid grid-cols-1 gap-4 xl:grid-cols-12">
          <Panel className="p-5 xl:col-span-7">
            <div className="mb-3 flex items-start justify-between gap-3">
              <div>
                <h2 className="font-display text-xl font-medium" style={{ color: NAVY_DEEP }}>Distribution Analysis — Stock × Sold</h2>
                <p className="text-xs" style={{ color: MUTED }}>Decision view: where stock should move, where it should stay, and where new buying is required.</p>
              </div>
              <button type="button" onClick={() => onNavigateView('reports', 'execution')} className="rounded-lg border px-2.5 py-1.5 text-[10px] font-extrabold" style={{ borderColor: BORDER, color: '#0B6FB8', background: '#F4FAFE' }}>
                Open Execution Report
              </button>
            </div>
            <div className="grid grid-cols-2 gap-2.5 sm:grid-cols-4">
              {[
                { label: 'Move In', value: totalMoveIn, note: 'shortage / under-stock', color: '#15803D' },
                { label: 'Move Out', value: totalMoveOut, note: 'overstock / excess', color: '#DC2626' },
                { label: 'New Buy', value: report.totalNewStockToBuy || 0, note: 'not covered by transfers', color: '#B45309' },
                { label: 'Action Items', value: report.variantsNeedingActionCount || 0, note: 'items needing decision', color: '#0B6FB8' },
              ].map((m) => (
                <div key={m.label} className="rounded-xl border p-3" style={{ borderColor: BORDER, background: '#FBFDFF' }}>
                  <div className="text-[10px] font-extrabold tracking-wide" style={{ color: MUTED }}>{m.label}</div>
                  <div className="mt-1 text-2xl font-black" style={{ color: m.color }}>{m.value.toLocaleString()}</div>
                  <div className="mt-0.5 text-[10px]" style={{ color: MUTED }}>{m.note}</div>
                </div>
              ))}
            </div>
            <div className="mt-4 overflow-x-auto">
              <table className="w-full min-w-[620px] text-left text-xs">
                <thead><tr className="border-b text-[10px] uppercase tracking-wide" style={{ borderColor: BORDER, color: MUTED }}>
                  <th className="py-2 pr-3">Branch</th><th className="py-2 pr-3 text-right">Sold</th><th className="py-2 pr-3 text-right">Stock</th><th className="py-2 pr-3 text-right">Move In</th><th className="py-2 pr-3 text-right">Move Out</th><th className="py-2">Position</th>
                </tr></thead>
                <tbody>
                  {rankedBranches.slice(0, 7).map((b) => {
                    const status = b.status === 'SHORTAGE' ? 'SHORTAGE' : b.status === 'OVERSTOCKED' ? 'OVERSTOCK' : 'BALANCED';
                    const statusStyle = status === 'SHORTAGE' ? { bg: '#ECFDF3', fg: '#15803D' } : status === 'OVERSTOCK' ? { bg: '#FEF2F2', fg: '#DC2626' } : { bg: '#F1F5F9', fg: '#475569' };
                    return <tr key={b.branch} className="border-b" style={{ borderColor: '#E6EFF6' }}>
                      <td className="py-2 pr-3 font-bold">{b.branch}</td>
                      <td className="py-2 pr-3 text-right font-mono">{b.totalSold.toLocaleString()}</td>
                      <td className="py-2 pr-3 text-right font-mono">{b.totalCurrentStock.toLocaleString()}</td>
                      <td className="py-2 pr-3 text-right font-mono font-bold" style={{ color: '#15803D' }}>{b.totalMoveIn ? `+${b.totalMoveIn.toLocaleString()}` : '—'}</td>
                      <td className="py-2 pr-3 text-right font-mono font-bold" style={{ color: '#DC2626' }}>{b.totalMoveOut ? `-${b.totalMoveOut.toLocaleString()}` : '—'}</td>
                      <td className="py-2"><span className="rounded-full px-2 py-1 text-[9px] font-extrabold" style={{ background: statusStyle.bg, color: statusStyle.fg }}>{status}</span></td>
                    </tr>;
                  })}
                  {!rankedBranches.length && <tr><td colSpan={6} className="py-8 text-center" style={{ color: MUTED }}>Upload stock + sold data to see distribution analysis.</td></tr>}
                </tbody>
              </table>
            </div>
          </Panel>

          <div className="space-y-4 xl:col-span-5">
            <Panel className="p-5">
              <h2 className="text-xl font-extrabold tracking-tight" style={{ color: NAVY_DEEP }}>Branch × {noun} Heatmap</h2>
              <p className="text-xs" style={{ color: MUTED }}>Units sold — higher = darker</p>
              {heat.rows.length && heat.cols.length ? (
                <div className="mt-3 overflow-x-auto">
                  <div className="min-w-[420px]">
                    <div className="grid gap-1 pb-1" style={{ gridTemplateColumns: `96px repeat(${heat.cols.length}, minmax(0, 1fr))` }}>
                      <span />
                      {heat.cols.map((c) => (
                        <span key={c} className="truncate text-center text-[10px] font-semibold" style={{ color: MUTED }} title={c}>{c}</span>
                      ))}
                    </div>
                    {heat.rows.map((r, ri) => (
                      <div key={r} className="mb-1 grid gap-1" style={{ gridTemplateColumns: `96px repeat(${heat.cols.length}, minmax(0, 1fr))` }}>
                        <button
                          type="button"
                          onClick={() => onSelectBranch?.(r)}
                          className="mr-3 truncate rounded-md px-2 py-2 text-left text-xs font-semibold"
                          style={{ background: NAVY_DEEP, color: '#FFFFFF' }}
                          title={r}
                        >
                          {r}
                        </button>
                        {heat.cells[ri].map((cell, ci) => (
                          <div
                            key={ci}
                            className="rounded-md"
                            style={{ background: heatColor(cell.sold > 0 ? 0.12 + 0.88 * Math.sqrt(cell.sold / heat.max) : 0), minHeight: 30 }}
                            title={`${r} · ${heat.cols[ci]}: ${cell.sold} sold, ${cell.stock} in stock`}
                          />
                        ))}
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <p className="py-8 text-center text-sm" style={{ color: MUTED }}>Upload stock + sold data to see the heatmap.</p>
              )}
            </Panel>

            <Panel className="p-5">
              <h2 className="text-xl font-extrabold tracking-tight" style={{ color: NAVY_DEEP }}>Key Insights</h2>
              <ul className="mt-3 space-y-2.5">
                {insights.map((t) => (
                  <li key={t} className="flex items-start gap-2.5 text-sm">
                    <svg aria-hidden width="12" height="12" viewBox="0 0 24 24" className="mt-1.5 shrink-0" fill={CYAN}><path d="M12 0l12 12-12 12L0 12z" /></svg>
                    <span>{t}</span>
                  </li>
                ))}
              </ul>
            </Panel>
          </div>
        </div>

        {/* Shortcuts (mobile has no sidebar) */}
        <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
          {shortcuts.map((s) => (
            <button
              key={s.title}
              type="button"
              onClick={() => onNavigateView(s.view, s.report)}
              className="group rounded-2xl bg-white p-4 text-left transition-transform hover:-translate-y-0.5"
              style={{ border: `1px solid ${BORDER}`, boxShadow: '0 6px 18px rgba(20,180,232,0.08)' }}
            >
              <s.icon className="mb-2 h-5 w-5" style={{ color: CYAN }} />
              <span className="block text-sm font-bold">{s.title}</span>
              <span className="block text-xs" style={{ color: MUTED }}>{s.detail}</span>
            </button>
          ))}
        </div>

        {/* Reminders + top items + transfers */}
        <div className="grid grid-cols-1 gap-4 xl:grid-cols-12">
          <Panel className="p-5 xl:col-span-4">
            <div className="mb-2 flex items-center justify-between">
              <h2 className="text-base font-extrabold">Reminders</h2>
              <span className="rounded-full px-2 py-0.5 text-[10px] font-bold" style={{ background: '#E6F4FC', color: '#0B6FB8' }}>{alerts} open</span>
            </div>
            <div className="space-y-1">
              {(report.actionAlerts || []).slice(0, 4).map((a, i) => (
                <button
                  key={a.id || `${a.title}-${i}`}
                  type="button"
                  onClick={() => onNavigateView('reports', 'movement_summary')}
                  className="flex w-full items-start gap-2.5 rounded-lg px-2 py-2 text-left hover:bg-[#F1F8FD]"
                >
                  <span className={`mt-0.5 h-8 w-1 rounded-full ${a.priority === 'URGENT' ? 'bg-red-500' : a.priority === 'WARNING' ? 'bg-amber-500' : ''}`} style={a.priority === 'INFO' ? { background: CYAN } : undefined} />
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-xs font-bold">{a.title}</span>
                    <span className="line-clamp-2 block text-[11px]" style={{ color: MUTED }}>{a.description}</span>
                  </span>
                  <ChevronRight className="mt-1 h-3.5 w-3.5" style={{ color: MUTED }} />
                </button>
              ))}
              {!alerts && <p className="py-5 text-center text-xs" style={{ color: MUTED }}>No active reminders.</p>}
            </div>
          </Panel>

          <Panel className="p-5 xl:col-span-3">
            <h2 className="mb-2 text-base font-extrabold">Top selling {noun.toLowerCase()}s</h2>
            <div className="space-y-1">
              {topItems.map((w) => {
                const pct = totalSold > 0 ? Math.round((w.soldQty / totalSold) * 100) : 0;
                return (
                  <button key={w.weight} type="button" onClick={() => onSelectWeight?.(w.weight)} className="w-full rounded-lg px-2 py-1.5 text-left hover:bg-[#F1F8FD]">
                    <div className="flex items-center justify-between text-xs">
                      <span className="truncate font-semibold">{w.weight}</span>
                      <span className="font-mono" style={{ color: MUTED }}>{w.soldQty} · <b style={{ color: '#0B6FB8' }}>{pct}%</b></span>
                    </div>
                    <div className="mt-1 h-1.5 rounded-full bg-[#E6F4FC]"><div className="h-full rounded-full" style={{ width: `${Math.min(100, pct * 2)}%`, background: `linear-gradient(90deg, ${CYAN}, #3AC6FF)` }} /></div>
                  </button>
                );
              })}
              {!topItems.length && <p className="py-5 text-center text-xs" style={{ color: MUTED }}>Upload data to see items</p>}
            </div>
          </Panel>

          <Panel className="p-5 xl:col-span-5">
            <div className="mb-2 flex items-center justify-between">
              <h2 className="text-base font-extrabold">Recent transfers</h2>
              <button type="button" onClick={() => onNavigateView('reports', 'movement_summary')} className="text-xs font-bold" style={{ color: '#0B6FB8' }}>View all</button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full min-w-[380px] text-left text-xs">
                <thead>
                  <tr className="border-b text-[10px] uppercase tracking-wide" style={{ borderColor: BORDER, color: MUTED }}>
                    <th className="py-2 pr-2 font-bold">Item</th>
                    <th className="py-2 pr-2 font-bold">From → To</th>
                    <th className="py-2 pr-2 text-right font-bold">Qty</th>
                    <th className="py-2 font-bold">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {recentMoves.map((t) => (
                    <tr key={t.id} className="border-b" style={{ borderColor: '#E1EFF8' }}>
                      <td className="max-w-[110px] truncate py-2 pr-2 font-semibold">{t.weight}</td>
                      <td className="py-2 pr-2"><span className="font-semibold text-rose-600">{t.fromBranch}</span><span className="mx-1.5" style={{ color: MUTED }}>→</span><span className="font-semibold" style={{ color: GREEN }}>{t.toBranch}</span></td>
                      <td className="py-2 pr-2 text-right font-mono font-bold" style={{ color: '#0B6FB8' }}>{t.qty}</td>
                      <td className="py-2"><span className="rounded-full px-2 py-0.5 text-[10px] font-bold" style={{ background: '#E6F4FC', color: '#0B6FB8' }}>{t.priority || t.status || 'OPEN'}</span></td>
                    </tr>
                  ))}
                  {!recentMoves.length && (
                    <tr><td colSpan={4} className="py-8 text-center" style={{ color: MUTED }}>No transfer orders yet — upload stock + sold</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          </Panel>
        </div>
      </div>
    </div>
  );
};
