import React, { useMemo } from 'react';
import { ArrowDownRight, ArrowUpRight, FileSpreadsheet, Grid3X3, Package, Store } from 'lucide-react';
import { RedistributionReport } from '../types';
import {
  getBranchDisplayName,
  isOnlineBranch,
  isExcludedOutlet,
  isWarehouseBranchCode,
} from '../utils/dataIdentityEngine';
import { exportStyledRowsExcel } from '../utils/styledReportExport';

interface OutletDesignMatrixReportProps {
  report: RedistributionReport;
  onSelectBranch?: (branch: string) => void;
  onSelectWeight?: (weight: string) => void;
}

type MatrixCell = RedistributionReport['matrix']['cells'][string][string];

const isWarehouse = (branch: string) => isWarehouseBranchCode(branch);

const splitItemKey = (key: string) => {
  const parts = String(key || '').split(' · ');
  if (parts.length >= 2) {
    return { carat: parts[0].trim(), design: parts.slice(1).join(' · ').trim() };
  }
  return { carat: String(key || '').trim(), design: '' };
};

const fmt = (value: number) => Math.round(Number(value || 0)).toLocaleString();

export const OutletDesignMatrixReport: React.FC<OutletDesignMatrixReportProps> = ({
  report,
  onSelectBranch,
  onSelectWeight,
}) => {
  const weights = useMemo(() => {
    return report.matrix.weights.filter((w) => {
      const totalSold = report.matrix.branches.reduce(
        (sum, branch) => sum + Number(report.matrix.cells[branch]?.[w]?.sold || 0),
        0,
      );
      const totalStock = report.matrix.branches.reduce(
        (sum, branch) => sum + Number(report.matrix.cells[branch]?.[w]?.stock || 0),
        0,
      );
      return totalSold > 0 || totalStock > 0;
    });
  }, [report]);

  const outlets = useMemo(
    () =>
      report.matrix.branches.filter(
        (branch) =>
          !isWarehouse(branch) &&
          !isOnlineBranch(branch) &&
          !isExcludedOutlet(branch),
      ),
    [report.matrix.branches],
  );

  const designMode = weights.some((w) => String(w).includes(' · '));
  const itemUnit = report.categoryConfig?.itemUnit || 'units';
  const dimensionLabel = report.categoryConfig?.itemLabel || 'Cts';

  const itemTotals = useMemo(() => {
    const result: Record<string, { sold: number; stock: number; move: number }> = {};
    weights.forEach((weight) => {
      let sold = 0;
      let stock = 0;
      let move = 0;
      outlets.forEach((outlet) => {
        const cell = report.matrix.cells[outlet]?.[weight];
        sold += Number(cell?.sold || 0);
        stock += Number(cell?.stock || 0);
        move += Number(cell?.netMove || 0);
      });
      result[weight] = { sold, stock, move };
    });
    return result;
  }, [weights, outlets, report.matrix.cells]);

  const outletTotals = useMemo(() => {
    return outlets.map((outlet) => {
      let sold = 0;
      let stock = 0;
      let move = 0;
      weights.forEach((weight) => {
        const cell = report.matrix.cells[outlet]?.[weight];
        sold += Number(cell?.sold || 0);
        stock += Number(cell?.stock || 0);
        move += Number(cell?.netMove || 0);
      });
      return { outlet, sold, stock, move };
    });
  }, [outlets, weights, report.matrix.cells]);

  const retailStock = outletTotals.reduce((sum, row) => sum + row.stock, 0);
  const retailSold = outletTotals.reduce((sum, row) => sum + row.sold, 0);
  const retailMove = outletTotals.reduce((sum, row) => sum + row.move, 0);
  const warehouseStock = weights.reduce(
    (sum, weight) => sum + Number(report.matrix.cells['DWL']?.[weight]?.stock || 0),
    0,
  );

  const moveClass = (move: number) =>
    move > 0
      ? 'bg-[#C6EFCE] text-[#006100]'
      : move < 0
        ? 'bg-[#FFC7CE] text-[#9C0006]'
        : 'text-[#64748B] bg-white';

  /** Compact Excel: Sold · Stock · Move only (same software engine as Master Matrix) */
  const handleExportExcel = () => {
    const lead = 1; // Outlet column
    const colsPerItem = 3; // Sold, Stock, Move IN/OUT
    const row1: (string | number)[] = ['Outlet'];
    weights.forEach((weight) => {
      const { carat, design } = splitItemKey(weight);
      const label = designMode
        ? `${design || '—'} · ${carat}${itemUnit === 'ct' ? ' ct' : ''}`
        : `${carat}${itemUnit === 'ct' ? ' ct' : ''}`;
      row1.push(label, '', '');
    });
    row1.push('Outlet Total', '', '');

    const row2: (string | number)[] = [''];
    weights.forEach(() => {
      row2.push('Sold', 'Stock', 'Move');
    });
    row2.push('Stock', 'Sold', 'Net');

    const headerMerges: [number, number, number, number][] = [[1, 1, 2, 1]];
    let col = lead + 1;
    const branchGroups: { startCol: number; span: number }[] = [];
    weights.forEach(() => {
      headerMerges.push([1, col, 1, col + colsPerItem - 1]);
      branchGroups.push({ startCol: col, span: colsPerItem });
      col += colsPerItem;
    });
    headerMerges.push([1, col, 1, col + 2]);
    branchGroups.push({ startCol: col, span: 3 });

    const movementCols = weights.map((_, wi) => lead + wi * colsPerItem + 3);
    movementCols.push(lead + weights.length * colsPerItem + 3);

    const rows: (string | number)[][] = outlets.map((outlet) => {
      const values: (string | number)[] = [getBranchDisplayName(outlet)];
      weights.forEach((weight) => {
        const cell = report.matrix.cells[outlet]?.[weight] as MatrixCell | undefined;
        values.push(
          Number(cell?.sold || 0),
          Number(cell?.stock || 0),
          Number(cell?.netMove || 0),
        );
      });
      const total = outletTotals.find((row) => row.outlet === outlet);
      values.push(total?.stock || 0, total?.sold || 0, total?.move || 0);
      return values;
    });

    void exportStyledRowsExcel(
      [
        {
          name: 'Outlet Design Matrix',
          title: 'Outlet × Cts / Design Matrix',
          period: report.period || undefined,
          modeLabel: designMode ? 'Design × Cts' : dimensionLabel,
          headerRows: [row1, row2],
          headerMerges,
          rows,
          movementCols,
          branchGroups,
          freezeCols: 1,
          columnWidths: [18, 10, 10, 10],
        },
      ],
      'DiaMatrix_Outlet_Design_Matrix.xlsx',
    ).catch((error) => {
      console.error(error);
      window.alert(
        `Excel export failed: ${error instanceof Error ? error.message : 'Please try again.'}`,
      );
    });
  };

  return (
    <div className="bg-white border border-[#CFE6F5] rounded-xl shadow-sm overflow-hidden">
      <div className="px-4 sm:px-5 py-3 border-b border-[#DCECF7] bg-[#F6FAFD] flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-[#E6F4FC] border border-[#B8DDF2] text-[#0C94D0] flex items-center justify-center">
            <Grid3X3 className="w-4.5 h-4.5" />
          </div>
          <div>
            <h2 className="text-base sm:text-lg font-black text-[#0B2545]">Outlet × Cts / Design Matrix</h2>
            <p className="text-[11px] text-[#64748B] mt-0.5">
              Outlet is fixed on the left; Cts / Design columns run across like the Excel matrix.
            </p>
          </div>
        </div>
        <button
          type="button"
          onClick={handleExportExcel}
          className="inline-flex items-center gap-2 px-3 py-2 rounded-lg bg-[#0B2545] hover:bg-[#0D9488] text-white text-xs font-extrabold shadow-sm"
        >
          <FileSpreadsheet className="w-3.5 h-3.5" />
          Export Matrix Excel
        </button>
      </div>

      <div className="px-4 py-3 border-b border-[#DCECF7] bg-white flex flex-wrap gap-2 text-[10px] font-bold">
        <div className="inline-flex items-center gap-2 rounded-lg border border-[#CFE6F5] bg-[#F6FAFD] px-3 py-2 text-[#36516B]">
          <Store className="w-3.5 h-3.5 text-[#0C94D0]" />
          {outlets.length} outlets
        </div>
        <div className="inline-flex items-center gap-2 rounded-lg border border-[#CFE6F5] bg-[#F6FAFD] px-3 py-2 text-[#36516B]">
          <Package className="w-3.5 h-3.5 text-[#0C94D0]" />
          {weights.length} {designMode ? 'Cts / Design combinations' : dimensionLabel}
        </div>
        <div className="inline-flex items-center gap-2 rounded-lg border border-[#CFE6F5] bg-[#F6FAFD] px-3 py-2 text-[#36516B]">
          Retail Stock <strong className="text-[#0B2545]">{fmt(retailStock)}</strong>
        </div>
        <div className="inline-flex items-center gap-2 rounded-lg border border-[#CFE6F5] bg-[#F6FAFD] px-3 py-2 text-[#36516B]">
          Retail Sold <strong className="text-[#0C94D0]">{fmt(retailSold)}</strong>
        </div>
        <div className="inline-flex items-center gap-2 rounded-lg border border-[#CFE6F5] bg-[#F6FAFD] px-3 py-2 text-[#36516B]">
          DWL Reserve <strong className="text-[#0B2545]">{fmt(warehouseStock)}</strong>
        </div>
      </div>

      <div className="overflow-auto max-h-[620px]">
        <table className="w-max min-w-full text-[10px] border-collapse font-sans table-fixed">
          <thead className="sticky top-0 z-30 shadow-sm">
            <tr className="bg-[#DFF2FC] text-[#0B2545]">
              <th rowSpan={2} className="sticky left-0 z-40 bg-[#DFF2FC] border border-[#B9D9EC] px-2 py-1.5 text-left font-black w-[120px] min-w-[120px] max-w-[140px]">
                Outlet
              </th>
              {weights.map((weight) => {
                const { carat, design } = splitItemKey(weight);
                return (
                  <th key={weight} colSpan={3} className="border border-[#B9D9EC] px-1 py-1.5 text-center font-black min-w-[150px] max-w-[180px]">
                    <button
                      type="button"
                      onClick={() => onSelectWeight?.(weight)}
                      className="hover:text-[#0D9488] transition-colors truncate max-w-[170px]"
                      title={`View ${design || carat}`}
                    >
                      {designMode ? `${design || '—'} · ${carat}${itemUnit === 'ct' ? ' ct' : ''}` : `${carat}${itemUnit === 'ct' ? ' ct' : ''}`}
                    </button>
                  </th>
                );
              })}
              <th colSpan={3} className="border border-[#B9D9EC] bg-[#EAF6FC] px-1.5 py-1.5 text-center font-black min-w-[132px]">
                Total
              </th>
            </tr>
            <tr className="bg-[#EDF8FD] text-[#36516B]">
              {weights.flatMap((weight) => [
                <th key={`${weight}-sold`} className="border border-[#C8E2EF] px-1 py-1 min-w-[48px] w-[48px]">Sold</th>,
                <th key={`${weight}-stock`} className="border border-[#C8E2EF] px-1 py-1 min-w-[48px] w-[48px]">Stock</th>,
                <th key={`${weight}-move`} className="border border-[#C8E2EF] px-1 py-1 min-w-[52px] w-[52px]">Move</th>,
              ])}
              <th className="border border-[#C8E2EF] px-1 py-1 min-w-[44px]">Stk</th>
              <th className="border border-[#C8E2EF] px-1 py-1 min-w-[44px]">Sold</th>
              <th className="border border-[#C8E2EF] px-1 py-1 min-w-[44px]">Net</th>
            </tr>
          </thead>

          <tbody>
            {outletTotals.map(({ outlet, sold: outletSold, stock: outletStock, move: outletMove }) => (
              <tr key={outlet} className="hover:bg-[#F6FBFE] transition-colors">
                <td className="sticky left-0 z-20 bg-white border border-[#D5E5EF] px-2 py-1 font-black text-[#0B2545] w-[120px] min-w-[120px] max-w-[140px]">
                  <button
                    type="button"
                    onClick={() => onSelectBranch?.(outlet)}
                    className="text-left hover:text-[#0D9488] transition-colors truncate max-w-[130px] text-[10px]"
                    title={`Open ${outlet}`}
                  >
                    {getBranchDisplayName(outlet)}
                  </button>
                </td>

                {weights.map((weight) => {
                  const cell = report.matrix.cells[outlet]?.[weight] as MatrixCell | undefined;
                  const sold = Number(cell?.sold || 0);
                  const stock = Number(cell?.stock || 0);
                  const move = Number(cell?.netMove || 0);
                  return (
                    <React.Fragment key={`${outlet}-${weight}`}>
                      <td className="border border-[#D5E5EF] px-1 py-1 text-right font-mono font-bold text-[#1E293B] tabular-nums">{fmt(sold)}</td>
                      <td className="border border-[#D5E5EF] px-1 py-1 text-right font-mono font-bold text-[#334155] tabular-nums">{fmt(stock)}</td>
                      <td className={`border border-[#D5E5EF] px-1 py-1 text-right font-mono font-black tabular-nums ${moveClass(move)}`}>
                        <span className="inline-flex items-center justify-end gap-0.5">
                          {move > 0 ? <ArrowUpRight className="w-2.5 h-2.5" /> : move < 0 ? <ArrowDownRight className="w-2.5 h-2.5" /> : null}
                          {move > 0 ? `+${fmt(move)}` : fmt(move)}
                        </span>
                      </td>
                    </React.Fragment>
                  );
                })}

                <td className="border border-[#BFD6E4] bg-[#F1F7FB] px-1 py-1 text-right font-mono font-black text-[#0B2545] tabular-nums">{fmt(outletStock)}</td>
                <td className="border border-[#BFD6E4] bg-[#F1F7FB] px-1 py-1 text-right font-mono font-black text-[#0D9488] tabular-nums">{fmt(outletSold)}</td>
                <td className={`border border-[#BFD6E4] px-1 py-1 text-right font-mono font-black tabular-nums ${moveClass(outletMove)}`}>
                  {outletMove > 0 ? `+${fmt(outletMove)}` : fmt(outletMove)}
                </td>
              </tr>
            ))}
          </tbody>

          <tfoot>
            <tr className="bg-[#E7EEF3] font-black text-[#0B2545]">
              <td className="sticky left-0 z-20 bg-[#E7EEF3] border border-[#B9C9D4] px-2 py-1.5 text-[10px]">TOTAL</td>
              {weights.map((weight) => {
                const total = itemTotals[weight] || { sold: 0, stock: 0, move: 0 };
                return (
                  <React.Fragment key={`total-${weight}`}>
                    <td className="border border-[#C5D4DE] px-1 py-1 text-right font-mono tabular-nums">{fmt(total.sold)}</td>
                    <td className="border border-[#C5D4DE] px-1 py-1 text-right font-mono tabular-nums">{fmt(total.stock)}</td>
                    <td className={`border border-[#C5D4DE] px-1 py-1 text-right font-mono tabular-nums ${moveClass(total.move)}`}>
                      {total.move > 0 ? `+${fmt(total.move)}` : fmt(total.move)}
                    </td>
                  </React.Fragment>
                );
              })}
              <td className="border border-[#B9C9D4] px-1 py-1 text-right font-mono tabular-nums">{fmt(retailStock)}</td>
              <td className="border border-[#B9C9D4] px-1 py-1 text-right font-mono text-[#0D9488] tabular-nums">{fmt(retailSold)}</td>
              <td className={`border border-[#B9C9D4] px-1 py-1 text-right font-mono tabular-nums ${moveClass(retailMove)}`}>
                {retailMove > 0 ? `+${fmt(retailMove)}` : fmt(retailMove)}
              </td>
            </tr>
          </tfoot>
        </table>
      </div>
    </div>
  );
};
