import React, { useEffect, useMemo, useState } from 'react';
import {
  Building2,
  Calendar,
  FileSpreadsheet,
  Filter,
  Gem,
  Layers,
  PackagePlus,
  ArrowRightLeft,
  Flame,
  Sparkles,
  Search,
  X,
  BarChart3,
  Package,
  TrendingUp,
  Warehouse,
  LayoutGrid,
  Gauge,
} from 'lucide-react';
import { RawInventoryRecord } from '../types';
import { ReportFilters, EMPTY_FILTERS, parseCaratValue, applyReportFilters } from './ReportFilterBar';
import { calculateRedistributionReport } from '../utils/redistributionEngine';
import type { AllocationMode, SalesTimeframe, SpecialMonth } from '../types';
import { downloadExecutionWorkbook, downloadExecutionPdf, saveExecutionReportsToFolder, type ExecutionReportMode } from '../utils/executionReportExport';
import { BRAND } from '../brand';

export type ReportKey =
  | 'refill_demand'
  | 'excel_sheet'
  | 'outlet_design_matrix'
  | 'movement_summary'
  | 'branches'
  | 'weights'
  | 'demand_booster'
  | 'ai_crossmatch'
  | 'execution'
  | 'stock_turn_rate';

interface AllReportsHubProps {
  rawRecords: RawInventoryRecord[];
  filters: ReportFilters;
  onFiltersChange: (f: ReportFilters) => void;
  period: string;
  activeReport: ReportKey;
  onSelectReport: (key: ReportKey, mode?: 'manual' | 'ai') => void;
  filteredCount: number;
  totalCount: number;
  selectedTimeframe: SalesTimeframe;
  specialMonths?: SpecialMonth[];
}

type ReportBtn = {
  key: ReportKey;
  label: string;
  hint?: string;
  mode?: 'manual' | 'ai';
  icon: React.ReactNode;
};

const STOCK_REPORTS: ReportBtn[] = [
  { key: 'outlet_design_matrix', label: 'Outlet × Cts / Design', hint: 'Outlet on left', icon: <LayoutGrid className="w-3.5 h-3.5" /> },
  { key: 'excel_sheet', label: 'Stock Matrix', hint: 'Branch × Range', icon: <FileSpreadsheet className="w-3.5 h-3.5" /> },
  { key: 'branches', label: 'Branch Balances', hint: 'Outlet stock', icon: <Building2 className="w-3.5 h-3.5" /> },
  { key: 'weights', label: 'Design / Range Stk', hint: 'Style analysis', icon: <Gem className="w-3.5 h-3.5" /> },
  { key: 'refill_demand', label: 'Refill / Shortage', hint: 'Stock gaps', icon: <PackagePlus className="w-3.5 h-3.5" /> },
  { key: 'stock_turn_rate', label: 'Stock Turn Rate', hint: 'Sales ÷ Stock ranking', icon: <Gauge className="w-3.5 h-3.5" /> },
];

const SOLD_REPORTS: ReportBtn[] = [
  { key: 'outlet_design_matrix', label: 'Outlet × Cts / Design', hint: 'Sales by outlet', icon: <TrendingUp className="w-3.5 h-3.5" /> },
  { key: 'excel_sheet', label: 'Sales Matrix', hint: 'Sold × outlet', icon: <TrendingUp className="w-3.5 h-3.5" /> },
  { key: 'movement_summary', label: 'Movement Dispatch', hint: 'Transfer lines', icon: <ArrowRightLeft className="w-3.5 h-3.5" /> },
  { key: 'demand_booster', label: 'Opportunity Booster', hint: 'Demand lift', icon: <Flame className="w-3.5 h-3.5" /> },
  { key: 'weights', label: 'Design Sales', hint: 'Velocity', icon: <BarChart3 className="w-3.5 h-3.5" /> },
];

const DISTRIBUTION_REPORTS: ReportBtn[] = [
  { key: 'outlet_design_matrix', label: 'Outlet × Cts / Design', hint: 'Transposed matrix', icon: <LayoutGrid className="w-3.5 h-3.5" /> },
  { key: 'execution', label: 'Distribution Execution', hint: 'Contribution · 3M · Hybrid', icon: <ArrowRightLeft className="w-3.5 h-3.5" /> },
  { key: 'stock_turn_rate', label: 'Stock Turn Rate', hint: 'Fast / slow outlet ranking', icon: <Gauge className="w-3.5 h-3.5" /> },
  { key: 'branches', label: 'Branch Distribution', hint: 'Stock × sold by outlet', icon: <Building2 className="w-3.5 h-3.5" /> },
  { key: 'movement_summary', label: 'Stock Movement Gap', hint: 'Move in / move out', icon: <ArrowRightLeft className="w-3.5 h-3.5" /> },
  { key: 'refill_demand', label: 'Distribution Shortage', hint: 'Transfer vs new buy', icon: <PackagePlus className="w-3.5 h-3.5" /> },
  { key: 'weights', label: 'Velocity Distribution', hint: 'Best / steady / slow', icon: <TrendingUp className="w-3.5 h-3.5" /> },
  { key: 'excel_sheet', label: 'Stock × Sold Matrix', hint: 'Item × outlet distribution', icon: <LayoutGrid className="w-3.5 h-3.5" /> },
];

const EXECUTION_REPORTS: ReportBtn[] = [
  { key: 'execution', label: 'Execution Report', hint: 'Contribution · 3M Baseline · Hybrid', icon: <ArrowRightLeft className="w-3.5 h-3.5" /> },
];

const ANALYSIS_REPORTS: ReportBtn[] = [
  { key: 'ai_crossmatch', label: 'AI Crossmatch', hint: 'AI briefing', mode: 'ai', icon: <Sparkles className="w-3.5 h-3.5" /> },
  { key: 'stock_turn_rate', label: 'Stock Turn Rate', hint: 'Outlet velocity ranking', icon: <Gauge className="w-3.5 h-3.5" /> },
  { key: 'excel_sheet', label: 'Full Workbook', hint: 'Export hub', icon: <LayoutGrid className="w-3.5 h-3.5" /> },
  { key: 'refill_demand', label: 'Procurement Gap', hint: 'New buy', icon: <Package className="w-3.5 h-3.5" /> },
  { key: 'branches', label: 'Warehouse (DWL)', hint: 'Central stock', icon: <Warehouse className="w-3.5 h-3.5" /> },
];

const fieldCls =
  'h-8 w-full border border-[#89919a] bg-white px-2 text-[12px] text-[#32363a] focus:outline-none focus:border-[#0B6FB8] focus:ring-1 focus:ring-[#0B6FB8]/25';

/**
 * All Reports hub — filter strip inspired by legacy Stock & Sold Report
 * (Branch, S.Branch, Main/Sub category, Range, Date, Style) + report buttons below.
 */
export const AllReportsHub: React.FC<AllReportsHubProps> = ({
  rawRecords,
  filters,
  onFiltersChange,
  period,
  activeReport,
  onSelectReport,
  filteredCount,
  totalCount,
  selectedTimeframe,
  specialMonths = [],
}) => {
  const [draft, setDraft] = useState<ReportFilters>(filters);
  const [sBranch, setSBranch] = useState('');
  const [savingExecutionReports, setSavingExecutionReports] = useState(false);
  const [executionMessage, setExecutionMessage] = useState('');

  useEffect(() => {
    setDraft(filters);
  }, [filters]);

  const branchOptions = useMemo(() => {
    const set = new Set<string>();
    rawRecords.forEach((r) => {
      if (r.branch) set.add(r.branch);
    });
    return Array.from(set).sort((a, b) => a.localeCompare(b));
  }, [rawRecords]);

  const categoryOptions = useMemo(() => {
    const set = new Set<string>();
    rawRecords.forEach((r) => {
      if (r.category) set.add(r.category);
    });
    return Array.from(set).sort((a, b) => a.localeCompare(b));
  }, [rawRecords]);

  const rangeOptions = useMemo(() => {
    const set = new Set<string>();
    rawRecords.forEach((r) => {
      if (r.weight) {
        const base = String(r.weight).split('·')[0].trim();
        if (base) set.add(base);
      }
    });
    return Array.from(set).sort((a, b) => {
      const na = parseCaratValue(a);
      const nb = parseCaratValue(b);
      if (na != null && nb != null) return na - nb;
      return a.localeCompare(b);
    });
  }, [rawRecords]);

  const styleOptions = useMemo(() => {
    const set = new Set<string>();
    rawRecords.forEach((r) => {
      const c = (r.itemCode || r.variant || '').trim();
      if (c) set.add(c);
    });
    return Array.from(set).sort((a, b) => a.localeCompare(b));
  }, [rawRecords]);

  const executionRecords = useMemo(() => applyReportFilters(rawRecords, filters), [rawRecords, filters]);
  const executionDesignMode = !!filters.subCategory.trim();
  const executionPreserveTrailingS = /^[a-zA-Z]{2,4}s$/i.test(filters.branchId.trim());
  const executionReports = useMemo(() => {
    const make = (mode: AllocationMode) => calculateRedistributionReport(
      executionRecords,
      period,
      undefined,
      undefined,
      undefined,
      selectedTimeframe,
      mode,
      specialMonths,
      executionDesignMode,
      executionPreserveTrailingS,
    );
    return {
      contribution: make('contribution'),
      baseline: make('baseline'),
      hybrid: make('hybrid'),
      liquidity: make('liquidity'),
      demand_backup: make('demand_backup'),
      coverage: make('coverage'),
    };
  }, [executionRecords, period, selectedTimeframe, specialMonths, executionDesignMode, executionPreserveTrailingS]);

  const executionModeLabel = (mode: ExecutionReportMode) =>
    mode === 'contribution' ? 'Contribution'
    : mode === 'baseline' ? '3-Month Baseline'
    : mode === 'hybrid' ? 'Hybrid'
    : mode === 'liquidity' ? 'Capital Liquidity'
    : mode === 'demand_backup' ? 'Demand-Backup & Safety'
    : 'Universal Coverage';

  const downloadExecution = async (mode: ExecutionReportMode) => {
    const label = executionModeLabel(mode);
    setExecutionMessage(`${label} Excel is being generated…`);
    try {
      await downloadExecutionWorkbook(executionReports[mode], mode);
      setExecutionMessage(`${label} Excel report generated.`);
    } catch (error) {
      setExecutionMessage(error instanceof Error ? error.message : `${label} Excel export failed.`);
    }
  };

  const downloadExecutionPdfFile = async (mode: ExecutionReportMode) => {
    const label = executionModeLabel(mode);
    setExecutionMessage(`${label} PDF is being generated…`);
    try {
      await downloadExecutionPdf(executionReports[mode], mode);
      setExecutionMessage(`${label} PDF report generated.`);
    } catch (error) {
      setExecutionMessage(error instanceof Error ? error.message : `${label} PDF export failed.`);
    }
  };

  const saveAllExecutionReports = async () => {
    setSavingExecutionReports(true);
    setExecutionMessage('');
    try {
      await saveExecutionReportsToFolder(executionReports);
      setExecutionMessage('Execution Report folder saved with all 5 independent Excel files.');
    } catch (error) {
      setExecutionMessage(error instanceof Error ? error.message : 'Folder save was cancelled.');
    } finally {
      setSavingExecutionReports(false);
    }
  };

  const applyFilters = () => {
    // S.Branch exact → use as branch filter (individual S outlet)
    const next = { ...draft };
    if (sBranch.trim()) {
      next.branchId = sBranch.trim().toUpperCase();
    }
    onFiltersChange(next);
  };

  const clearFilters = () => {
    setDraft(EMPTY_FILTERS);
    setSBranch('');
    onFiltersChange(EMPTY_FILTERS);
  };

  const onKey = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') applyFilters();
  };

  const btnClass = (key: ReportKey, mode?: 'manual' | 'ai') => {
    const active =
      activeReport === key &&
      (mode === 'ai' ? key === 'ai_crossmatch' : key !== 'ai_crossmatch' || activeReport === key);
    const isAi = mode === 'ai' || key === 'ai_crossmatch';
    const base = 'rounded-xl transition-all duration-200 hover:-translate-y-0.5';
    if (active && isAi) {
      return `${base} bg-violet-600 text-white border-violet-700 shadow-[0_1px_0_rgba(255,255,255,0.2)_inset,0_6px_0_#5b21b6,0_12px_24px_rgba(109,40,217,0.35)]`;
    }
    if (active) {
      return `${base} bg-[#DDF2FF] text-[#0B2545] border-[#62BCEB] shadow-[0_4px_14px_rgba(20,180,232,0.18)] ring-1 ring-[#A9D9F0]`;
    }
    if (isAi) {
      return `${base} bg-violet-50 text-violet-800 border-violet-200 hover:bg-violet-100 shadow-[0_1px_0_#fff_inset,0_4px_12px_rgba(109,40,217,0.12)]`;
    }
    return `${base} bg-gradient-to-b from-white to-[#F0F9FF] text-[#0A1628] border-[#A9D9F0] hover:border-[#14B4E8] shadow-[0_1px_0_#fff_inset,0_4px_14px_rgba(20,180,232,0.12)]`;
  };

  const renderGroup = (title: string, items: ReportBtn[]) => (
    <div className="space-y-1.5">
      <div className="text-[10px] font-extrabold uppercase tracking-wider text-[#0A1628] px-0.5">
        {title}
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
        {items.map((item) => (
          <button
            key={`${title}-${item.key}-${item.label}`}
            type="button"
            onClick={() => onSelectReport(item.key, item.mode)}
            className={`text-left border px-2.5 py-2.5 ${btnClass(
              item.key,
              item.mode
            )}`}
          >
            <div className="flex items-center gap-1.5 text-[12px] font-bold">
              {item.icon}
              <span className="truncate">{item.label}</span>
            </div>
            {item.hint && (
              <div className="text-[10px] font-semibold mt-0.5 truncate opacity-100">{item.hint}</div>
            )}
          </button>
        ))}
      </div>
    </div>
  );

  return (
    <div className="space-y-3">
      {activeReport === 'execution' && (
        <div className="rounded-xl border border-[#cbd5e1] bg-white shadow-[0_10px_28px_rgba(10,15,29,0.10)] overflow-hidden">
          <div className="bg-[#E6F4FC] px-3 py-2.5 text-[#0B2545] border-b border-[#CFE6F5] flex items-center justify-between">
            <div>
              <div className="text-sm font-extrabold">Execution Report</div>
              <div className="text-[10px] text-[#4F6B88] mt-0.5">Important distribution report · choose one calculation method</div>
            </div>
            <button type="button" onClick={saveAllExecutionReports} disabled={savingExecutionReports} className="rounded-lg bg-[#14B4E8] text-white px-3 py-2 text-[11px] font-extrabold shadow-[0_4px_0_#0B8FBA] hover:-translate-y-0.5 disabled:opacity-60">
              {savingExecutionReports ? 'Saving…' : 'Save All 6 Reports'}
            </button>
          </div>
          <div className="px-3 pt-3 text-[10px] font-semibold text-[#475569]">
            Category-wise execution options: Contribution, 3M Baseline, Hybrid, Liquidity, Demand-Backup and Coverage are calculated independently from the same filtered dataset.
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5 p-3 bg-[#F4F6F9]">
            {([
              ['contribution', 'Contribution', 'Full pool by sales share (high→more)', '#2A75D3'],
              ['baseline', '3-Month Baseline', 'Velocity / baseline target', '#0F4C81'],
              ['hybrid', 'Hybrid', 'Higher of contribution vs baseline', '#E6A100'],
              ['liquidity', 'Capital Liquidity', 'Sales ÷ aging; scale if >90d', '#0B6E4F'],
              ['demand_backup', 'Demand-Backup', '3M + 20% HP + stock-out safety', '#7C3AED'],
              ['coverage', 'Universal Coverage', 'Every outlet ≥1 pc; rest by sales', '#BE123C'],
            ] as const).map(([mode, label, hint, accent]) => (
              <div key={mode} className="rounded-xl border border-[#d7dde5] bg-white p-3 shadow-[0_5px_0_#dbe2ea,0_12px_22px_rgba(10,15,29,0.08)]">
                <div className="flex items-center justify-between">
                  <div className="font-extrabold text-[#0A0F1D] text-xs">{label}</div>
                  <span className="h-2.5 w-2.5 rounded-full" style={{ background: accent }} />
                </div>
                <div className="text-[10px] text-[#475569] mt-1">{hint}</div>
                <div className="grid grid-cols-2 gap-2 mt-3">
                  <button type="button" onClick={() => void downloadExecution(mode)} className="rounded-lg bg-[#E6F4FC] border border-[#A9D9F0] text-[#0B6FB8] px-2 py-2 text-[10px] font-extrabold hover:bg-[#D7F0FF] hover:-translate-y-0.5">
                    Export Excel
                  </button>
                  <button type="button" onClick={() => void downloadExecutionPdfFile(mode)} className="rounded-lg bg-white border border-[#A9D9F0] text-[#0F4C81] px-2 py-2 text-[10px] font-extrabold hover:bg-[#F4F9FC] hover:-translate-y-0.5">
                    Export PDF
                  </button>
                </div>
              </div>
            ))}
          </div>
          {executionMessage && <div className="px-3 pb-3 text-[10px] font-semibold text-[#0F4C81]">{executionMessage}</div>}
        </div>
      )}
      {/* Title bar like legacy "Stock & Sold Report" */}
      <div className="bg-[#E6F4FC] text-[#0B2545] px-3 py-2.5 rounded-t-xl border border-[#CFE6F5] flex items-center justify-between shadow-[0_1px_0_rgba(255,255,255,0.12)_inset,0_8px_24px_rgba(6,16,31,0.35)]">
        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-[#14B4E8]" />
          <h2 className="text-sm font-bold tracking-wide">
            {BRAND.short} Reports — Filter &amp; Options
          </h2>
        </div>
        <div className="text-[11px] text-[#4F6B88] font-mono font-semibold">
          {filteredCount.toLocaleString()} / {totalCount.toLocaleString()} rows
          {period ? ` · ${period}` : ''}
        </div>
      </div>

      {/* Filter panel — legacy field layout, modern styling */}
      <div className="bg-[#edf0f4] border border-[#d0d7de] border-t-0 rounded-b px-3 py-3 space-y-2.5">
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-2">
          {/* Branch ID */}
          <label className="block text-[10px] font-bold text-[#0A1628] space-y-0.5">
            <span className="font-semibold">Branch ID</span>
            <input
              list="allrep-branch"
              value={draft.branchId}
              onChange={(e) => setDraft({ ...draft, branchId: e.target.value })}
              onKeyDown={onKey}
              placeholder="BCT, MOH…"
              className={fieldCls}
            />
            <datalist id="allrep-branch">
              {branchOptions.map((b) => (
                <option key={b} value={b} />
              ))}
            </datalist>
          </label>

          {/* S.Branch ID — exact trailing-S outlet */}
          <label className="block text-[10px] font-bold text-[#0A1628] space-y-0.5">
            <span className="font-semibold">S.Branch ID</span>
            <input
              list="allrep-sbranch"
              value={sBranch}
              onChange={(e) => setSBranch(e.target.value)}
              onKeyDown={onKey}
              placeholder="BCTS, MOHS…"
              className={fieldCls}
            />
            <datalist id="allrep-sbranch">
              {branchOptions
                .filter((b) => /s$/i.test(b) && b.length <= 5)
                .map((b) => (
                  <option key={b} value={b} />
                ))}
            </datalist>
          </label>

          {/* Main / Category */}
          <label className="block text-[10px] font-bold text-[#0A1628] space-y-0.5 md:col-span-2">
            <span className="font-semibold flex items-center gap-1">
              <Layers className="w-3 h-3" /> Main / Sub Category
            </span>
            <input
              list="allrep-cat"
              value={draft.mainCategory}
              onChange={(e) => setDraft({ ...draft, mainCategory: e.target.value })}
              onKeyDown={onKey}
              placeholder="D.RING, D.Ladies Generic Ring…"
              className={fieldCls}
            />
            <datalist id="allrep-cat">
              {categoryOptions.map((c) => (
                <option key={c} value={c} />
              ))}
            </datalist>
          </label>

          {/* Style / Design */}
          <label className="block text-[10px] font-bold text-[#0A1628] space-y-0.5 md:col-span-2">
            <span className="font-semibold flex items-center gap-1">
              <Gem className="w-3 h-3" /> Style / Design Name
            </span>
            <input
              list="allrep-style"
              value={draft.subCategory}
              onChange={(e) => setDraft({ ...draft, subCategory: e.target.value })}
              onKeyDown={onKey}
              placeholder="NP7SD1…"
              className={fieldCls}
            />
            <datalist id="allrep-style">
              {styleOptions.map((s) => (
                <option key={s} value={s} />
              ))}
            </datalist>
          </label>

          {/* Range / Cts From */}
          <label className="block text-[10px] font-bold text-[#0A1628] space-y-0.5">
            <span className="font-semibold">Range / Cts From</span>
            <input
              list="allrep-from"
              value={draft.ctsFrom}
              onChange={(e) => setDraft({ ...draft, ctsFrom: e.target.value })}
              onKeyDown={onKey}
              placeholder="K30 or 0.30"
              className={fieldCls}
            />
            <datalist id="allrep-from">
              {rangeOptions.map((c) => (
                <option key={`f-${c}`} value={c} />
              ))}
            </datalist>
          </label>

          {/* Range / Cts To */}
          <label className="block text-[10px] font-bold text-[#0A1628] space-y-0.5">
            <span className="font-semibold">Range / Cts To</span>
            <input
              list="allrep-to"
              value={draft.ctsTo}
              onChange={(e) => setDraft({ ...draft, ctsTo: e.target.value })}
              onKeyDown={onKey}
              placeholder="L10 or 1.10"
              className={fieldCls}
            />
            <datalist id="allrep-to">
              {rangeOptions.map((c) => (
                <option key={`t-${c}`} value={c} />
              ))}
            </datalist>
          </label>

          {/* Period (read-only display of upload window) */}
          <label className="block text-[10px] font-bold text-[#0A1628] space-y-0.5 md:col-span-2">
            <span className="font-semibold flex items-center gap-1">
              <Calendar className="w-3 h-3" /> Date / Period (from upload)
            </span>
            <input
              readOnly
              value={period || '—'}
              className={`${fieldCls} bg-[#f1f5f9] text-[#64748b]`}
            />
          </label>
        </div>

        <div className="flex flex-wrap items-center gap-2 pt-1">
          <button
            type="button"
            onClick={applyFilters}
            className="h-8 px-4 bg-[#0B6FB8] hover:bg-[#0B8BD6] text-white text-[12px] font-semibold border border-[#0B6FB8] inline-flex items-center gap-1.5"
          >
            <Search className="w-3.5 h-3.5" />
            Search / Apply Filter
          </button>
          <button
            type="button"
            onClick={clearFilters}
            className="h-8 px-3 bg-white hover:bg-[#f5f6f7] text-[#32363a] text-[12px] font-semibold border border-[#89919a] inline-flex items-center gap-1.5"
          >
            <X className="w-3.5 h-3.5" />
            Clear
          </button>
          <span className="text-[11px] font-semibold text-[#334155]">
            Tip: <strong>S.Branch</strong> = exact MOHS/BCTS only · <strong>Branch</strong> = parent + S combined
          </span>
        </div>
      </div>

      {/* Report option groups — like legacy Stock Report / Sold Report sections */}
      <div className="bg-white border border-[#d0d7de] rounded px-3 py-3 space-y-3">
        {renderGroup('Distribution Analysis', DISTRIBUTION_REPORTS)}
        {renderGroup('Execution Report', EXECUTION_REPORTS)}
        {renderGroup('Stock Report', STOCK_REPORTS)}
        {renderGroup('Sold Report', SOLD_REPORTS)}
        {renderGroup('Analysis & AI', ANALYSIS_REPORTS)}
      </div>
    </div>
  );
};
