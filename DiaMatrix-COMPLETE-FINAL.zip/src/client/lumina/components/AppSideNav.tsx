import React from 'react';
import { BRAND } from '../brand';
import {
  Home,
  Gem,
  ArrowRightLeft,
  PackagePlus,
  Building2,
  FileSpreadsheet,
  Files,
  FolderLock,
  LayoutDashboard,
  Sparkles,
  History,
  Download,
  FileDown,
  Gauge,
  Grid3X3,
} from 'lucide-react';

export interface AppSideNavProps {
  activeView: string;
  activeReport: string;
  onNavigateView: (view: any, report?: any) => void;
  onExportExcel?: () => void;
  onExportPdf?: () => void;
  onOpenUploadHistory?: () => void;
  onOpenDailyUpload?: () => void;
  collapsed?: boolean;
}

type NavItem = {
  id: string;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
  view: string;
  report?: string;
  color?: string;
};

const MAIN: NavItem[] = [
  { id: 'cockpit', label: 'Cockpit', icon: Home, view: 'dashboard' },
  { id: 'option', label: 'Item Allocation Matrix', icon: Gem, view: 'option_allocation' },
  { id: 'aging', label: 'Movement & Aging', icon: ArrowRightLeft, view: 'movement_aging' },
  { id: 'refill', label: 'Refill Demand', icon: PackagePlus, view: 'reports', report: 'refill_demand' },
  { id: 'branches', label: 'Showrooms', icon: Building2, view: 'reports', report: 'branches' },
  { id: 'weights', label: 'Design Analysis', icon: Gem, view: 'reports', report: 'weights' },
  { id: 'matrix', label: 'Master Excel Matrix', icon: FileSpreadsheet, view: 'reports', report: 'excel_sheet' },
  { id: 'outlet_matrix', label: 'Outlet × Cts / Design', icon: Grid3X3, view: 'reports', report: 'outlet_design_matrix' },
  { id: 'all', label: 'All Reports', icon: Files, view: 'reports', report: 'excel_sheet' },
  { id: 'execution', label: 'Execution Report', icon: ArrowRightLeft, view: 'reports', report: 'execution' },
  { id: 'turn_rate', label: 'Stock Turn Rate', icon: Gauge, view: 'reports', report: 'stock_turn_rate' },
  { id: 'ai', label: 'AI Crossmatch', icon: Sparkles, view: 'reports', report: 'ai_crossmatch' },
];

function isActive(item: NavItem, activeView: string, activeReport: string) {
  if (item.view === 'dashboard') {
    return activeView === 'dashboard' || activeView === 'menu';
  }
  if (item.view === 'option_allocation' || item.view === 'movement_aging') {
    return activeView === item.view;
  }
  if (item.report) {
    return activeView === 'reports' && activeReport === item.report;
  }
  return activeView === item.view;
}

export const AppSideNav: React.FC<AppSideNavProps> = ({
  activeView,
  activeReport,
  onNavigateView,
  onExportExcel,
  onExportPdf,
  onOpenUploadHistory,
  onOpenDailyUpload,
}) => {
  const action =
    'w-full flex items-center gap-2 rounded-lg px-3 py-2 text-[11px] font-semibold text-[#4F6B88] hover:bg-[#E6F4FC] hover:text-[#0B2545] transition-colors';
  return (
    <aside className="sw-sidebar hidden md:flex w-[220px] lg:w-[240px] shrink-0 flex-col border-r min-h-0 h-full sticky top-0 self-stretch z-30">
      <div className="flex flex-col items-center px-4 pt-6 pb-4">
        <img
          src="/diamatrix-mark.svg"
          alt={BRAND.short}
          className="w-[120px] h-auto object-contain dmx-logo-3d dmx-logo-spin"
          draggable={false}
        />
        <div className="mt-4 text-[11px] font-extrabold tracking-[0.28em] text-[#0A1628]">WORKSPACE</div>
      </div>

      <nav className="flex-1 overflow-y-auto px-3 py-1 space-y-1">
        {MAIN.map((item) => {
          const active = isActive(item, activeView, activeReport);
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => onNavigateView(item.view, item.report)}
              className={`sw-nav-item group w-full flex items-center gap-2.5 rounded-xl px-3 py-2.5 text-left text-[13px] ${
                item.view === 'reports' ? 'font-extrabold' : 'font-bold'
              } transition-all duration-150 ${
                active ? 'active shadow-[0_4px_14px_rgba(20,180,232,0.18)]' : ''
              }`}
            >
              <Icon className={`w-4 h-4 shrink-0 ${active ? 'text-[#0C94D0]' : 'text-[#5B7A99] group-hover:text-[#0C94D0]'}`} />
              <span className="truncate leading-snug">{item.label}</span>
            </button>
          );
        })}
      </nav>

      <div className="p-3 border-t border-[#E1EFF8] space-y-1">
        {onExportExcel && (
          <button type="button" onClick={onExportExcel} className={action}>
            <Download className="w-3.5 h-3.5 text-[#0C94D0]" />
            Export Excel
          </button>
        )}
        {onExportPdf && (
          <button type="button" onClick={onExportPdf} className={action}>
            <FileDown className="w-3.5 h-3.5 text-[#0C94D0]" />
            Export PDF
          </button>
        )}
        {onOpenUploadHistory && (
          <button type="button" onClick={onOpenUploadHistory} className={action}>
            <History className="w-3.5 h-3.5 text-[#0C94D0]" />
            Upload History
          </button>
        )}
        {onOpenDailyUpload && (
          <button
            type="button"
            onClick={onOpenDailyUpload}
            className="w-full mt-2 inline-flex items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-[#14B4E8] to-[#3AC6FF] px-3 py-2.5 text-[12px] font-bold text-white shadow-md shadow-[#14B4E8]/30 hover:brightness-105"
          >
            <Gem className="w-4 h-4" />
            Daily Intake
          </button>
        )}
      </div>
    </aside>
  );
};
