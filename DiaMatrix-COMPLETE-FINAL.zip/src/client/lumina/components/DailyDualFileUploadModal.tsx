import React, { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import {
  X,
  UploadCloud,
  FileSpreadsheet,
  CheckCircle2,
  AlertCircle,
  Sparkles,
  Layers,
  ArrowRight,
  Database,
  RefreshCw,
  FileText,
  Calendar,
  Check,
  Plus,
  Trash2,
  PartyPopper,
  Download,
} from 'lucide-react';
import { RawInventoryRecord, SpecialMonth, SpecialMonthType } from '../types';
import {
  mergeDualStockAndSoldData,
  mergeMultiFileStockAndSoldData,
  detectDesignFromFileName,
  parseAnyContentToGrid,
  ParsedDataResult,
  UploadFileBlob,
} from '../utils/universalParser';
import { saveDailySnapshot } from '../utils/dailyStorageEngine';
import {
  analyzeHeaders,
  extractHeaderRow,
  needsColumnMapper,
  HeaderAnalysis,
  ColumnMapDict,
} from '../utils/columnMappingEngine';
import { ColumnMapperModal } from './ColumnMapperModal';
import { queueBackgroundMerge } from '../utils/fileProcessingQueue';

interface DailyDualFileUploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onImportRecords: (
    records: RawInventoryRecord[],
    period: string,
    specialMonths?: SpecialMonth[],
    importMode?: 'replace' | 'append'
  ) => void;
  /** Called after import when user chooses AI Mode — parent should open AI Crossmatch view */
  onOpenAiMode?: () => void;
  currentPeriod?: string;
  /** Rows already in IndexedDB / memory — enables Append mode */
  existingRecordCount?: number;
}

const MONTH_OPTIONS = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December'
];

const SPECIAL_TYPE_OPTIONS: SpecialMonthType[] = ['Festival', 'Exhibition', 'Promotion', 'Other'];

// Generic jewelry template for testing the parser. Production data is supplied by upload.
export const SAMPLE_SOLDOUT_MATRIX_TEXT = `Category,Branch,Nosepin-A,Nosepin-B,Earring-A,Earring-B,Finger-Ring-A,Locket-A,Total
Demo Jewelry,Branch-01,2,1,0,1,2,0,6
,Branch-02,1,0,2,0,1,1,5
,Branch-03,0,1,1,0,0,2,4
,Total,3,2,3,1,3,3,15`;

export const SAMPLE_STOCK_MATRIX_TEXT = `Category,Branch,Nosepin-A,Nosepin-B,Earring-A,Earring-B,Finger-Ring-A,Locket-A,Total
Demo Jewelry,Branch-01,5,2,1,3,4,1,16
,Branch-02,1,1,5,2,1,4,14
,Branch-03,0,3,2,1,2,5,13
,Central Warehouse,20,10,15,10,12,18,85
,Total,26,16,23,16,19,28,128`;

function formatDateDDMMYYYY(d: Date): string {
  const dd = String(d.getDate()).padStart(2, '0');
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const yyyy = d.getFullYear();
  return `${dd}-${mm}-${yyyy}`;
}

function toInputDate(d: Date): string {
  return d.toISOString().slice(0, 10);
}

function fromInputDate(s: string): Date {
  const d = new Date(s + 'T12:00:00');
  return isNaN(d.getTime()) ? new Date() : d;
}

/** Enrich dual-upload records with multi-period sales estimates so all report timeframes work. */
function enrichRecordsWithPeriodSales(
  records: RawInventoryRecord[],
  periodDays: number
): RawInventoryRecord[] {
  return records.map((r) => {
    const sold = Number(r.soldQty) || 0;
    // Scale estimates so the uploaded soldQty maps to the selected period window
    const factor3m = periodDays > 0 ? Math.min(1, 90 / periodDays) : 0.4;
    const factor6m = periodDays > 0 ? Math.min(1, 180 / periodDays) : 0.7;
    const factor1y = periodDays > 0 ? Math.min(1, 365 / periodDays) : 1;
    const factor2y = periodDays > 0 ? Math.min(2, 730 / periodDays) : 1.8;
    return {
      ...r,
      sales3M: r.sales3M !== undefined ? r.sales3M : Math.max(0, Math.round(sold * factor3m)),
      sales6M: r.sales6M !== undefined ? r.sales6M : Math.max(0, Math.round(sold * factor6m)),
      sales1Y: r.sales1Y !== undefined ? r.sales1Y : Math.max(0, Math.round(sold * factor1y)),
      sales2Y: r.sales2Y !== undefined ? r.sales2Y : Math.max(0, Math.round(sold * factor2y)),
      ageDays: r.ageDays !== undefined ? r.ageDays : (r.currentStock > 0 && sold === 0 ? 310 : 65)
    };
  });
}

export const DailyDualFileUploadModal: React.FC<DailyDualFileUploadModalProps> = ({
  isOpen,
  onClose,
  onImportRecords,
  onOpenAiMode,
  currentPeriod = 'Last 30 Days',
  existingRecordCount = 0,
}) => {
  const [stockFileName, setStockFileName] = useState('');
  const [stockContent, setStockContent] = useState<string | ArrayBuffer>('');
  const [stockMode, setStockMode] = useState<'upload' | 'paste'>('upload');
  const [stockFiles, setStockFiles] = useState<UploadFileBlob[]>([]);

  const [soldFileName, setSoldFileName] = useState('');
  const [soldContent, setSoldContent] = useState<string | ArrayBuffer>('');
  const [soldMode, setSoldMode] = useState<'upload' | 'paste'>('upload');
  const [soldFiles, setSoldFiles] = useState<UploadFileBlob[]>([]);

  const today = new Date();
  const defaultFrom = new Date(today);
  defaultFrom.setDate(defaultFrom.getDate() - 30);

  const [quickPeriod, setQuickPeriod] = useState<string>('1m');
  const [fromDate, setFromDate] = useState(toInputDate(defaultFrom));
  const [toDate, setToDate] = useState(toInputDate(today));
  const [period, setPeriod] = useState(
    `${formatDateDDMMYYYY(defaultFrom)} to ${formatDateDDMMYYYY(today)}`
  );
  const [errorMsg, setErrorMsg] = useState('');
  const [parsedResult, setParsedResult] = useState<ParsedDataResult | null>(null);
  const [importMode, setImportMode] = useState<'replace' | 'append'>('replace');
  const [mapperAnalysis, setMapperAnalysis] = useState<HeaderAnalysis | null>(null);
  const [mapperFileLabel, setMapperFileLabel] = useState<string>('');
  const [mapperOpen, setMapperOpen] = useState(false);
  const [pendingMerge, setPendingMerge] = useState<{
    stock: UploadFileBlob[];
    sold: UploadFileBlob[];
  } | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [stockDragOver, setStockDragOver] = useState(false);
  const [soldDragOver, setSoldDragOver] = useState(false);

  // Special / Festival / Exhibition / Promotion months
  const [specialMonths, setSpecialMonths] = useState<SpecialMonth[]>([]);
  const [newMonthLabel, setNewMonthLabel] = useState('');
  const [newEventName, setNewEventName] = useState('');
  const [newSpecialType, setNewSpecialType] = useState<SpecialMonthType>('Festival');
  const [newMonthYear, setNewMonthYear] = useState(String(new Date().getFullYear()));

  // Escape closes the nested column mapper first, then the Daily Intake modal.
  useEffect(() => {
    if (!isOpen) return;

    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key !== 'Escape') return;
      event.preventDefault();
      event.stopPropagation();

      if (mapperOpen) {
        setMapperOpen(false);
        return;
      }

      onClose();
    };

    window.addEventListener('keydown', closeOnEscape);
    return () => window.removeEventListener('keydown', closeOnEscape);
  }, [isOpen, mapperOpen, onClose]);

  const handleAddSpecialMonth = () => {
    if (!newMonthLabel.trim() || !newEventName.trim()) return;
    const label = newMonthYear
      ? `${newMonthLabel.trim()} ${newMonthYear.trim()}`
      : newMonthLabel.trim();
    setSpecialMonths((prev) => [
      ...prev,
      {
        id: `sm-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        monthLabel: label,
        eventName: newEventName.trim(),
        type: newSpecialType
      }
    ]);
    setNewEventName('');
    setNewMonthLabel('');
  };

  const handleRemoveSpecialMonth = (id: string) => {
    setSpecialMonths((prev) => prev.filter((m) => m.id !== id));
  };

  // Prefer Append when IndexedDB already has data
  useEffect(() => {
    if (isOpen && existingRecordCount > 0) {
      setImportMode('append');
    } else if (isOpen) {
      setImportMode('replace');
    }
  }, [isOpen, existingRecordCount]);

  // Sync period label when modal opens with currentPeriod
  useEffect(() => {
    if (isOpen && currentPeriod) {
      // Keep existing custom range; only seed if still default-ish
      if (!period || period.includes('Last 30') || period.includes('Daily Update')) {
        const f = new Date(today);
        f.setDate(f.getDate() - 30);
        setFromDate(toInputDate(f));
        setToDate(toInputDate(today));
        setPeriod(`${formatDateDDMMYYYY(f)} to ${formatDateDDMMYYYY(today)}`);
        setQuickPeriod('1m');
      }
    }
  }, [isOpen]);

  const handlePeriodQuickChange = (preset: string) => {
    setQuickPeriod(preset);
    const end = new Date();
    const start = new Date();
    if (preset === '7d') start.setDate(end.getDate() - 7);
    else if (preset === '15d') start.setDate(end.getDate() - 15);
    else if (preset === '1m') start.setMonth(end.getMonth() - 1);
    else if (preset === '3m') start.setMonth(end.getMonth() - 3);
    else if (preset === '6m') start.setMonth(end.getMonth() - 6);
    else if (preset === '9m') start.setMonth(end.getMonth() - 9);
    else if (preset === 'ytd') {
      start.setMonth(0);
      start.setDate(1);
    } else if (preset === 'custom') {
      // keep current from/to; user will edit
      setPeriod(`${formatDateDDMMYYYY(fromInputDate(fromDate))} to ${formatDateDDMMYYYY(fromInputDate(toDate))}`);
      return;
    }
    setFromDate(toInputDate(start));
    setToDate(toInputDate(end));
    setPeriod(`${formatDateDDMMYYYY(start)} to ${formatDateDDMMYYYY(end)}`);
  };

  const handleFromToChange = (from: string, to: string) => {
    setFromDate(from);
    setToDate(to);
    setQuickPeriod('custom');
    setPeriod(
      `${formatDateDDMMYYYY(fromInputDate(from))} to ${formatDateDDMMYYYY(fromInputDate(to))}`
    );
  };

  const getPeriodDays = (): number => {
    const f = fromInputDate(fromDate).getTime();
    const t = fromInputDate(toDate).getTime();
    return Math.max(1, Math.round(Math.abs(t - f) / (1000 * 60 * 60 * 24)));
  };

  if (!isOpen) return null;

  const runMerge = async (
    nextStockFiles: UploadFileBlob[],
    nextSoldFiles: UploadFileBlob[],
    skipMapper = false
  ) => {
    if (nextStockFiles.length === 0 || nextSoldFiles.length === 0) {
      setParsedResult(null);
      return;
    }
    try {
      setIsProcessing(true);
      setErrorMsg('');

      // Column mapper: analyze first stock + sold file headers when not skipping
      if (!skipMapper) {
        const probe = nextStockFiles[0] || nextSoldFiles[0];
        if (probe) {
          try {
            const grid = parseAnyContentToGrid(probe.content, probe.name);
            const { headers } = extractHeaderRow(grid);
            if (headers.filter(Boolean).length > 0) {
              const analysis = analyzeHeaders(headers);
              if (needsColumnMapper(analysis)) {
                setMapperAnalysis(analysis);
                setMapperFileLabel(probe.name || 'uploaded file');
                setPendingMerge({ stock: nextStockFiles, sold: nextSoldFiles });
                setMapperOpen(true);
                setIsProcessing(false);
                return;
              }
            }
          } catch {
            /* fall through to normal parse */
          }
        }
      }

      const result = await queueBackgroundMerge({ stockFiles: nextStockFiles, soldFiles: nextSoldFiles });
      if (result.records.length === 0) {
        // Offer column mapper so user can fix unrecognized ERP headers
        try {
          const probe = nextStockFiles[0] || nextSoldFiles[0];
          if (probe) {
            const grid = parseAnyContentToGrid(probe.content, probe.name);
            const { headers } = extractHeaderRow(grid);
            if (headers.filter(Boolean).length > 0) {
              const analysis = analyzeHeaders(headers);
              setMapperAnalysis(analysis);
              setMapperFileLabel(probe.name || 'uploaded file');
              setPendingMerge({ stock: nextStockFiles, sold: nextSoldFiles });
              setMapperOpen(true);
              setErrorMsg(
                'কলাম অটো-ডিটেক্ট হয়নি — Column Mapper দিয়ে ERP হেডার ম্যাপ করুন (যেমন Outlet_Code → Branch)।'
              );
              setParsedResult(null);
              return;
            }
          }
        } catch {
          /* ignore */
        }
        setErrorMsg(
          'Could not detect valid branch and item records. Check Oracle matrix format (Category, Brnch, carat columns) — or use Column Mapper.'
        );
        setParsedResult(null);
      } else {
        setParsedResult(result);
      }
    } catch (err: any) {
      setErrorMsg(`Error parsing files: ${err.message || 'Check file formatting'}`);
      setParsedResult(null);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleMapperConfirm = (_maps: ColumnMapDict) => {
    setMapperOpen(false);
    setMapperAnalysis(null);
    if (pendingMerge) {
      const { stock, sold } = pendingMerge;
      setPendingMerge(null);
      runMerge(stock, sold, true);
    }
  };

  const handleMapperCancel = () => {
    setMapperOpen(false);
    setMapperAnalysis(null);
    setPendingMerge(null);
  };

  /** Backward-compatible single stock+sold merge (paste mode) */
  const handleProcessMerge = (stock: string | ArrayBuffer, sold: string | ArrayBuffer) => {
    const sFiles: UploadFileBlob[] = stock
      ? [{ name: stockFileName || 'stock.csv', content: stock }]
      : stockFiles;
    const dFiles: UploadFileBlob[] = sold
      ? [{ name: soldFileName || 'sold.csv', content: sold }]
      : soldFiles;
    if (stock) setStockFiles(sFiles);
    if (sold) setSoldFiles(dFiles);
    runMerge(
      stock ? sFiles : stockFiles,
      sold ? dFiles : soldFiles
    );
  };

  const readFileAsBlob = (file: File): Promise<UploadFileBlob> =>
    new Promise((resolve, reject) => {
      const isExcel = file.name.endsWith('.xlsx') || file.name.endsWith('.xls');
      const reader = new FileReader();
      reader.onload = (ev) => {
        resolve({
          name: file.name,
          content: ev.target?.result as string | ArrayBuffer,
        });
      };
      reader.onerror = () => reject(new Error(`Failed to read ${file.name}`));
      if (isExcel) reader.readAsArrayBuffer(file);
      else reader.readAsText(file);
    });

  const isAcceptedUploadFile = (file: File) => {
    const n = file.name.toLowerCase();
    return (
      n.endsWith('.xlsx') ||
      n.endsWith('.xls') ||
      n.endsWith('.csv') ||
      n.endsWith('.txt') ||
      file.type.includes('sheet') ||
      file.type.includes('csv') ||
      file.type.includes('excel')
    );
  };

  const ingestStockFiles = async (fileList: FileList | File[]) => {
    const files = Array.from(fileList).filter(isAcceptedUploadFile);
    if (files.length === 0) {
      setErrorMsg('Only .xlsx / .xls / .csv / .txt files accepted');
      return;
    }
    try {
      const blobs = await Promise.all(files.map(readFileAsBlob));
      setStockFiles((prev) => {
        const map = new Map(prev.map((f) => [f.name, f]));
        blobs.forEach((b) => map.set(b.name, b));
        const next = Array.from(map.values());
        setStockFileName(next.map((f) => f.name).join(', '));
        setStockContent(next[0]?.content || '');
        runMerge(
          next,
          soldFiles.length
            ? soldFiles
            : soldContent
              ? [{ name: soldFileName || 'sold.csv', content: soldContent }]
              : []
        );
        return next;
      });
      setErrorMsg('');
    } catch (err: any) {
      setErrorMsg(err.message || 'Stock file read failed');
    }
  };

  const ingestSoldFiles = async (fileList: FileList | File[]) => {
    const files = Array.from(fileList).filter(isAcceptedUploadFile);
    if (files.length === 0) {
      setErrorMsg('Only .xlsx / .xls / .csv / .txt files accepted');
      return;
    }
    try {
      const blobs = await Promise.all(files.map(readFileAsBlob));
      setSoldFiles((prev) => {
        const map = new Map(prev.map((f) => [f.name, f]));
        blobs.forEach((b) => map.set(b.name, b));
        const next = Array.from(map.values());
        setSoldFileName(next.map((f) => f.name).join(', '));
        setSoldContent(next[0]?.content || '');
        runMerge(
          stockFiles.length
            ? stockFiles
            : stockContent
              ? [{ name: stockFileName || 'stock.csv', content: stockContent }]
              : [],
          next
        );
        return next;
      });
      setErrorMsg('');
    } catch (err: any) {
      setErrorMsg(err.message || 'Sold file read failed');
    }
  };

  const handleStockFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const list = e.target.files;
    if (!list || list.length === 0) return;
    await ingestStockFiles(list);
    e.target.value = '';
  };

  const handleSoldFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const list = e.target.files;
    if (!list || list.length === 0) return;
    await ingestSoldFiles(list);
    e.target.value = '';
  };

  const preventDragDefaults = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const onStockDrop = async (e: React.DragEvent) => {
    preventDragDefaults(e);
    setStockDragOver(false);
    if (e.dataTransfer?.files?.length) {
      await ingestStockFiles(e.dataTransfer.files);
    }
  };

  const onSoldDrop = async (e: React.DragEvent) => {
    preventDragDefaults(e);
    setSoldDragOver(false);
    if (e.dataTransfer?.files?.length) {
      await ingestSoldFiles(e.dataTransfer.files);
    }
  };

  const removeStockFile = (name: string) => {
    setStockFiles((prev) => {
      const next = prev.filter((f) => f.name !== name);
      setStockFileName(next.map((f) => f.name).join(', '));
      setStockContent(next[0]?.content || '');
      runMerge(next, soldFiles);
      return next;
    });
  };

  const removeSoldFile = (name: string) => {
    setSoldFiles((prev) => {
      const next = prev.filter((f) => f.name !== name);
      setSoldFileName(next.map((f) => f.name).join(', '));
      setSoldContent(next[0]?.content || '');
      runMerge(stockFiles, next);
      return next;
    });
  };

  const handleLoadSample = () => {
    setStockFileName('Current_Stock_Report.csv');
    setStockContent(SAMPLE_STOCK_MATRIX_TEXT);
    setStockMode('paste');
    setStockFiles([{ name: 'Current_Stock_Report.csv', content: SAMPLE_STOCK_MATRIX_TEXT }]);

    setSoldFileName('Soldout_Sales_Report.csv');
    setSoldContent(SAMPLE_SOLDOUT_MATRIX_TEXT);
    setSoldMode('paste');
    setSoldFiles([{ name: 'Soldout_Sales_Report.csv', content: SAMPLE_SOLDOUT_MATRIX_TEXT }]);

    handleProcessMerge(SAMPLE_STOCK_MATRIX_TEXT, SAMPLE_SOLDOUT_MATRIX_TEXT);
  };

  /**
   * Return the latest upload pair even when React state has not committed the
   * most recent file-selection update yet. This is important for the footer
   * actions: clicking Apply immediately after the second file is selected must
   * never depend on a stale `parsedResult` closure.
   */
  const getCurrentUploadPair = (): { stock: UploadFileBlob[]; sold: UploadFileBlob[] } => {
    const stock = stockFiles.length
      ? stockFiles
      : stockContent
        ? [{ name: stockFileName || 'stock.csv', content: stockContent }]
        : [];
    const sold = soldFiles.length
      ? soldFiles
      : soldContent
        ? [{ name: soldFileName || 'sold.csv', content: soldContent }]
        : [];
    return { stock, sold };
  };

  const commitImport = (openAi: boolean, resultOverride?: ParsedDataResult) => {
    const result = resultOverride || parsedResult;
    if (!result || result.records.length === 0) {
      setErrorMsg('Please verify/merge both Stock and Sold Out files before applying.');
      return false;
    }

    try {
      const periodDays = getPeriodDays();
      const enriched = enrichRecordsWithPeriodSales(result.records, periodDays);
      saveDailySnapshot(
        enriched,
        undefined,
        `Daily Ingestion (${period}) - ${result.summary.totalStock} Pcs`
      );
      onImportRecords(
        enriched,
        period,
        specialMonths.length > 0 ? specialMonths : undefined,
        importMode
      );
      onClose();
      if (openAi) onOpenAiMode?.();
      setErrorMsg('');
      return true;
    } catch (err: any) {
      console.error('[DiaMatrix] Daily Intake apply failed', err);
      setErrorMsg(`Apply failed: ${err?.message || 'Could not import the uploaded records.'}`);
      return false;
    }
  };

  /**
   * Apply is intentionally resilient to a stale parser state. If the parser
   * has not published parsedResult yet, build the merge directly from the
   * current uploaded files. If the files need Column Mapper, runMerge will
   * open the mapper instead of silently doing nothing.
   */
  const handleApply = () => {
    if (isProcessing) return;
    if (parsedResult?.records.length) {
      commitImport(false, parsedResult);
      return;
    }

    const { stock, sold } = getCurrentUploadPair();
    if (!stock.length || !sold.length) {
      setErrorMsg('Please upload both Current Stock and Sold Out files first.');
      return;
    }

    try {
      setIsProcessing(true);
      setErrorMsg('');
      const result =
        stock.length === 1 && sold.length === 1
          ? mergeDualStockAndSoldData(stock[0].content, sold[0].content, stock[0].name, sold[0].name)
          : mergeMultiFileStockAndSoldData(stock, sold);

      if (result.records.length > 0) {
        setParsedResult(result);
        setIsProcessing(false);
        commitImport(false, result);
        return;
      }
    } catch (err: any) {
      console.error('[DiaMatrix] Direct Apply parse failed', err);
    }

    setIsProcessing(false);
    runMerge(stock, sold);
  };

  const handleApplyAi = () => {
    if (isProcessing) return;
    if (parsedResult?.records.length) {
      commitImport(true, parsedResult);
      return;
    }

    const { stock, sold } = getCurrentUploadPair();
    if (!stock.length || !sold.length) {
      setErrorMsg('Please upload both Current Stock and Sold Out files first.');
      return;
    }

    try {
      setIsProcessing(true);
      setErrorMsg('');
      const result =
        stock.length === 1 && sold.length === 1
          ? mergeDualStockAndSoldData(stock[0].content, sold[0].content, stock[0].name, sold[0].name)
          : mergeMultiFileStockAndSoldData(stock, sold);

      if (result.records.length > 0) {
        setParsedResult(result);
        setIsProcessing(false);
        commitImport(true, result);
        return;
      }
    } catch (err: any) {
      console.error('[DiaMatrix] Direct AI Apply parse failed', err);
    }

    setIsProcessing(false);
    runMerge(stock, sold);
  };

  return (
    <>
    {typeof document !== 'undefined' && createPortal(
    <div
      id="daily-dual-upload-modal"
      onDragOver={preventDragDefaults}
      onDrop={preventDragDefaults}
      className="fixed inset-0 z-[2000] overflow-y-auto bg-[#0B2545]/50 backdrop-blur-[2px] pointer-events-auto"
      role="dialog"
      aria-modal="true"
    >
      <div className="flex min-h-full items-center justify-center p-4 sm:p-6">
      <div className="bg-white border border-[#A9D9F0] rounded-2xl w-full max-w-4xl shadow-[0_1px_0_#fff_inset,0_24px_64px_rgba(6,16,31,0.28)] overflow-hidden flex flex-col max-h-[min(90vh,900px)] relative">
        {/* Header */}
        <div className="px-6 py-4 border-b border-[#D3E8F6] bg-gradient-to-b from-white to-[#F0F9FF] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#14B4E8] to-[#0C94D0] flex items-center justify-center text-white shadow-lg shadow-[#14B4E8]/30">
              <UploadCloud className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-extrabold text-[#0A1628]">
                  Daily 2-File Upload (Current Stock & Sold Out Files)
                </h2>
                <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-[#DDF3FC] text-[#0C94D0] border border-[#A9D9F0]">
                  Dual Ingestion
                </span>
              </div>
              <p className="text-xs font-medium text-[#334155]">
                Upload your daily Current Stock and Sold Out files (Excel, CSV, or paste text). The system will automatically map the matrices and calculate redistribution.
              </p>
            </div>
          </div>
          <button
            id="close-daily-upload-modal-btn"
            onClick={onClose}
            className="text-[#4F6B88] hover:text-[#0A1628] p-2 rounded-lg hover:bg-[#E6F4FC] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-5 flex-1 text-[#0A1628] text-sm font-semibold">

          {/* IndexedDB import mode */}
          <div className="rounded-xl border border-[#CFE6F5] bg-[#F6FAFD] p-3.5 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
            <div className="text-xs text-[#0B2545] leading-relaxed">
              <div className="font-bold text-sm mb-0.5">Save mode · IndexedDB</div>
              {existingRecordCount > 0 ? (
                <span>
                  Local database already has <strong>{existingRecordCount.toLocaleString()}</strong> rows.
                  Use <strong>Append</strong> to add only new day&apos;s data without re-uploading everything.
                </span>
              ) : (
                <span>
                  First upload will be stored permanently in the browser. Tomorrow open the app and only append new files.
                </span>
              )}
            </div>
            <div className="flex rounded-xl border border-[#CFE6F5] overflow-hidden shrink-0">
              <button
                type="button"
                onClick={() => setImportMode('replace')}
                className={`px-3 py-2 text-xs font-semibold ${
                  importMode === 'replace'
                    ? 'bg-[#0B2545] text-[#0A1628]'
                    : 'bg-white text-[#0B2545] hover:bg-[#E6F4FC]'
                }`}
              >
                Replace all
              </button>
              <button
                type="button"
                onClick={() => setImportMode('append')}
                className={`px-3 py-2 text-xs font-semibold ${
                  importMode === 'append'
                    ? 'bg-[#14B4E8] text-white font-bold'
                    : 'bg-white text-[#0B2545] hover:bg-[#E6F4FC]'
                }`}
              >
                Append new
              </button>
            </div>
          </div>

          {/* Quick Helper Banner */}
          <div className="bg-[#ECFDF5] border border-[#6EE7B7] rounded-xl p-3.5 flex items-center justify-between text-xs text-[#065F46] font-semibold">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>
                <strong>Format Support:</strong> Both files share the same branch rows and product/carat columns. The engine merges stock and sales to compute optimal redistribution.
              </span>
            </div>
            <button
              id="btn-load-sample-solitaire"
              type="button"
              onClick={handleLoadSample}
              className="shrink-0 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold font-medium text-xs transition-colors flex items-center gap-1.5 shadow-sm"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              Load Sample Data (Solitaire Earring)
            </button>
          </div>

          {/* Design-level breakdown guide */}
          <div className="bg-[#FFFBEB] border border-[#FCD34D] rounded-xl p-3.5 text-xs text-[#78350F] space-y-2">
            <div className="font-semibold text-[#B45309] font-bold flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5" />
              Same carat, multiple designs? Use Design Breakdown format
            </div>
            <p className="text-[#92400E] leading-relaxed">
              Example: <strong>0.02 ct</strong> nosepin total 20 pcs is not one design —
              e.g. NP7SD1 = 10, NP7SD21 = 5, NP7D10 = 5. Upload a <strong>flat file</strong> with a Design column
              so redistribution runs per design model (not only per carat).
            </p>
            <div className="rounded-lg bg-white border border-[#FDE68A] overflow-x-auto shadow-sm">
              <table className="w-full text-[11px] font-mono">
                <thead>
                  <tr className="text-[#B45309] font-bold border-b border-[#FDE68A]">
                    <th className="text-left px-2 py-1.5">Branch</th>
                    <th className="text-left px-2 py-1.5">Category</th>
                    <th className="text-left px-2 py-1.5">Weight</th>
                    <th className="text-left px-2 py-1.5">Design</th>
                    <th className="text-right px-2 py-1.5">Stock</th>
                    <th className="text-right px-2 py-1.5">Sold</th>
                  </tr>
                </thead>
                <tbody className="text-[#78350F]">
                  <tr className="border-b border-amber-900/30">
                    <td className="px-2 py-1">GUL</td>
                    <td className="px-2 py-1">Diamond Nosepin 7 Stone</td>
                    <td className="px-2 py-1">0.02</td>
                    <td className="px-2 py-1 text-[#14B4E8]">NP7SD1</td>
                    <td className="px-2 py-1 text-right">10</td>
                    <td className="px-2 py-1 text-right">2</td>
                  </tr>
                  <tr className="border-b border-amber-900/30">
                    <td className="px-2 py-1">GUL</td>
                    <td className="px-2 py-1">Diamond Nosepin 7 Stone</td>
                    <td className="px-2 py-1">0.02</td>
                    <td className="px-2 py-1 text-[#14B4E8]">NP7SD21</td>
                    <td className="px-2 py-1 text-right">5</td>
                    <td className="px-2 py-1 text-right">1</td>
                  </tr>
                  <tr>
                    <td className="px-2 py-1">GUL</td>
                    <td className="px-2 py-1">Diamond Nosepin 7 Stone</td>
                    <td className="px-2 py-1">0.02</td>
                    <td className="px-2 py-1 text-[#14B4E8]">NP7D10</td>
                    <td className="px-2 py-1 text-right">5</td>
                    <td className="px-2 py-1 text-right">0</td>
                  </tr>
                </tbody>
              </table>
            </div>
            <p className="text-[#92400E]">
              Headers accepted: <code className="text-[#B45309] font-semibold">Design</code>, <code className="text-[#B45309] font-semibold">Model</code>,{' '}
              <code className="text-[#B45309] font-semibold">SKU</code>, <code className="text-[#B45309] font-semibold">Style</code>,{' '}
              <code className="text-[#B45309] font-semibold">ItemCode</code>. Carat-only matrix still works; when Design is present,
              reports show keys like <code className="text-[#B45309] font-semibold">0.02 · NP7SD1</code>.
            </p>
            <p className="text-[#92400E]">
              <strong className="text-[#B45309] font-semibold">Auto-detect:</strong> Design column না থাকলেও system text থেকে
              model code খুঁজে বের করে (যেমন <code className="text-[#B45309] font-semibold">NP7SD1</code>,{' '}
              <code className="text-[#B45309] font-semibold">KR106729SB</code>) — explicit column → pattern match → embedded text.
            </p>
          </div>

          {/* Official sample templates the software understands */}
          <div className="bg-[#F0F9FF] border border-[#A9D9F0] rounded-xl p-3.5 space-y-2.5">
            <div className="flex items-center gap-2 text-sm font-semibold text-[#0A1628]">
              <FileSpreadsheet className="w-4 h-4 text-emerald-700" />
              Sample formats (download → fill your data → upload)
            </div>
            <p className="text-[11px] text-[#334155] leading-relaxed">
              <strong className="text-[#0A1628]">Oracle software export যেমন আছে তেমনই upload করুন।</strong>{' '}
              Sheet-এর ভিতরে Style Name লাগে না — file name দিয়ে design চেনে (NP7SD1.xlsx → NP7SD1)।
              শুধু category চাইলে category stock + sold; breakdown চাইলে প্রতি Style-এর stock + sold sheet একসাথে দিন।
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px]">
              <a
                href="/api/mocks/SAMPLE_STOCK_Category_Nosepin7Stone.xlsx"
                download
                className="flex items-center gap-2 rounded-lg border border-[#7DD3FC] bg-[#E0F2FE] px-2.5 py-2 text-[#0C94D0] font-semibold hover:bg-[#BAE6FD] transition"
              >
                <Download className="w-3.5 h-3.5 shrink-0" />
                <span>
                  <strong>Stock — Category</strong>
                  <span className="block text-[#0A1628] font-bold">Branch × carat matrix</span>
                </span>
              </a>
              <a
                href="/api/mocks/SAMPLE_SOLD_Category_Nosepin7Stone.xlsx"
                download
                className="flex items-center gap-2 rounded-lg border border-[#FCD34D] bg-[#FFFBEB] px-2.5 py-2 text-[#B45309] font-semibold hover:bg-[#FEF3C7] transition"
              >
                <Download className="w-3.5 h-3.5 shrink-0" />
                <span>
                  <strong>Sold — Category</strong>
                  <span className="block text-[#B45309] font-bold">Oracle Range / Qty style</span>
                </span>
              </a>
              <a
                href="/api/mocks/SAMPLE_STOCK_Style_NP7SD1.xlsx"
                download
                className="flex items-center gap-2 rounded-lg border border-[#C4B5FD] bg-[#F5F3FF] px-2.5 py-2 text-[#6D28D9] font-semibold hover:bg-[#EDE9FE] transition"
              >
                <Download className="w-3.5 h-3.5 shrink-0" />
                <span>
                  <strong>Stock — Style NP7SD1</strong>
                  <span className="block text-[#4C1D95] font-bold">Filename = design code</span>
                </span>
              </a>
              <a
                href="/api/mocks/SAMPLE_SOLD_Style_NP7SD1.xlsx"
                download
                className="flex items-center gap-2 rounded-lg border border-[#C4B5FD] bg-[#F5F3FF] px-2.5 py-2 text-[#6D28D9] font-semibold hover:bg-[#EDE9FE] transition"
              >
                <Download className="w-3.5 h-3.5 shrink-0" />
                <span>
                  <strong>Sold — Style NP7SD1</strong>
                  <span className="block text-[#4C1D95] font-bold">Filename = design code</span>
                </span>
              </a>
            </div>
            <p className="text-[10px] text-[#475569]">
              Tip: Style sheet upload করলে category sheet skip করতে পারেন (double-count হবে না)। Report matrix-এ
              দেখাবে <code className="text-[#334155]">0.05 · NP7SD1</code> — software-style allocation matrix।
            </p>
            <div className="rounded-lg bg-[#F0F9FF] border border-[#D3E8F6] overflow-x-auto">
              <table className="w-full text-[10px] font-mono text-[#1E3A5F]">
                <thead>
                  <tr className="text-[#334155] border-b border-[#D3E8F6]">
                    <th className="text-left px-2 py-1">Category Name</th>
                    <th className="text-left px-2 py-1">Brnch</th>
                    <th className="text-right px-2 py-1">0.03</th>
                    <th className="text-right px-2 py-1">0.04</th>
                    <th className="text-right px-2 py-1">0.05</th>
                    <th className="text-right px-2 py-1">Total</th>
                  </tr>
                </thead>
                <tbody>
                  <tr className="border-b border-slate-900">
                    <td className="px-2 py-1">D.Nosepin 7 Stone</td>
                    <td className="px-2 py-1">GUL</td>
                    <td className="px-2 py-1 text-right">2</td>
                    <td className="px-2 py-1 text-right">8</td>
                    <td className="px-2 py-1 text-right">14</td>
                    <td className="px-2 py-1 text-right">36</td>
                  </tr>
                  <tr>
                    <td className="px-2 py-1 text-[#475569]">…</td>
                    <td className="px-2 py-1">DWL</td>
                    <td className="px-2 py-1 text-right">10</td>
                    <td className="px-2 py-1 text-right">46</td>
                    <td className="px-2 py-1 text-right">50</td>
                    <td className="px-2 py-1 text-right">119</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          {/* Dual path note: Manual engine vs AI Crossmatch */}
          <div className="border border-[#C4B5FD] bg-violet-950/25 rounded-xl p-3 flex gap-3">
            <div className="w-8 h-8 rounded-lg bg-violet-500/20 text-violet-700 font-bold flex items-center justify-center shrink-0">
              <Sparkles className="w-4 h-4" />
            </div>
            <div className="text-[11px] text-violet-100/90 leading-relaxed">
              <p className="font-semibold text-violet-100 mb-0.5">After upload — choose your mode</p>
              <p>
                <strong className="text-emerald-700 font-bold">Apply &amp; Distribution</strong> = Manual engine
                (contribution / baseline / hybrid matrix).{' '}
                <strong className="text-violet-700 font-bold">AI Crossmatch Report</strong> = same numbers +
                international AI briefing on shortage, overstock, transfers &amp; buy. Any format you
                upload (cents or K30 range) is supported.
              </p>
            </div>
          </div>

          {/* Two Side-by-side or stacked File Dropzones */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Box 1: Current Stock */}
            <div className="border border-[#D3E8F6] bg-white/90 rounded-xl p-4 flex flex-col space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-lg bg-blue-500/20 text-blue-400 flex items-center justify-center font-bold text-xs">
                    1
                  </div>
                  <div>
                    <h3 className="font-semibold text-sm text-[#0A1628] flex items-center gap-1.5">
                      📦 Current Stock File
                      <span className="text-xs text-blue-400 font-normal">(Stock Data)</span>
                    </h3>
                  </div>
                </div>
                <div className="flex items-center bg-[#E6F4FC] rounded-lg p-0.5 text-xs">
                  <button
                    type="button"
                    onClick={() => setStockMode('upload')}
                    className={`px-2 py-0.5 rounded-md font-medium transition-colors ${
                      stockMode === 'upload' ? 'bg-slate-700 text-[#0A1628] shadow-xs' : 'text-[#334155] hover:text-[#0A1628]'
                    }`}
                  >
                    File
                  </button>
                  <button
                    type="button"
                    onClick={() => setStockMode('paste')}
                    className={`px-2 py-0.5 rounded-md font-medium transition-colors ${
                      stockMode === 'paste' ? 'bg-slate-700 text-[#0A1628] shadow-xs' : 'text-[#334155] hover:text-[#0A1628]'
                    }`}
                  >
                    Paste
                  </button>
                </div>
              </div>

              {stockMode === 'upload' ? (
                <div className="space-y-2">
                  <label
                    onDragEnter={(e) => {
                      preventDragDefaults(e);
                      setStockDragOver(true);
                    }}
                    onDragOver={preventDragDefaults}
                    onDragLeave={(e) => {
                      preventDragDefaults(e);
                      setStockDragOver(false);
                    }}
                    onDrop={onStockDrop}
                    className={`border-2 border-dashed rounded-xl p-4 flex flex-col items-center justify-center gap-2 cursor-pointer transition-colors ${
                      stockDragOver
                        ? 'border-blue-400 bg-blue-500/15 scale-[1.01]'
                        : 'border-[#A9D9F0] hover:border-blue-500/50 bg-[#F0F9FF]/50 hover:bg-[#E6F4FC]/40'
                    }`}
                  >
                    <input
                      type="file"
                      accept=".csv,.xlsx,.xls,.txt"
                      multiple
                      onChange={handleStockFileUpload}
                      className="hidden"
                    />
                    <UploadCloud className={`w-6 h-6 ${stockDragOver ? 'text-blue-300' : 'text-blue-400'}`} />
                    <div className="text-center">
                      <span className="text-xs font-semibold text-[#0A1628]">
                        {stockDragOver
                          ? 'Drop stock file(s) here'
                          : stockFiles.length
                            ? `${stockFiles.length} stock file(s) — add more`
                            : 'Drag & drop or click — stock file(s)'}
                      </span>
                      <p className="text-[11px] text-[#334155] mt-0.5">
                        Category sheet + optional Style sheets (NP7SD1.xlsx…)
                      </p>
                    </div>
                  </label>
                  {stockFiles.length > 0 && (
                    <ul className="space-y-1 max-h-28 overflow-y-auto">
                      {stockFiles.map((f) => {
                        const design = detectDesignFromFileName(f.name);
                        return (
                          <li
                            key={f.name}
                            className="flex items-center justify-between gap-2 text-[11px] bg-[#F0F9FF] border border-[#D3E8F6] rounded-lg px-2 py-1"
                          >
                            <span className="truncate text-[#1E3A5F]">
                              {f.name}
                              {design ? (
                                <span className="ml-1.5 text-[#14B4E8] font-mono">→ {design}</span>
                              ) : (
                                <span className="ml-1.5 text-[#475569]">(category)</span>
                              )}
                            </span>
                            <button
                              type="button"
                              onClick={() => removeStockFile(f.name)}
                              className="text-[#475569] hover:text-red-400 shrink-0"
                            >
                              <X className="w-3.5 h-3.5" />
                            </button>
                          </li>
                        );
                      })}
                    </ul>
                  )}
                </div>
              ) : (
                <textarea
                  rows={4}
                  value={typeof stockContent === 'string' ? stockContent : ''}
                  onChange={(e) => {
                    setStockContent(e.target.value);
                    if (soldContent) handleProcessMerge(e.target.value, soldContent);
                  }}
                  placeholder="Paste Current Stock CSV / matrix text here..."
                  className="w-full bg-[#F0F9FF] border border-[#D3E8F6] rounded-lg p-2.5 text-xs font-mono text-[#0A1628] placeholder-slate-500 focus:outline-none focus:border-blue-500 resize-none"
                />
              )}
            </div>

            {/* Box 2: Sold Out */}
            <div className="border border-[#D3E8F6] bg-white/90 rounded-xl p-4 flex flex-col space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-lg bg-amber-500/20 text-[#B45309] flex items-center justify-center font-bold text-xs">
                    2
                  </div>
                  <div>
                    <h3 className="font-semibold text-sm text-[#0A1628] flex items-center gap-1.5">
                      🛒 Sold Out / Sales File
                      <span className="text-xs text-[#B45309] font-normal">(Sales Demand)</span>
                    </h3>
                  </div>
                </div>
                <div className="flex items-center bg-[#E6F4FC] rounded-lg p-0.5 text-xs">
                  <button
                    type="button"
                    onClick={() => setSoldMode('upload')}
                    className={`px-2 py-0.5 rounded-md font-medium transition-colors ${
                      soldMode === 'upload' ? 'bg-slate-700 text-[#0A1628] shadow-xs' : 'text-[#334155] hover:text-[#0A1628]'
                    }`}
                  >
                    File
                  </button>
                  <button
                    type="button"
                    onClick={() => setSoldMode('paste')}
                    className={`px-2 py-0.5 rounded-md font-medium transition-colors ${
                      soldMode === 'paste' ? 'bg-slate-700 text-[#0A1628] shadow-xs' : 'text-[#334155] hover:text-[#0A1628]'
                    }`}
                  >
                    Paste
                  </button>
                </div>
              </div>

              {soldMode === 'upload' ? (
                <div className="space-y-2">
                  <label
                    onDragEnter={(e) => {
                      preventDragDefaults(e);
                      setSoldDragOver(true);
                    }}
                    onDragOver={preventDragDefaults}
                    onDragLeave={(e) => {
                      preventDragDefaults(e);
                      setSoldDragOver(false);
                    }}
                    onDrop={onSoldDrop}
                    className={`border-2 border-dashed rounded-xl p-4 flex flex-col items-center justify-center gap-2 cursor-pointer transition-colors ${
                      soldDragOver
                        ? 'border-amber-400 bg-amber-500/15 scale-[1.01]'
                        : 'border-[#A9D9F0] hover:border-amber-500/50 bg-[#F0F9FF]/50 hover:bg-[#E6F4FC]/40'
                    }`}
                  >
                    <input
                      type="file"
                      accept=".csv,.xlsx,.xls,.txt"
                      multiple
                      onChange={handleSoldFileUpload}
                      className="hidden"
                    />
                    <UploadCloud className={`w-6 h-6 ${soldDragOver ? 'text-[#B45309] font-bold' : 'text-[#B45309]'}`} />
                    <div className="text-center">
                      <span className="text-xs font-semibold text-[#0A1628]">
                        {soldDragOver
                          ? 'Drop sold file(s) here'
                          : soldFiles.length
                            ? `${soldFiles.length} sold file(s) — add more`
                            : 'Drag & drop or click — sold file(s)'}
                      </span>
                      <p className="text-[11px] text-[#334155] mt-0.5">
                        Category sold + optional Style Name sales sheets
                      </p>
                    </div>
                  </label>
                  {soldFiles.length > 0 && (
                    <ul className="space-y-1 max-h-28 overflow-y-auto">
                      {soldFiles.map((f) => {
                        const design = detectDesignFromFileName(f.name);
                        return (
                          <li
                            key={f.name}
                            className="flex items-center justify-between gap-2 text-[11px] bg-[#F0F9FF] border border-[#D3E8F6] rounded-lg px-2 py-1"
                          >
                            <span className="truncate text-[#1E3A5F]">
                              {f.name}
                              {design ? (
                                <span className="ml-1.5 text-[#14B4E8] font-mono">→ {design}</span>
                              ) : (
                                <span className="ml-1.5 text-[#475569]">(category)</span>
                              )}
                            </span>
                            <button
                              type="button"
                              onClick={() => removeSoldFile(f.name)}
                              className="text-[#475569] hover:text-red-400 shrink-0"
                            >
                              <X className="w-3.5 h-3.5" />
                            </button>
                          </li>
                        );
                      })}
                    </ul>
                  )}
                </div>
              ) : (
                <textarea
                  rows={4}
                  value={typeof soldContent === 'string' ? soldContent : ''}
                  onChange={(e) => {
                    setSoldContent(e.target.value);
                    if (stockContent) handleProcessMerge(stockContent, e.target.value);
                  }}
                  placeholder="Paste Sold Out CSV / matrix text here..."
                  className="w-full bg-[#F0F9FF] border border-[#D3E8F6] rounded-lg p-2.5 text-xs font-mono text-[#0A1628] placeholder-slate-500 focus:outline-none focus:border-amber-500 resize-none"
                />
              )}
            </div>
          </div>

          {/* Custom Duration / Period Selector */}
          <div className="bg-[#F0F9FF] p-3.5 rounded-xl border border-[#D3E8F6] space-y-3">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <label className="text-xs font-semibold text-[#0A1628] flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-emerald-700" />
                Select Sales Duration / Period
              </label>
              <div className="flex flex-wrap items-center gap-1 text-[11px]">
                {[
                  { id: '7d', label: '7 Days' },
                  { id: '15d', label: '15 Days' },
                  { id: '1m', label: '1 Month' },
                  { id: '3m', label: '3 Months' },
                  { id: '6m', label: '6 Months' },
                  { id: '9m', label: '9 Months' },
                  { id: 'ytd', label: 'YTD' },
                  { id: 'custom', label: 'Custom' }
                ].map((p) => (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => handlePeriodQuickChange(p.id)}
                    className={`px-2 py-0.5 rounded-md font-medium transition-colors ${
                      quickPeriod === p.id
                        ? 'bg-emerald-600 text-white font-bold shadow-sm'
                        : 'bg-[#E6F4FC] text-[#334155] hover:text-[#0A1628]'
                    }`}
                  >
                    {p.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-[11px] text-[#334155] block mb-1">From Date</label>
                <input
                  type="date"
                  value={fromDate}
                  onChange={(e) => handleFromToChange(e.target.value, toDate)}
                  className="w-full bg-[#F0F9FF] border border-[#A9D9F0] rounded-lg px-3 py-1.5 text-xs text-[#0A1628] focus:outline-none focus:border-emerald-500"
                />
              </div>
              <div>
                <label className="text-[11px] text-[#334155] block mb-1">To Date</label>
                <input
                  type="date"
                  value={toDate}
                  onChange={(e) => handleFromToChange(fromDate, e.target.value)}
                  className="w-full bg-[#F0F9FF] border border-[#A9D9F0] rounded-lg px-3 py-1.5 text-xs text-[#0A1628] focus:outline-none focus:border-emerald-500"
                />
              </div>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-[11px] text-[#334155] shrink-0">Period Label:</span>
              <input
                type="text"
                value={period}
                onChange={(e) => {
                  setPeriod(e.target.value);
                  setQuickPeriod('custom');
                }}
                placeholder="e.g. 01-03-2026 to 19-09-2026"
                className="flex-1 bg-[#F0F9FF] border border-[#A9D9F0] rounded-lg px-3 py-1.5 text-xs font-mono text-[#0A1628] focus:outline-none focus:border-emerald-500"
              />
            </div>
            <p className="text-[11px] text-[#475569]">
              This period is stamped on all reports, Excel exports, KPIs, and analysis. Choose a preset or custom dates.
            </p>
          </div>

          {/* Special / Festival / Exhibition / Promotion months */}
          <div className="rounded-xl border border-amber-500/30 bg-amber-950/20 p-3.5 space-y-3">
            <div className="flex items-start gap-2">
              <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-[#B45309] font-bold flex items-center justify-center shrink-0">
                <PartyPopper className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-semibold text-amber-100">
                  Special Months (Festival / Exhibition / Promotion)
                </h3>
                <p className="text-[11px] text-[#B45309] font-semibold/70 mt-0.5 leading-relaxed">
                  Months with Festival, Exhibition, or Promotion often have unusually high sales.
                  They are <strong className="text-amber-100">not treated as normal average months</strong>.
                  Select the month and enter the event name, then Add.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-12 gap-2 items-end">
              <div className="sm:col-span-3">
                <label className="text-[10px] text-[#B45309] font-semibold/80 block mb-1">Month</label>
                <select
                  value={newMonthLabel}
                  onChange={(e) => setNewMonthLabel(e.target.value)}
                  className="w-full text-xs bg-[#F0F9FF] border border-amber-500/40 rounded-lg px-2 py-2 text-[#0A1628] focus:outline-none focus:ring-1 focus:ring-amber-400"
                >
                  <option value="">Select month…</option>
                  {MONTH_OPTIONS.map((m) => (
                    <option key={m} value={m}>{m}</option>
                  ))}
                </select>
              </div>
              <div className="sm:col-span-2">
                <label className="text-[10px] text-[#B45309] font-semibold/80 block mb-1">Year</label>
                <input
                  type="text"
                  value={newMonthYear}
                  onChange={(e) => setNewMonthYear(e.target.value)}
                  placeholder="2026"
                  className="w-full text-xs bg-[#F0F9FF] border border-amber-500/40 rounded-lg px-2 py-2 text-[#0A1628] focus:outline-none focus:ring-1 focus:ring-amber-400"
                />
              </div>
              <div className="sm:col-span-3">
                <label className="text-[10px] text-[#B45309] font-semibold/80 block mb-1">Festival / Event name</label>
                <input
                  type="text"
                  value={newEventName}
                  onChange={(e) => setNewEventName(e.target.value)}
                  placeholder="e.g. Eid-ul-Fitr, Durga Puja Expo"
                  className="w-full text-xs bg-[#F0F9FF] border border-amber-500/40 rounded-lg px-2 py-2 text-[#0A1628] focus:outline-none focus:ring-1 focus:ring-amber-400"
                />
              </div>
              <div className="sm:col-span-2">
                <label className="text-[10px] text-[#B45309] font-semibold/80 block mb-1">Type</label>
                <select
                  value={newSpecialType}
                  onChange={(e) => setNewSpecialType(e.target.value as SpecialMonthType)}
                  className="w-full text-xs bg-[#F0F9FF] border border-amber-500/40 rounded-lg px-2 py-2 text-[#0A1628] focus:outline-none focus:ring-1 focus:ring-amber-400"
                >
                  {SPECIAL_TYPE_OPTIONS.map((t) => (
                    <option key={t} value={t}>{t}</option>
                  ))}
                </select>
              </div>
              <div className="sm:col-span-2">
                <button
                  type="button"
                  onClick={handleAddSpecialMonth}
                  disabled={!newMonthLabel.trim() || !newEventName.trim()}
                  className="w-full flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg text-xs font-bold bg-blue-600 hover:bg-blue-700 disabled:opacity-40 disabled:cursor-not-allowed text-[#0A1628] transition-colors"
                >
                  <Plus className="w-3.5 h-3.5" />
                  Add
                </button>
              </div>
            </div>

            {specialMonths.length > 0 && (
              <ul className="space-y-1.5 mt-1">
                {specialMonths.map((sm) => (
                  <li
                    key={sm.id}
                    className="flex items-center justify-between gap-2 rounded-lg bg-[#F0F9FF] border border-amber-500/20 px-3 py-2"
                  >
                    <div className="min-w-0">
                      <span className="text-xs font-semibold text-amber-100">{sm.monthLabel}</span>
                      <span className="text-[#475569] mx-1.5">·</span>
                      <span className="text-xs text-[#0A1628]">{sm.eventName}</span>
                      <span className="ml-2 inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-medium bg-amber-500/20 text-[#B45309] font-semibold border border-amber-500/30">
                        {sm.type}
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleRemoveSpecialMonth(sm.id)}
                      className="shrink-0 p-1 rounded-md text-[#334155] hover:text-red-400 hover:bg-red-500/10 transition-colors"
                      title="Remove"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </li>
                ))}
              </ul>
            )}

            {specialMonths.length === 0 && (
              <p className="text-[11px] text-[#475569] italic">
                No special months added — all months count toward the normal average.
              </p>
            )}
          </div>

          {/* Error Message if Any */}
          {errorMsg && (
            <div className="bg-red-950/50 border border-red-800 rounded-xl p-3 flex items-center gap-2 text-xs text-red-300">
              <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}

          {/* Live Ingestion Summary & Preview */}
          {parsedResult && (
            <div className="border border-[#D3E8F6] rounded-xl bg-[#F0F9FF]/70 p-4 space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-semibold text-[#0A1628] uppercase tracking-wider flex items-center gap-1.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-700" />
                  Combined Ingestion Summary (Verified Data)
                </h4>
                <span className="text-xs text-emerald-700 font-medium bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20">
                  Ready to Ingest
                </span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
                <div className="bg-white p-2.5 rounded-lg border border-[#D3E8F6]">
                  <span className="text-[11px] text-[#334155] block">Total Branches</span>
                  <span className="text-base font-bold text-[#0A1628]">
                    {parsedResult.summary.branchesFound}
                  </span>
                </div>
                <div className="bg-white p-2.5 rounded-lg border border-[#D3E8F6]">
                  <span className="text-[11px] text-[#334155] block">Carats / Products</span>
                  <span className="text-base font-bold text-[#0A1628]">
                    {parsedResult.summary.weightsFound}
                  </span>
                </div>
                <div className="bg-white p-2.5 rounded-lg border border-[#D3E8F6]">
                  <span className="text-[11px] text-[#334155] block">Total Current Stock</span>
                  <span className="text-base font-bold text-blue-400">
                    {parsedResult.summary.totalStock} pcs
                  </span>
                </div>
                <div className="bg-white p-2.5 rounded-lg border border-[#D3E8F6]">
                  <span className="text-[11px] text-[#334155] block">Total Sold Quantity</span>
                  <span className="text-base font-bold text-[#B45309]">
                    {parsedResult.summary.totalSold} pcs
                  </span>
                </div>
              </div>

              {specialMonths.length > 0 && (
                <div className="text-[#B45309] font-semibold/90 text-[11px] bg-amber-950/40 border border-amber-500/20 rounded-lg px-3 py-2">
                  Special months (normalized out of average):{' '}
                  {specialMonths.map((s) => `${s.monthLabel} — ${s.eventName}`).join('; ')}
                </div>
              )}

              {/* Sample 5 Records Preview */}
              <div className="mt-2">
                <span className="text-[11px] text-[#334155] block mb-1.5">Sample Merged Records:</span>
                <div className="max-h-36 overflow-y-auto rounded-lg border border-[#D3E8F6] bg-[#F0F9FF] text-xs">
                  <table className="w-full text-left border-collapse">
                    <thead className="bg-white text-[#334155] sticky top-0">
                      <tr>
                        <th className="px-3 py-1.5 border-b border-[#D3E8F6] font-semibold">Branch</th>
                        <th className="px-3 py-1.5 border-b border-[#D3E8F6] font-semibold">Carat / Item</th>
                        <th className="px-3 py-1.5 border-b border-[#D3E8F6] font-semibold text-right">Current Stock</th>
                        <th className="px-3 py-1.5 border-b border-[#D3E8F6] font-semibold text-right">Sold Quantity</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-850 text-[#1E3A5F] font-mono text-[11px]">
                      {parsedResult.records.slice(0, 6).map((rec, i) => (
                        <tr key={i} className="hover:bg-white/50">
                          <td className="px-3 py-1 font-sans font-medium text-[#0A1628]">{rec.branch}</td>
                          <td className="px-3 py-1">{rec.weight}</td>
                          <td className="px-3 py-1 text-right text-blue-400 font-semibold">{rec.currentStock}</td>
                          <td className="px-3 py-1 text-right text-[#B45309] font-semibold">{rec.soldQty}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="px-6 py-4 border-t border-[#D3E8F6] bg-[#F0F9FF] flex items-center justify-between">
          <button
            id="btn-cancel-daily-upload"
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-xs font-medium text-[#334155] hover:text-[#0A1628] hover:bg-[#E6F4FC] transition-colors"
          >
            Cancel
          </button>

          <div className="flex items-center gap-2">
            {(!parsedResult || parsedResult.records.length === 0) && (
              <button
                type="button"
                onClick={() => {
                  if (stockContent && soldContent) {
                    handleProcessMerge(stockContent, soldContent);
                  } else {
                    setErrorMsg('Please select or paste both files to process.');
                  }
                }}
                disabled={
                  isProcessing ||
                  (!stockFiles.length && !stockContent) ||
                  (!soldFiles.length && !soldContent)
                }
                className="px-4 py-2 rounded-xl text-xs font-semibold bg-[#E6F4FC] hover:bg-slate-750 text-[#0A1628] disabled:opacity-50 transition-colors"
              >
                Verify & Merge Files
              </button>
            )}

            <button
              id="btn-apply-daily-upload"
              type="button"
              onClick={handleApply}
              disabled={
                isProcessing ||
                ((!stockFiles.length && !stockContent) || (!soldFiles.length && !soldContent))
              }
              className="px-4 py-2.5 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-[#14B4E8] to-[#0C94D0] hover:brightness-105 disabled:opacity-40 disabled:cursor-not-allowed shadow-[0_1px_0_rgba(255,255,255,0.35)_inset,0_6px_0_#0A7AAD,0_10px_24px_rgba(20,180,232,0.4)] transition-all flex items-center gap-2"
            >
              <CheckCircle2 className="w-4 h-4" />
              Apply &amp; Distribution
            </button>
            <button
              id="btn-apply-ai-crossmatch"
              type="button"
              onClick={handleApplyAi}
              disabled={
                isProcessing ||
                ((!stockFiles.length && !stockContent) || (!soldFiles.length && !soldContent))
              }
              className="px-4 py-2.5 rounded-xl text-xs font-bold text-white bg-gradient-to-r from-violet-600 to-indigo-600 hover:brightness-105 disabled:opacity-40 disabled:cursor-not-allowed shadow-[0_1px_0_rgba(255,255,255,0.25)_inset,0_6px_0_#4c1d95,0_10px_24px_rgba(109,40,217,0.35)] transition-all flex items-center gap-2"
            >
              <Sparkles className="w-4 h-4" />
              AI Crossmatch Report
            </button>
          </div>
        </div>
      </div>
      </div>
    </div>, document.body)}

      {mapperAnalysis && (
        <ColumnMapperModal
          open={mapperOpen}
          analysis={mapperAnalysis}
          fileLabel={mapperFileLabel}
          onCancel={handleMapperCancel}
          onConfirm={handleMapperConfirm}
        />
      )}
    </>
  );
};
