import React, { useEffect, useState } from 'react';
import { BRAND } from '../brand';
import { AppTheme } from '../utils/settingsEngine';

interface ErpStatusBarProps {
  userName?: string;
  userRole?: string;
  period: string;
  rowCount: number;
  branchCount: number;
  skuCount: number;
  timeframe: string;
  allocationMode: string;
  theme: AppTheme;
  dataSource: 'demo' | 'upload' | 'empty';
  lastUploadAt?: string | null;
  onAbout?: () => void;
}

/**
 * Classic ERP bottom status bar — always visible after login.
 * Signals: live dataset, user, period, theme, version.
 */
export const ErpStatusBar: React.FC<ErpStatusBarProps> = ({
  userName,
  userRole,
  period,
  rowCount,
  branchCount,
  skuCount,
  timeframe,
  allocationMode,
  theme,
  dataSource,
  lastUploadAt,
  onAbout,
}) => {
  const [clock, setClock] = useState(() => new Date());

  useEffect(() => {
    const t = setInterval(() => setClock(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  const modeLabel =
    allocationMode === 'contribution' ? 'Contribution'
    : allocationMode === 'baseline' ? '3M Baseline'
    : allocationMode === 'hybrid' ? 'Hybrid'
    : allocationMode === 'liquidity' ? 'Capital Liquidity'
    : allocationMode === 'demand_backup' ? 'Demand-Backup'
    : allocationMode === 'coverage' ? 'Coverage'
    : 'Hybrid';

  const sourceLabel =
    dataSource === 'upload' ? 'Uploaded dataset' : dataSource === 'demo' ? 'Demo dataset' : 'No data';

  return (
    <div
      className="sw-statusbar shrink-0 z-30 flex flex-wrap items-center justify-between gap-x-4 gap-y-1"
      role="status"
      aria-label="Application status"
    >
      <div className="flex flex-wrap items-center gap-x-3 gap-y-0.5">
        <span className="font-semibold text-[11px]" style={{ color: 'var(--shell-accent)' }}>
          {BRAND.short}
        </span>
        <span className="opacity-40">|</span>
        <span>
          <strong>{sourceLabel}</strong>
          {lastUploadAt && dataSource === 'upload' && (
            <span className="opacity-70"> · {lastUploadAt}</span>
          )}
        </span>
        <span className="opacity-40">|</span>
        <span>
          Rows <strong>{rowCount.toLocaleString()}</strong>
        </span>
        <span>
          Outlets <strong>{branchCount}</strong>
        </span>
        <span>
          SKUs <strong>{skuCount}</strong>
        </span>
        <span className="opacity-40">|</span>
        <span>
          Period <strong>{period || '—'}</strong>
        </span>
        <span>
          Sales <strong>{timeframe}</strong>
        </span>
        <span>
          Mode <strong>{modeLabel}</strong>
        </span>
      </div>

      <div className="flex flex-wrap items-center gap-x-3 gap-y-0.5">
        {userName && (
          <span>
            User <strong>{userName}</strong>
            {userRole ? ` (${userRole})` : ''}
          </span>
        )}
        <span className="opacity-40">|</span>
        <span>
          Theme <strong className="capitalize">{theme}</strong>
        </span>
        <span className="opacity-40">|</span>
        <button
          type="button"
          onClick={onAbout}
          className="hover:underline font-semibold"
          style={{ color: 'var(--shell-accent)' }}
          title="About DiaMatrix"
        >
          v{BRAND.version}
        </button>
        <span className="opacity-40">|</span>
        <span className="font-mono tabular-nums">
          {clock.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
        </span>
      </div>
    </div>
  );
};
