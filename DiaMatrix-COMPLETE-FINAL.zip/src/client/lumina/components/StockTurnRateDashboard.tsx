/**
 * Stock Turn Rate Dashboard
 * Sales ÷ Current Stock per outlet — Top Fast / Slow movers + full ranking.
 * Matches DiaMatrix / Lumina visual language (emerald accents, slate tables).
 */
import React, { useMemo, useState } from 'react';
import {
  Gauge,
  Search,
  ArrowUpDown,
  Zap,
  Turtle,
  AlertTriangle,
  TrendingUp,
  Building2,
} from 'lucide-react';
import { RedistributionReport, BranchSummary } from '../types';
import { getBranchDisplayName } from '../utils/dataIdentityEngine';

interface StockTurnRateDashboardProps {
  report: RedistributionReport;
  onSelectBranch?: (branch: string) => void;
}

type TurnStatus = 'FAST' | 'AVERAGE' | 'SLOW' | 'STOCKOUT';

interface TurnRow {
  branch: string;
  displayName: string;
  totalSold: number;
  totalCurrentStock: number;
  turnRate: number | null; // null = stock-out (sold > 0, stock = 0)
  status: TurnStatus;
  isWarehouse: boolean;
}

const FAST_THRESHOLD = 6.5;
const SLOW_THRESHOLD = 3.2;

function computeTurn(b: BranchSummary): TurnRow {
  const sold = b.totalSold || 0;
  const stock = b.totalCurrentStock || 0;
  let turnRate: number | null = null;
  let status: TurnStatus = 'AVERAGE';

  if (stock === 0) {
    if (sold > 0) {
      turnRate = null;
      status = 'STOCKOUT';
    } else {
      turnRate = 0;
      status = 'SLOW';
    }
  } else {
    turnRate = sold / stock;
    if (turnRate >= FAST_THRESHOLD) status = 'FAST';
    else if (turnRate <= SLOW_THRESHOLD) status = 'SLOW';
    else status = 'AVERAGE';
  }

  return {
    branch: b.branch,
    displayName: getBranchDisplayName?.(b.branch) ?? b.branch,
    totalSold: sold,
    totalCurrentStock: stock,
    turnRate,
    status,
    isWarehouse: !!b.isWarehouse,
  };
}

function statusBadge(status: TurnStatus) {
  const map: Record<TurnStatus, string> = {
    FAST: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-300',
    AVERAGE: 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300',
    SLOW: 'bg-red-100 text-red-800 dark:bg-red-900/40 dark:text-red-300',
    STOCKOUT: 'bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-300',
  };
  const label: Record<TurnStatus, string> = {
    FAST: '🟢 FAST',
    AVERAGE: '🟡 AVG',
    SLOW: '🔴 SLOW',
    STOCKOUT: '⚡ STOCKOUT',
  };
  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold ${map[status]}`}>
      {label[status]}
    </span>
  );
}

export const StockTurnRateDashboard: React.FC<StockTurnRateDashboardProps> = ({
  report,
  onSelectBranch,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [sortField, setSortField] = useState<'turnRate' | 'totalSold' | 'totalCurrentStock' | 'branch'>('turnRate');
  const [sortAsc, setSortAsc] = useState(false);

  const rows = useMemo(() => {
    return (report.branchSummaries || [])
      .filter((b) => !b.isWarehouse)
      .map(computeTurn);
  }, [report.branchSummaries]);

  const kpis = useMemo(() => {
    const totalSold = rows.reduce((s, r) => s + r.totalSold, 0);
    const totalStock = rows.reduce((s, r) => s + r.totalCurrentStock, 0);
    const overall = totalStock > 0 ? totalSold / totalStock : null;
    const fast = rows.filter((r) => r.status === 'FAST' || r.status === 'STOCKOUT').length;
    const slow = rows.filter((r) => r.status === 'SLOW').length;
    const stockout = rows.filter((r) => r.status === 'STOCKOUT').length;
    return { totalSold, totalStock, overall, fast, slow, stockout, outlets: rows.length };
  }, [rows]);

  const sorted = useMemo(() => {
    const filtered = rows.filter(
      (r) =>
        r.branch.toLowerCase().includes(searchTerm.toLowerCase()) ||
        r.displayName.toLowerCase().includes(searchTerm.toLowerCase())
    );
    return [...filtered].sort((a, b) => {
      let va: number | string = 0;
      let vb: number | string = 0;
      if (sortField === 'branch') {
        va = a.displayName;
        vb = b.displayName;
        return sortAsc ? String(va).localeCompare(String(vb)) : String(vb).localeCompare(String(va));
      }
      if (sortField === 'turnRate') {
        // null (stockout) sorts as highest when desc
        va = a.turnRate === null ? Number.POSITIVE_INFINITY : a.turnRate;
        vb = b.turnRate === null ? Number.POSITIVE_INFINITY : b.turnRate;
      } else {
        va = a[sortField];
        vb = b[sortField];
      }
      return sortAsc ? (va as number) - (vb as number) : (vb as number) - (va as number);
    });
  }, [rows, searchTerm, sortField, sortAsc]);

  const topFast = useMemo(() => {
    return [...rows]
      .sort((a, b) => {
        const va = a.turnRate === null ? Number.POSITIVE_INFINITY : a.turnRate;
        const vb = b.turnRate === null ? Number.POSITIVE_INFINITY : b.turnRate;
        return vb - va;
      })
      .slice(0, 5);
  }, [rows]);

  const topSlow = useMemo(() => {
    return [...rows]
      .filter((r) => r.turnRate !== null)
      .sort((a, b) => (a.turnRate ?? 0) - (b.turnRate ?? 0))
      .slice(0, 5);
  }, [rows]);

  const handleSort = (field: typeof sortField) => {
    if (sortField === field) setSortAsc(!sortAsc);
    else {
      setSortField(field);
      setSortAsc(false);
    }
  };

  const fmtRate = (r: number | null) => (r === null ? '∞' : r.toFixed(2) + '×');

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-4 shadow-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Gauge className="w-4 h-4 text-emerald-600" />
              Stock Turn Rate Dashboard
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Sales ÷ Current Stock · {kpis.outlets} retail outlets · Period: {report.period || 'Current'}
            </p>
          </div>
          <div className="relative w-full sm:w-64">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search outlet..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg text-slate-800 dark:text-slate-200 focus:outline-none focus:ring-1 focus:ring-emerald-500"
            />
          </div>
        </div>

        {/* KPI strip */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2 mt-4">
          {[
            { label: 'Total Sales', value: kpis.totalSold.toLocaleString(), icon: TrendingUp, color: 'text-blue-600' },
            { label: 'Total Stock', value: kpis.totalStock.toLocaleString(), icon: Building2, color: 'text-slate-600' },
            { label: 'Overall Turn', value: kpis.overall === null ? '∞' : kpis.overall.toFixed(2) + '×', icon: Gauge, color: 'text-emerald-600' },
            { label: 'Fast Outlets', value: String(kpis.fast), icon: Zap, color: 'text-emerald-600' },
            { label: 'Slow Outlets', value: String(kpis.slow), icon: Turtle, color: 'text-red-600' },
            { label: 'Stock-Out Risk', value: String(kpis.stockout), icon: AlertTriangle, color: 'text-amber-600' },
          ].map((k) => (
            <div
              key={k.label}
              className="rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/50 px-3 py-2"
            >
              <div className="flex items-center gap-1.5 text-[10px] uppercase tracking-wide text-slate-500 font-semibold">
                <k.icon className={`w-3 h-3 ${k.color}`} />
                {k.label}
              </div>
              <div className={`text-lg font-bold mt-0.5 ${k.color}`}>{k.value}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Top 5 Fast / Slow */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="bg-white dark:bg-slate-900 rounded-xl border border-emerald-200 dark:border-emerald-900 shadow-sm overflow-hidden">
          <div className="bg-emerald-700 text-white px-4 py-2.5 flex items-center gap-2 text-sm font-bold">
            <Zap className="w-4 h-4" /> Top 5 Fast-Moving Outlets
          </div>
          <table className="w-full text-xs">
            <thead>
              <tr className="bg-emerald-50 dark:bg-emerald-950/30 text-emerald-900 dark:text-emerald-200">
                <th className="py-2 px-3 text-left">#</th>
                <th className="py-2 px-3 text-left">Outlet</th>
                <th className="py-2 px-3 text-right">Sales</th>
                <th className="py-2 px-3 text-right">Stock</th>
                <th className="py-2 px-3 text-right">Turn</th>
              </tr>
            </thead>
            <tbody>
              {topFast.map((r, i) => (
                <tr
                  key={r.branch}
                  className="border-t border-slate-100 dark:border-slate-800 hover:bg-emerald-50/50 dark:hover:bg-emerald-950/20 cursor-pointer"
                  onClick={() => onSelectBranch?.(r.branch)}
                >
                  <td className="py-2 px-3 font-mono text-slate-400">{i + 1}</td>
                  <td className="py-2 px-3 font-semibold text-slate-800 dark:text-slate-100">{r.displayName}</td>
                  <td className="py-2 px-3 text-right">{r.totalSold.toLocaleString()}</td>
                  <td className="py-2 px-3 text-right">{r.totalCurrentStock.toLocaleString()}</td>
                  <td className="py-2 px-3 text-right font-bold text-emerald-700 dark:text-emerald-400">
                    {fmtRate(r.turnRate)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-xl border border-red-200 dark:border-red-900 shadow-sm overflow-hidden">
          <div className="bg-red-700 text-white px-4 py-2.5 flex items-center gap-2 text-sm font-bold">
            <Turtle className="w-4 h-4" /> Top 5 Slow-Moving Outlets
          </div>
          <table className="w-full text-xs">
            <thead>
              <tr className="bg-red-50 dark:bg-red-950/30 text-red-900 dark:text-red-200">
                <th className="py-2 px-3 text-left">#</th>
                <th className="py-2 px-3 text-left">Outlet</th>
                <th className="py-2 px-3 text-right">Sales</th>
                <th className="py-2 px-3 text-right">Stock</th>
                <th className="py-2 px-3 text-right">Turn</th>
              </tr>
            </thead>
            <tbody>
              {topSlow.map((r, i) => (
                <tr
                  key={r.branch}
                  className="border-t border-slate-100 dark:border-slate-800 hover:bg-red-50/50 dark:hover:bg-red-950/20 cursor-pointer"
                  onClick={() => onSelectBranch?.(r.branch)}
                >
                  <td className="py-2 px-3 font-mono text-slate-400">{i + 1}</td>
                  <td className="py-2 px-3 font-semibold text-slate-800 dark:text-slate-100">{r.displayName}</td>
                  <td className="py-2 px-3 text-right">{r.totalSold.toLocaleString()}</td>
                  <td className="py-2 px-3 text-right">{r.totalCurrentStock.toLocaleString()}</td>
                  <td className="py-2 px-3 text-right font-bold text-red-700 dark:text-red-400">
                    {fmtRate(r.turnRate)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Full ranking table */}
      <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
        <div className="px-4 py-2.5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <h3 className="text-sm font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
            <Building2 className="w-3.5 h-3.5 text-slate-500" />
            Full Outlet Ranking
          </h3>
          <span className="text-[10px] text-slate-500">
            Fast ≥ {FAST_THRESHOLD}× · Slow ≤ {SLOW_THRESHOLD}× · ∞ = stock-out risk
          </span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-800 text-white font-semibold text-[11px] tracking-wider">
                <th className="py-2.5 px-3">#</th>
                <th
                  className="py-2.5 px-3 cursor-pointer hover:bg-slate-700"
                  onClick={() => handleSort('branch')}
                >
                  <span className="flex items-center gap-1">
                    Outlet <ArrowUpDown className="w-3 h-3 text-slate-400" />
                  </span>
                </th>
                <th
                  className="py-2.5 px-3 text-right cursor-pointer hover:bg-slate-700"
                  onClick={() => handleSort('totalSold')}
                >
                  <span className="flex items-center justify-end gap-1">
                    Sales Qty <ArrowUpDown className="w-3 h-3 text-slate-400" />
                  </span>
                </th>
                <th
                  className="py-2.5 px-3 text-right cursor-pointer hover:bg-slate-700"
                  onClick={() => handleSort('totalCurrentStock')}
                >
                  <span className="flex items-center justify-end gap-1">
                    Stock Qty <ArrowUpDown className="w-3 h-3 text-slate-400" />
                  </span>
                </th>
                <th
                  className="py-2.5 px-3 text-right cursor-pointer hover:bg-slate-700"
                  onClick={() => handleSort('turnRate')}
                >
                  <span className="flex items-center justify-end gap-1 text-emerald-300">
                    Turn Rate <ArrowUpDown className="w-3 h-3" />
                  </span>
                </th>
                <th className="py-2.5 px-3 text-center">Status</th>
              </tr>
            </thead>
            <tbody>
              {sorted.map((r, i) => (
                <tr
                  key={r.branch}
                  className="border-t border-slate-100 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/50 cursor-pointer transition-colors"
                  onClick={() => onSelectBranch?.(r.branch)}
                >
                  <td className="py-2 px-3 font-mono text-slate-400">{i + 1}</td>
                  <td className="py-2 px-3">
                    <div className="font-semibold text-slate-800 dark:text-slate-100">{r.displayName}</div>
                    <div className="text-[10px] text-slate-400 font-mono">{r.branch}</div>
                  </td>
                  <td className="py-2 px-3 text-right tabular-nums">{r.totalSold.toLocaleString()}</td>
                  <td className="py-2 px-3 text-right tabular-nums">{r.totalCurrentStock.toLocaleString()}</td>
                  <td
                    className={`py-2 px-3 text-right font-bold tabular-nums ${
                      r.status === 'FAST' || r.status === 'STOCKOUT'
                        ? 'text-emerald-700 dark:text-emerald-400'
                        : r.status === 'SLOW'
                          ? 'text-red-700 dark:text-red-400'
                          : 'text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    {fmtRate(r.turnRate)}
                  </td>
                  <td className="py-2 px-3 text-center">{statusBadge(r.status)}</td>
                </tr>
              ))}
              {sorted.length === 0 && (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-slate-400">
                    No outlets match your search.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      <p className="text-[10px] text-slate-400 px-1">
        Stock Turn Rate = Total Sales Qty ÷ Current Stock Qty. Higher rate = inventory converting to sales faster.
        Warehouse locations are excluded. Click any row to drill into that outlet.
      </p>
    </div>
  );
};

export default StockTurnRateDashboard;
