import React, { useMemo, useState } from 'react';
import { History, Trash2, RotateCcw, X, Database, Calendar } from 'lucide-react';
import {
  getSavedSnapshots,
  deleteSnapshot,
  type DailyInventorySnapshot,
} from '../utils/dailyStorageEngine';
import type { RawInventoryRecord } from '../types';

interface UploadHistoryPanelProps {
  isOpen: boolean;
  onClose: () => void;
  /** Restore full analysis from a saved snapshot */
  onRestore: (records: RawInventoryRecord[], label: string, periodHint?: string) => void;
}

export const UploadHistoryPanel: React.FC<UploadHistoryPanelProps> = ({
  isOpen,
  onClose,
  onRestore,
}) => {
  const [tick, setTick] = useState(0);
  const snapshots = useMemo(() => getSavedSnapshots(), [tick, isOpen]);

  if (!isOpen) return null;

  const handleDelete = (id: string) => {
    if (!confirm('Delete this upload history entry?')) return;
    deleteSnapshot(id);
    setTick((t) => t + 1);
  };

  const handleRestore = (snap: DailyInventorySnapshot) => {
    onRestore(snap.records, snap.label, snap.displayDate);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
      <div className="w-full max-w-2xl max-h-[85vh] flex flex-col rounded-xl border border-slate-700 bg-slate-900 shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between px-4 py-3 border-b border-slate-700 bg-slate-950">
          <div className="flex items-center gap-2 text-slate-100">
            <History className="w-5 h-5 text-[#0EA5E9]" />
            <div>
              <h2 className="text-sm font-bold tracking-wide">Upload History</h2>
              <p className="text-[11px] text-slate-400">
                Open a previous analysis — stock, sold &amp; matrix restored
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-3 space-y-2">
          {snapshots.length === 0 ? (
            <div className="text-center py-12 text-slate-500 text-sm">
              <Database className="w-10 h-10 mx-auto mb-2 opacity-40" />
              No saved uploads yet. After you upload Stock + Sold and apply, it appears here.
            </div>
          ) : (
            snapshots.map((s) => (
              <div
                key={s.id}
                className="flex flex-col sm:flex-row sm:items-center gap-3 rounded-lg border border-slate-700 bg-slate-950/80 px-3 py-2.5 hover:border-[#0EA5E9]/40 transition-colors"
              >
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 text-slate-100 text-sm font-semibold truncate">
                    <Calendar className="w-3.5 h-3.5 text-[#0EA5E9] shrink-0" />
                    {s.label}
                  </div>
                  <div className="text-[11px] text-slate-400 mt-1 flex flex-wrap gap-x-3 gap-y-0.5">
                    <span>{s.displayDate}</span>
                    <span>Stock: <strong className="text-slate-200">{s.totalStock}</strong></span>
                    <span>Sold: <strong className="text-slate-200">{s.totalSold}</strong></span>
                    <span>Branches: {s.branchesCount}</span>
                    <span>Items: {s.variantsCount}</span>
                    <span>{s.records.length} rows</span>
                  </div>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={() => handleRestore(s)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#0EA5E9] text-[#0a0a0c] text-xs font-bold hover:brightness-110"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    Open analysis
                  </button>
                  <button
                    type="button"
                    onClick={() => handleDelete(s.id)}
                    className="p-1.5 rounded-lg text-slate-500 hover:text-red-400 hover:bg-slate-800"
                    title="Delete"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        <div className="px-4 py-2 border-t border-slate-800 text-[10px] text-slate-500">
          Last 30 uploads kept in this browser. Clearing site data removes history.
        </div>
      </div>
    </div>
  );
};
