import React, { useMemo, useState } from 'react';
import {
  Gem,
  Layers,
  Package,
  TrendingUp,
  AlertTriangle,
  Search,
  Download,
  ChevronRight,
} from 'lucide-react';
import { RedistributionReport } from '../types';
import { getReportDimension } from '../utils/reportDimension';
import { exportDesignWiseStockExcel } from '../utils/styledReportExport';

interface DesignWiseStockAnalysisProps {
  report: RedistributionReport;
  onSelectWeight?: (weight: string) => void;
}

type OutletCell = {
  stock: number;
  sold: number;
  moveIn: number;
  moveOut: number;
  netMove: number;
};

type DesignRow = {
  design: string;
  carat: string;
  itemKey: string;
  stock: number;
  sold: number;
  refill: number;
  moveIn: number;
  moveOut: number;
  turnover: number;
  velocity: string;
  byOutlet: Record<string, OutletCell>;
};

type DesignGroup = {
  design: string;
  stock: number;
  sold: number;
  refill: number;
  lines: number;
  rows: DesignRow[];
};

function splitItemKey(key: string): { carat: string; design: string } {
  const parts = String(key || '').split(' · ');
  if (parts.length >= 2) {
    return { carat: parts[0].trim(), design: parts.slice(1).join(' · ').trim() };
  }
  return { carat: key, design: '(Category / No Style)' };
}

function isWarehouseBranch(b: string) {
  const lower = (b || '').toLowerCase().trim();
  return (
    lower === 'dwl' ||
    lower.startsWith('dwl ') ||
    lower.endsWith(' dwl') ||
    lower.includes('warehouse') ||
    lower.includes('central') ||
    lower.includes('hub')
  );
}

/**
 * Design-wise Stock Analysis
 * Groups matrix rows by Oracle style code (NP7SD1, NP7SD10…) when present;
 * shows per-outlet Stock / Sold / Move like the Excel matrix so export is easy to read.
 */
export const DesignWiseStockAnalysis: React.FC<DesignWiseStockAnalysisProps> = ({
  report,
  onSelectWeight,
}) => {
  const [search, setSearch] = useState('');
  const [selectedDesign, setSelectedDesign] = useState<string>('ALL');
  const [sortBy, setSortBy] = useState<'sold' | 'stock' | 'refill' | 'turnover'>('sold');
  const [showOutlets, setShowOutlets] = useState(true);
  const reportDimension = getReportDimension(report);
  const dimensionLabel = reportDimension.label;

  const outletColumns = useMemo(() => {
    const branches = report.matrix?.branches || report.branchSummaries.map((b) => b.branch);
    // DWL first, then retail sorted
    const dwl = branches.filter(isWarehouseBranch);
    const retail = branches.filter((b) => !isWarehouseBranch(b)).sort((a, b) => a.localeCompare(b));
    return [...dwl, ...retail];
  }, [report.matrix?.branches, report.branchSummaries]);

  const { groups, hasDesign, flatRows } = useMemo(() => {
    const cells = report.matrix?.cells || {};
    const rows: DesignRow[] = report.weightSummaries.map((w) => {
      const { carat, design } = splitItemKey(w.weight);
      const byOutlet: Record<string, OutletCell> = {};
      outletColumns.forEach((b) => {
        const c = cells[b]?.[w.weight];
        byOutlet[b] = {
          stock: c?.stock ?? 0,
          sold: c?.sold ?? 0,
          moveIn: c?.moveIn ?? 0,
          moveOut: c?.moveOut ?? 0,
          netMove: c?.netMove ?? 0,
        };
      });
      return {
        design,
        carat,
        itemKey: w.weight,
        stock: w.currentStock,
        sold: w.soldQty,
        refill: w.unmetShortage || 0,
        moveIn: w.moveInNeeded || 0,
        moveOut: w.moveOutNeeded || 0,
        turnover: w.turnoverRatio || 0,
        velocity: w.velocityCategory || '—',
        byOutlet,
      };
    });

    const hasDesign = rows.some((r) => r.design !== '(Category / No Style)');
    const map = new Map<string, DesignGroup>();

    rows.forEach((r) => {
      if (!map.has(r.design)) {
        map.set(r.design, {
          design: r.design,
          stock: 0,
          sold: 0,
          refill: 0,
          lines: 0,
          rows: [],
        });
      }
      const g = map.get(r.design)!;
      g.stock += r.stock;
      g.sold += r.sold;
      g.refill += r.refill;
      g.lines += 1;
      g.rows.push(r);
    });

    const groups = Array.from(map.values()).sort((a, b) => b.sold - a.sold);
    return { groups, hasDesign, flatRows: rows };
  }, [report.weightSummaries, report.matrix?.cells, outletColumns]);

  const filteredGroups = useMemo(() => {
    const q = search.trim().toLowerCase();
    return groups
      .filter((g) => selectedDesign === 'ALL' || g.design === selectedDesign)
      .map((g) => {
        let rows = g.rows;
        if (q) {
          // Exact design match preferred; also allow carat / key contains
          rows = rows.filter((r) => {
            const d = r.design.toLowerCase();
            if (d === q) return true;
            // word-boundary style so NP7SD1 does not match NP7SD10
            const tokenRe = new RegExp(
              `(^|[^a-z0-9])${q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}([^a-z0-9]|$)`
            );
            return (
              tokenRe.test(d) ||
              r.carat.toLowerCase().includes(q) ||
              r.itemKey.toLowerCase().includes(q)
            );
          });
        }
        rows = [...rows].sort((a, b) => {
          if (sortBy === 'sold') return b.sold - a.sold;
          if (sortBy === 'stock') return b.stock - a.stock;
          if (sortBy === 'refill') return b.refill - a.refill;
          return b.turnover - a.turnover;
        });
        return {
          ...g,
          rows,
          stock: rows.reduce((s, r) => s + r.stock, 0),
          sold: rows.reduce((s, r) => s + r.sold, 0),
          refill: rows.reduce((s, r) => s + r.refill, 0),
          lines: rows.length,
        };
      })
      .filter((g) => g.lines > 0);
  }, [groups, search, selectedDesign, sortBy]);

  const totals = useMemo(() => {
    return filteredGroups.reduce(
      (acc, g) => ({
        stock: acc.stock + g.stock,
        sold: acc.sold + g.sold,
        refill: acc.refill + g.refill,
        designs: acc.designs + 1,
        lines: acc.lines + g.lines,
      }),
      { stock: 0, sold: 0, refill: 0, designs: 0, lines: 0 }
    );
  }, [filteredGroups]);

  const handleExport = () => {
    exportDesignWiseStockExcel(
      filteredGroups.map((g) => ({
        design: g.design,
        rows: g.rows.map((r) => ({ carat: r.carat, stock: r.stock, sold: r.sold, refill: r.refill, byOutlet: r.byOutlet })),
      })),
      showOutlets ? outletColumns : [],
      report.period,
      dimensionLabel
    ).catch((error) => {
      console.error('Design-wise export failed:', error);
      window.alert(`Excel export failed: ${error instanceof Error ? error.message : 'Please try again.'}`);
    });
  };

  const periodLabel = report.period || '—';

  return (
    <div className="space-y-3">
      {/* Header */}
      <div className="bg-white border border-[#d0d7de] px-3 py-2.5 flex flex-wrap items-center justify-between gap-2">
        <div>
          <h2 className="text-sm font-bold text-[#0f2744] flex items-center gap-2">
            <Layers className="w-4 h-4 text-[#0B6FB8]" />
            Design-wise Stock Analysis
          </h2>
          <p className="text-[11px] text-[#6a6d70] mt-0.5">
            {hasDesign
              ? 'Style sheets detected — analysis grouped by design code (exact match: NP7SD1 ≠ NP7SD10)'
              : 'Category-level data — upload Oracle style sheets for design breakdown'}
            {' · '}
            Period: <strong className="text-[#32363a]">{periodLabel}</strong>
          </p>
        </div>
        <div className="flex items-center gap-2">
          <label className="inline-flex items-center gap-1.5 text-[11px] text-[#32363a] cursor-pointer select-none">
            <input
              type="checkbox"
              checked={showOutlets}
              onChange={(e) => setShowOutlets(e.target.checked)}
              className="rounded border-[#89919a]"
            />
            Show outlets
          </label>
          <button
            type="button"
            onClick={handleExport}
            className="inline-flex items-center gap-1.5 h-8 px-3 text-[12px] font-semibold bg-[#0B6FB8] text-white border border-[#0B6FB8] hover:bg-[#0B8BD6]"
          >
            <Download className="w-3.5 h-3.5" />
            Export Excel
          </button>
        </div>
      </div>

      {/* KPI strip */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
        {[
          { label: 'Designs', value: totals.designs, icon: Layers, color: 'text-[#0B6FB8]' },
          { label: `${dimensionLabel} lines`, value: totals.lines, icon: Gem, color: 'text-amber-700' },
          { label: 'Total Stock', value: totals.stock, icon: Package, color: 'text-emerald-700' },
          { label: 'Total Sold', value: totals.sold, icon: TrendingUp, color: 'text-blue-700' },
          { label: 'Refill Need', value: totals.refill, icon: AlertTriangle, color: 'text-red-700' },
        ].map((k) => (
          <div key={k.label} className="bg-white border border-[#d0d7de] px-3 py-2">
            <div className="text-[10px] font-semibold text-[#6a6d70] uppercase tracking-wide flex items-center gap-1">
              <k.icon className={`w-3 h-3 ${k.color}`} />
              {k.label}
            </div>
            <div className="text-lg font-bold text-[#29445F] font-mono tabular-nums">
              {k.value.toLocaleString()}
            </div>
          </div>
        ))}
      </div>

      {/* Toolbar */}
      <div className="bg-[#edf0f4] border border-[#d9d9d9] px-3 py-2 flex flex-wrap items-end gap-2">
        <div className="min-w-[140px]">
          <label className="block text-[10px] text-[#6a6d70] mb-0.5">Design / Style</label>
          <select
            value={selectedDesign}
            onChange={(e) => setSelectedDesign(e.target.value)}
            className="h-8 border border-[#89919a] bg-white px-2 text-[12px] min-w-[140px]"
          >
            <option value="ALL">All designs</option>
            {groups.map((g) => (
              <option key={g.design} value={g.design}>
                {g.design} ({g.lines})
              </option>
            ))}
          </select>
        </div>
        <div className="min-w-[100px]">
          <label className="block text-[10px] text-[#6a6d70] mb-0.5">Sort by</label>
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as typeof sortBy)}
            className="h-8 border border-[#89919a] bg-white px-2 text-[12px]"
          >
            <option value="sold">Sold</option>
            <option value="stock">Stock</option>
            <option value="refill">Refill</option>
            <option value="turnover">Sell-through</option>
          </select>
        </div>
        <div className="flex-1 min-w-[160px]">
          <label className="block text-[10px] text-[#6a6d70] mb-0.5">Search (exact design preferred)</label>
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-2 top-1/2 -translate-y-1/2 text-[#89919a]" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="NP7SD1, 0.05…"
              className="w-full h-8 border border-[#89919a] bg-white pl-7 pr-2 text-[12px]"
            />
          </div>
        </div>
      </div>

      {/* Design summary cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
        {filteredGroups.map((g) => {
          const sellThrough = g.stock + g.sold > 0 ? (g.sold / (g.stock + g.sold)) * 100 : 0;
          return (
            <button
              key={g.design}
              type="button"
              onClick={() => setSelectedDesign(selectedDesign === g.design ? 'ALL' : g.design)}
              className={`text-left bg-white border px-3 py-2.5 hover:border-[#0B6FB8] transition-colors ${
                selectedDesign === g.design ? 'border-[#0B6FB8] ring-1 ring-[#0B6FB8]/30' : 'border-[#d0d7de]'
              }`}
            >
              <div className="flex items-center justify-between gap-2">
                <span className="text-[13px] font-bold text-[#0f2744] font-mono truncate">{g.design}</span>
                <ChevronRight className="w-3.5 h-3.5 text-[#89919a] shrink-0" />
              </div>
              <div className="mt-1.5 grid grid-cols-3 gap-1 text-[11px]">
                <div>
                  <div className="text-[#6a6d70]">Stock</div>
                  <div className="font-bold font-mono">{g.stock.toLocaleString()}</div>
                </div>
                <div>
                  <div className="text-[#6a6d70]">Sold</div>
                  <div className="font-bold font-mono text-blue-700">{g.sold.toLocaleString()}</div>
                </div>
                <div>
                  <div className="text-[#6a6d70]">Refill</div>
                  <div className={`font-bold font-mono ${g.refill > 0 ? 'text-red-600' : 'text-emerald-700'}`}>
                    {g.refill.toLocaleString()}
                  </div>
                </div>
              </div>
              <div className="mt-1.5 h-1.5 bg-[#e8e8e8] overflow-hidden">
                <div
                  className="h-full bg-[#0B6FB8]"
                  style={{ width: `${Math.min(100, sellThrough)}%` }}
                />
              </div>
              <div className="text-[10px] text-[#6a6d70] mt-0.5">
                {g.lines} carat lines · sell-through {sellThrough.toFixed(0)}%
              </div>
            </button>
          );
        })}
      </div>

      {/* Detail grid — Design × Carat × Outlets (like Excel matrix) */}
      <div className="bg-white border border-[#d0d7de] overflow-hidden">
        <div className="px-3 py-1.5 bg-[#f6f8fa] border-b border-[#d0d7de] text-[11px] font-semibold text-[#32363a] flex flex-wrap items-center justify-between gap-2">
          <span>
            {dimensionLabel} × Design × Outlet detail
            {selectedDesign !== 'ALL' ? ` · ${selectedDesign}` : ''}
            {' · '}
            <span className="font-normal text-[#6a6d70]">Period: {periodLabel}</span>
          </span>
          {showOutlets && (
            <span className="font-normal text-[#6a6d70]">
              Outlets: Stock / Sold / Move (green = IN, pink = OUT)
            </span>
          )}
        </div>
        <div className="overflow-x-auto max-h-[560px]">
          <table className="w-full text-[11px] border-collapse">
            <thead className="sticky top-0 bg-[#f6f8fa] z-10">
              <tr>
                <th className="border border-[#d0d7de] px-2 py-1.5 text-left font-semibold text-[#32363a] whitespace-nowrap sticky left-0 bg-[#f6f8fa] z-20">
                  Design
                </th>
                <th className="border border-[#d0d7de] px-2 py-1.5 text-left font-semibold text-[#32363a] whitespace-nowrap">
                  {dimensionLabel}
                </th>
                <th className="border border-[#d0d7de] px-2 py-1.5 text-right font-semibold text-[#32363a] whitespace-nowrap">
                  Total Stock
                </th>
                <th className="border border-[#d0d7de] px-2 py-1.5 text-right font-semibold text-[#32363a] whitespace-nowrap">
                  Total Sold
                </th>
                <th className="border border-[#d0d7de] px-2 py-1.5 text-right font-semibold text-[#32363a] whitespace-nowrap">
                  Refill
                </th>
                {showOutlets &&
                  outletColumns.map((b) => (
                    <th
                      key={b}
                      colSpan={3}
                      className={`border border-[#d0d7de] px-1 py-1 text-center font-bold whitespace-nowrap ${
                        isWarehouseBranch(b) ? 'bg-[#e8f0fe] text-[#0B6FB8]' : 'bg-[#f0f4f8] text-[#32363a]'
                      }`}
                    >
                      {b}
                    </th>
                  ))}
                <th className="border border-[#d0d7de] px-2 py-1.5 text-right font-semibold text-[#32363a] whitespace-nowrap">
                  Sell-through
                </th>
                <th className="border border-[#d0d7de] px-2 py-1.5 text-left font-semibold text-[#32363a] whitespace-nowrap">
                  Velocity
                </th>
              </tr>
              {showOutlets && (
                <tr>
                  <th className="border border-[#d0d7de] px-1 py-0.5 sticky left-0 bg-[#f6f8fa] z-20" />
                  <th className="border border-[#d0d7de] px-1 py-0.5" />
                  <th className="border border-[#d0d7de] px-1 py-0.5" />
                  <th className="border border-[#d0d7de] px-1 py-0.5" />
                  <th className="border border-[#d0d7de] px-1 py-0.5" />
                  {outletColumns.map((b) => (
                    <React.Fragment key={`${b}-sub`}>
                      <th className="border border-[#d0d7de] px-1 py-0.5 text-[9px] font-medium text-[#6a6d70] text-right">
                        Stk
                      </th>
                      <th className="border border-[#d0d7de] px-1 py-0.5 text-[9px] font-medium text-[#6a6d70] text-right">
                        Sold
                      </th>
                      <th className="border border-[#d0d7de] px-1 py-0.5 text-[9px] font-medium text-[#6a6d70] text-right">
                        Move
                      </th>
                    </React.Fragment>
                  ))}
                  <th className="border border-[#d0d7de] px-1 py-0.5" />
                  <th className="border border-[#d0d7de] px-1 py-0.5" />
                </tr>
              )}
            </thead>
            <tbody>
              {filteredGroups.flatMap((g) =>
                g.rows.map((r) => (
                  <tr
                    key={r.itemKey}
                    className="hover:bg-[#eef5ff] cursor-pointer"
                    onClick={() => onSelectWeight?.(r.itemKey)}
                  >
                    <td className="border border-[#e6e8eb] px-2 py-1 font-mono font-semibold text-[#0B6FB8] sticky left-0 bg-white z-10">
                      {r.design}
                    </td>
                    <td className="border border-[#e6e8eb] px-2 py-1 font-mono">{r.carat}</td>
                    <td className="border border-[#e6e8eb] px-2 py-1 text-right font-mono">{r.stock}</td>
                    <td className="border border-[#e6e8eb] px-2 py-1 text-right font-mono text-blue-700">
                      {r.sold}
                    </td>
                    <td
                      className={`border border-[#e6e8eb] px-2 py-1 text-right font-mono font-bold ${
                        r.refill > 0 ? 'text-red-600' : 'text-slate-400'
                      }`}
                    >
                      {r.refill || '—'}
                    </td>
                    {showOutlets &&
                      outletColumns.map((b) => {
                        const c = r.byOutlet[b] || {
                          stock: 0,
                          sold: 0,
                          moveIn: 0,
                          moveOut: 0,
                          netMove: 0,
                        };
                        const net = c.netMove !== 0 ? c.netMove : c.moveIn - c.moveOut;
                        return (
                          <React.Fragment key={`${r.itemKey}-${b}`}>
                            <td className="border border-[#e6e8eb] px-1 py-1 text-right font-mono tabular-nums">
                              {c.stock || '—'}
                            </td>
                            <td className="border border-[#e6e8eb] px-1 py-1 text-right font-mono tabular-nums text-blue-700">
                              {c.sold || '—'}
                            </td>
                            <td
                              className={`border border-[#e6e8eb] px-1 py-1 text-right font-mono tabular-nums font-semibold ${
                                net > 0
                                  ? 'bg-emerald-50 text-emerald-800'
                                  : net < 0
                                    ? 'bg-red-50 text-red-700'
                                    : 'text-slate-400'
                              }`}
                            >
                              {net > 0 ? `+${net}` : net < 0 ? `${net}` : '—'}
                            </td>
                          </React.Fragment>
                        );
                      })}
                    <td className="border border-[#e6e8eb] px-2 py-1 text-right font-mono">
                      {r.turnover.toFixed(1)}%
                    </td>
                    <td className="border border-[#e6e8eb] px-2 py-1">
                      <span
                        className={`inline-block px-1.5 py-0.5 text-[10px] font-semibold ${
                          r.velocity === 'Best-Seller'
                            ? 'bg-emerald-50 text-emerald-800'
                            : r.velocity === 'Zero-Sales Stock'
                              ? 'bg-red-50 text-red-800'
                              : 'bg-slate-50 text-slate-600'
                        }`}
                      >
                        {r.velocity}
                      </span>
                    </td>
                  </tr>
                ))
              )}
              {filteredGroups.length === 0 && (
                <tr>
                  <td
                    colSpan={5 + (showOutlets ? outletColumns.length * 3 : 0) + 2}
                    className="px-3 py-8 text-center text-[#6a6d70]"
                  >
                    No design rows — upload stock/sold style sheets (NP7SD1, NP7SD10…) or clear filters.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
