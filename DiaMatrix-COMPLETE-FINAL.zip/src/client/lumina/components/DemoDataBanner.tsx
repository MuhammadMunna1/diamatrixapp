import React from 'react';
import { AlertTriangle, UploadCloud, X } from 'lucide-react';
import { BRAND } from '../brand';

interface DemoDataBannerProps {
  visible: boolean;
  onUpload: () => void;
  onDismiss?: () => void;
}

/**
 * Shown when console is running on built-in sample rows — not production data.
 */
export const DemoDataBanner: React.FC<DemoDataBannerProps> = ({
  visible,
  onUpload,
  onDismiss,
}) => {
  if (!visible) return null;

  return (
    <div
      className="mx-2 sm:mx-4 mt-2 rounded border px-3 py-2 flex flex-wrap items-center justify-between gap-2 text-[12px]"
      style={{
        background: 'rgba(245, 158, 11, 0.12)',
        borderColor: 'rgba(245, 158, 11, 0.45)',
        color: 'var(--shell-fg)',
      }}
      role="status"
    >
      <div className="flex items-start gap-2 min-w-0">
        <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
        <div>
          <strong className="text-amber-800 dark:text-amber-300">Demo dataset active</strong>
          <span className="opacity-80">
            {' '}
            — {BRAND.short} is showing sample rows so modules load. Upload your Stock + Sold files for
            live outlet decisions.
          </span>
        </div>
      </div>
      <div className="flex items-center gap-2 shrink-0">
        <button
          type="button"
          onClick={onUpload}
          className="sw-btn-primary sw-btn inline-flex items-center gap-1.5"
        >
          <UploadCloud className="w-3.5 h-3.5" />
          Upload Stock / Sold
        </button>
        {onDismiss && (
          <button type="button" onClick={onDismiss} className="sw-btn p-1.5" title="Dismiss">
            <X className="w-3.5 h-3.5" />
          </button>
        )}
      </div>
    </div>
  );
};
