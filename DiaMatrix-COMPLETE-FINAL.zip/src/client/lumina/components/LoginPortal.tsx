import React, { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  AlertCircle,
  Check,
  ChevronRight,
  Eye,
  EyeOff,
  KeyRound,
  Loader2,
  Lock,
  ShieldCheck,
  User,
  WifiOff,
  X,
} from 'lucide-react';
import { AuthUser } from '../types';
import { authenticateUser, authenticateOffline, requestPasswordRecovery, requestSignup } from '../utils/authEngine';
import {
  getTurnstileSiteKey,
  loadTurnstileScript,
  verifyTurnstileToken,
  isTurnstileEnabled,
  isTurnstileTestMode,
} from '../utils/cloudflareTurnstile';
import { BRAND } from '../brand';
import { MshOrbitCredit } from './MshOrbitCredit';

interface LoginPortalProps {
  onLoginSuccess: (user: AuthUser) => void;
}

type Mode = 'login' | 'signup' | 'forgot';
type ServerStatus = 'checking' | 'online' | 'offline';

/** Igniting logo reveal BG — watermark removed, full-bleed cover */
const LOGIN_VIDEO_SRC = '/lumina-login-reveal.mp4?v=7';
const LOGIN_POSTER_SRC = '/lumina-login-reveal-poster.jpg?v=7';

export const LoginPortal: React.FC<LoginPortalProps> = ({ onLoginSuccess }) => {
  const [mode, setMode] = useState<Mode>('login');
  const [name, setName] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [agreedToTerms, setAgreedToTerms] = useState(true);
  const [message, setMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [serverStatus, setServerStatus] = useState<ServerStatus>('checking');
  const [showLoginCard, setShowLoginCard] = useState(false);
  /** When true, video file missing/failed — show static poster as full-bleed background */
  const [videoFailed, setVideoFailed] = useState(false);
  const [turnstileToken, setTurnstileToken] = useState('');
  const [turnstileReady, setTurnstileReady] = useState(false);
  const turnstileRef = useRef<HTMLDivElement>(null);
  const turnstileWidgetId = useRef<string | null>(null);
  const [mfaCode, setMfaCode] = useState('');
  const [showMfaField, setShowMfaField] = useState(false);

  // ── Subtle mouse-parallax (scaled so edges never show black) ──
  const stageRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const [parallax, setParallax] = useState({ x: 0, y: 0 });

  const handleStageMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const el = stageRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const nx = (e.clientX - rect.left) / rect.width - 0.5;
    const ny = (e.clientY - rect.top) / rect.height - 0.5;
    // Minimal parallax so Diamond World end-card stays visually centered
    setParallax({
      x: nx * 8,
      y: ny * 6,
    });
  };

  const handleStageMouseLeave = () => {
    setParallax({ x: 0, y: 0 });
  };

  // ── Reliable autoplay ──
  useEffect(() => {
    setVideoFailed(false);
    const video = videoRef.current;
    if (!video) return;

    video.muted = true;
    video.defaultMuted = true;
    video.setAttribute('muted', '');
    video.setAttribute('playsinline', '');
    video.playsInline = true;

    const tryPlay = () => {
      const p = video.play();
      if (p && typeof p.then === 'function') {
        p.catch(() => {
          /* Autoplay blocked — retry on next gesture */
        });
      }
    };

    const onError = () => setVideoFailed(true);

    tryPlay();

    const onVisibility = () => {
      if (document.visibilityState === 'visible' && video.paused) tryPlay();
    };
    const onCanPlay = () => tryPlay();
    const onLoaded = () => tryPlay();

    document.addEventListener('visibilitychange', onVisibility);
    video.addEventListener('canplay', onCanPlay);
    video.addEventListener('loadeddata', onLoaded);
    video.addEventListener('error', onError);

    const unlock = () => {
      tryPlay();
      window.removeEventListener('pointerdown', unlock);
      window.removeEventListener('keydown', unlock);
      window.removeEventListener('touchstart', unlock);
    };
    window.addEventListener('pointerdown', unlock, { once: true });
    window.addEventListener('keydown', unlock, { once: true });
    window.addEventListener('touchstart', unlock, { once: true });

    return () => {
      document.removeEventListener('visibilitychange', onVisibility);
      video.removeEventListener('canplay', onCanPlay);
      video.removeEventListener('loadeddata', onLoaded);
      video.removeEventListener('error', onError);
      window.removeEventListener('pointerdown', unlock);
      window.removeEventListener('keydown', unlock);
      window.removeEventListener('touchstart', unlock);
    };
  }, []);

  useEffect(() => {
    let cancelled = false;
    const checkHealth = async () => {
      try {
        const res = await fetch('/api/health', { credentials: 'include' });
        if (!cancelled) setServerStatus(res.ok ? 'online' : 'offline');
      } catch {
        if (!cancelled) setServerStatus('offline');
      }
    };
    checkHealth();
    return () => {
      cancelled = true;
    };
  }, []);

  // Close login card on Escape
  useEffect(() => {
    if (!showLoginCard) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setShowLoginCard(false);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [showLoginCard]);

  const clearNotice = () => {
    setMessage('');
    setErrorMessage('');
  };

  const resetTurnstile = () => {
    setTurnstileToken('');
    setTurnstileReady(false);
    if (turnstileWidgetId.current && window.turnstile) {
      try {
        window.turnstile.reset(turnstileWidgetId.current);
      } catch {
        /* ignore */
      }
    }
  };

  // Cloudflare Turnstile — only render clean widget when real site key is set
  useEffect(() => {
    if (!showLoginCard) return;

    // No real key → hide widget completely (no test banner / extra text), auto-ready
    if (!isTurnstileEnabled()) {
      setTurnstileToken('');
      setTurnstileReady(true);
      return;
    }

    let cancelled = false;
    (async () => {
      try {
        await loadTurnstileScript();
        if (cancelled || !turnstileRef.current || !window.turnstile) return;
        if (turnstileWidgetId.current) {
          try {
            window.turnstile.remove(turnstileWidgetId.current);
          } catch {
            /* ignore */
          }
          turnstileWidgetId.current = null;
        }
        turnstileRef.current.innerHTML = '';
        const id = window.turnstile.render(turnstileRef.current, {
          sitekey: getTurnstileSiteKey(),
          theme: 'light',
          size: 'normal', // classic "Verify you are human" checkbox
          callback: (token: string) => {
            setTurnstileToken(token);
            setTurnstileReady(true);
          },
          'error-callback': () => {
            setTurnstileToken('');
            setTurnstileReady(false);
          },
          'expired-callback': () => {
            setTurnstileToken('');
            setTurnstileReady(false);
          },
        });
        turnstileWidgetId.current = id;
      } catch {
        setTurnstileReady(false);
      }
    })();
    return () => {
      cancelled = true;
      if (turnstileWidgetId.current && window.turnstile) {
        try {
          window.turnstile.remove(turnstileWidgetId.current);
        } catch {
          /* ignore */
        }
        turnstileWidgetId.current = null;
      }
    };
  }, [showLoginCard, mode]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    clearNotice();
    if (mode !== 'login' && !agreedToTerms) {
      setErrorMessage('Please accept the access terms to continue.');
      return;
    }
    setIsLoading(true);

    try {
      if (mode === 'login') {
        if (offlineLocalOnly) {
          const result = await authenticateOffline(username, password);
          if (result.success && result.user) {
            onLoginSuccess(result.user);
          } else {
            setErrorMessage(result.error || 'Offline credentials rejected.');
          }
          setIsLoading(false);
          return;
        }
        if (!turnstileToken && !isTurnstileTestMode()) {
          setErrorMessage('Please complete the Cloudflare security check.');
          setIsLoading(false);
          return;
        }
        const gate = await verifyTurnstileToken(turnstileToken || '');
        if (!gate.ok) {
          setErrorMessage(gate.error || 'Security check failed.');
          resetTurnstile();
          setIsLoading(false);
          return;
        }
        const result = await authenticateUser(username, password, turnstileToken);
        if (result.success && result.user) {
          onLoginSuccess(result.user);
        } else {
          setErrorMessage(result.error || 'Invalid username or password.');
          resetTurnstile();
        }
      } else if (mode === 'signup') {
        const result = await requestSignup({ username, name, password });
        if (result.success) {
          setMessage(result.message || 'Account request submitted.');
          setMode('login');
          setPassword('');
        } else {
          setErrorMessage(result.error || 'Could not create account request.');
        }
      } else {
        const result = await requestPasswordRecovery(username);
        if (result.success) {
          setMessage(result.message || 'Recovery request submitted.');
        } else {
          setErrorMessage(result.error || 'Could not submit recovery request.');
        }
      }
    } finally {
      setIsLoading(false);
    }
  };

  const switchMode = (next: Mode) => {
    if (serverStatus === 'offline' && next !== 'login') {
      setErrorMessage('Signup and recovery require a live server connection. Use local credentials to sign in offline.');
      return;
    }
    setMode(next);
    setPassword('');
    setMfaCode('');
    setShowMfaField(false);
    clearNotice();
  };

  const openLogin = () => {
    setMode('login');
    clearNotice();
    setShowLoginCard(true);
  };

  const heading =
    mode === 'login' ? 'Sign In' : mode === 'signup' ? 'Request Access' : 'Recover Account';

  const subheading =
    mode === 'login'
      ? 'Authenticate to access the intelligence console'
      : mode === 'signup'
        ? 'Submit details for system owner approval'
        : 'Enter username to request a password reset';

  const submitLabel =
    mode === 'login' ? 'Sign In' : mode === 'signup' ? 'Submit Request' : 'Send Recovery Link';


  const passwordHint = (() => {
    if (!password) return null;
    const len = password.length;
    if (len < 4) return { label: 'Too short', tone: 'text-amber-600' };
    if (len < 8) return { label: 'Basic strength', tone: 'text-[#0C94D0]' };
    if (!/[A-Za-z]/.test(password) || !/[0-9]/.test(password)) {
      return { label: 'Add letters and numbers for stronger security', tone: 'text-[#4F6B88]' };
    }
    return { label: 'Strong password', tone: 'text-emerald-600' };
  })();

  const offlineLocalOnly = serverStatus === 'offline';
  /** Freeze interactive chrome while loading; offline still allows local credential entry */
  const fieldsDisabled = isLoading;
  const offlineFieldClass = offlineLocalOnly
    ? ' opacity-95'
    : '';


  return (
    <div
      ref={stageRef}
      onMouseMove={handleStageMouseMove}
      onMouseLeave={handleStageMouseLeave}
      className="relative min-h-screen w-full font-body overflow-hidden flex flex-col bg-[#F6FAFD]"
    >
      {/* ══════════════ FULL SCREEN BACKGROUND — covers entire viewport, logo centered ══════════════ */}
      <div className="pointer-events-none absolute inset-0 z-0 overflow-hidden bg-[#F6FAFD]">
        {videoFailed ? (
          <motion.div
            animate={{ x: parallax.x, y: parallax.y }}
            transition={{ type: 'spring', stiffness: 60, damping: 18, mass: 0.8 }}
            className="absolute left-1/2 top-1/2 min-h-full min-w-full -translate-x-1/2 -translate-y-1/2 bg-cover bg-center"
            style={{
              width: '100vw',
              height: '100vh',
              backgroundImage: `url(${LOGIN_POSTER_SRC})`,
              backgroundPosition: 'center center',
              backgroundSize: 'cover',
              filter: 'brightness(0.82) saturate(1.1) contrast(1.04)',
            }}
          />
        ) : (
          <motion.video
            ref={videoRef}
            src={LOGIN_VIDEO_SRC}
            poster={LOGIN_POSTER_SRC}
            autoPlay
            loop
            muted
            playsInline
            preload="auto"
            disablePictureInPicture
            disableRemotePlayback
            onError={() => setVideoFailed(true)}
            animate={{ x: parallax.x, y: parallax.y }}
            transition={{ type: 'spring', stiffness: 60, damping: 18, mass: 0.8 }}
            className="absolute left-1/2 top-1/2 max-w-none -translate-x-1/2 -translate-y-1/2"
            style={{
              /* Full-bleed cover — landscape 16:9 reveal fills viewport, no letterbox */
              width: '100vw',
              height: '100vh',
              minWidth: '100%',
              minHeight: '100%',
              objectFit: 'cover',
              objectPosition: 'center center',
              filter: 'brightness(0.92) saturate(1.08) contrast(1.05)',
            }}
          />
        )}
      </div>

      {/* Soft vignette — light edges only so logo stays visible & centered */}
      <div
        className="pointer-events-none absolute inset-0"
        style={{
          background:
            'radial-gradient(ellipse 90% 80% at 50% 48%, transparent 35%, rgba(4,7,15,0.2) 70%, rgba(4,7,15,0.55) 100%),' +
            'linear-gradient(180deg, rgba(4,7,15,0.35) 0%, transparent 18%, transparent 82%, rgba(4,7,15,0.45) 100%)',
        }}
      />

      {/* ══════════════ Developed by MSH — Endurance ring + black hole ══════════════ */}
      <MshOrbitCredit />

      {/* ══════════════ TOP BAR — logo left, Log in button top-right (OpenAI Astra style) ══════════════ */}
      <header className="relative z-20 w-full px-4 sm:px-8 lg:px-10 pt-[max(0.25rem,env(safe-area-inset-top))] sm:pt-2 flex flex-wrap items-center justify-between gap-3">
        {/* Brand mark — larger logo + slogan */}
        <div className="flex items-center gap-1 sm:gap-1.5">
          <div className="flex shrink-0 flex-col items-start">
            <div className="flex items-center gap-3">
              <img
                src="/diamatrix-mark.svg"
                alt=""
                className="h-14 w-auto select-none sm:h-16 dmx-logo-3d dmx-logo-spin"
                draggable={false}
              />
              <div className="flex flex-col leading-tight">
                <span className="font-display text-3xl font-semibold tracking-tight text-white sm:text-4xl">{BRAND.short}</span>
                <span className="text-xs font-semibold text-[#BFE6F8] sm:text-sm">by {BRAND.company}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Top-right actions — Log in + optional CTA */}
        <div className="flex flex-wrap items-center justify-end gap-2 sm:gap-3">
          <button
            type="button"
            onClick={openLogin}
            className="inline-flex items-center justify-center rounded-full border border-white/25 bg-white/5 px-4 sm:px-5 py-2 text-sm font-medium text-white/95 backdrop-blur-md transition hover:bg-white/15 hover:border-white/40 active:scale-[0.98]"
          >
            Log in
          </button>
          <button
            type="button"
            onClick={openLogin}
            className="inline-flex items-center justify-center rounded-full bg-white px-4 sm:px-5 py-2 text-sm font-semibold text-[#0B2545] transition hover:bg-white/90 active:scale-[0.98]"
          >
            Enter Console
          </button>
        </div>
      </header>

      {/* ══════════════ HERO — clean center so video logo stays focal ══════════════ */}
      <div className="relative z-10 flex-1 flex flex-col items-center justify-center px-4 pointer-events-none">
        {/* Intentionally empty — brand video is the hero */}
      </div>

      {/* ══════════════ FOOTER ══════════════ */}
      <footer className="relative z-10 w-full px-6 sm:px-10 pt-4 pb-8 sm:pb-10 flex flex-col items-center gap-1.5 text-center">
        <p className="font-body text-xs sm:text-sm font-medium tracking-wide text-slate-300/70">
          © {new Date().getFullYear()} {BRAND.full}
        </p>
        <p className="font-body text-[11px] sm:text-xs font-normal tracking-[0.12em] uppercase text-slate-300/50">
          {BRAND.tagline}
        </p>
      </footer>

      {/* ══════════════ LOGIN CARD OVERLAY — appears on Log in click ══════════════ */}
      <AnimatePresence>
        {showLoginCard && (
          <>
            {/* Backdrop */}
            <motion.div
              key="backdrop"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.25 }}
              className="fixed inset-0 z-40 bg-black/55 backdrop-blur-[2px]"
              onClick={() => setShowLoginCard(false)}
            />

            {/* Card container */}
            <motion.div
              key="card-wrap"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-50 flex items-center justify-center px-3 py-4 pointer-events-none"
            >
              <motion.div
                initial={{ opacity: 0, scale: 0.94, y: 16 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.96, y: 10 }}
                transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
                className="pointer-events-auto w-full max-w-[320px] relative"
                onClick={(e) => e.stopPropagation()}
              >
                <div
                  style={{
                    background:
                      'linear-gradient(180deg, rgba(255,255,255,0.98) 0%, rgba(246,250,253,0.96) 100%)',
                    borderColor: 'rgba(207, 230, 245, 0.95)',
                    boxShadow:
                      '0 1px 0 rgba(255,255,255,0.9) inset, 0 28px 64px rgba(6, 20, 43, 0.38), 0 8px 24px rgba(20, 180, 232, 0.12), 0 0 0 1px rgba(20, 180, 232, 0.06)',
                  }}
                  className="relative rounded-2xl border backdrop-blur-2xl backdrop-saturate-150 p-4 sm:p-5 transition-shadow duration-300"
                >
                  {/* Close button */}
                  <button
                    type="button"
                    aria-label="Close"
                    onClick={() => setShowLoginCard(false)}
                    className="absolute top-2.5 right-2.5 h-7 w-7 rounded-full flex items-center justify-center text-[#4F6B88] hover:text-[#0B2545] hover:bg-[#E6F4FC] transition"
                  >
                    <X className="h-4 w-4" />
                  </button>

                  {/* Corner Gold accent */}
                  <div className="pointer-events-none absolute top-0 left-8 right-8 h-px bg-gradient-to-r from-transparent via-[#14B4E8] to-transparent opacity-80" />

                  {/* Mode title + status header */}
                  <div className="mb-3 flex items-start justify-between gap-2 pr-7">
                    <div className="text-left">
                      <h2 className="font-display text-lg font-semibold text-[#0B2545] tracking-tight">
                        {heading}
                      </h2>
                      <p className="text-xs text-[#4F6B88] mt-1 font-body">{subheading}</p>
                    </div>
                    <div
                      className="h-9 w-9 rounded-xl flex items-center justify-center shadow-inner shrink-0 border"
                      style={{
                        background:
                          'linear-gradient(135deg, rgba(20, 180, 232, 0.22) 0%, rgba(255,255,255,0.6) 100%)',
                        borderColor: 'rgba(20, 180, 232, 0.5)',
                        color: '#14B4E8',
                      }}
                    >
                      <Lock className="h-4 w-4" />
                    </div>
                  </div>

                  {/* Notices */}
                  <AnimatePresence mode="wait">
                    {serverStatus === 'offline' && (
                      <motion.div
                        key="offline"
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        className="mb-4 rounded-xl border border-amber-400/50 bg-gradient-to-br from-amber-50 via-orange-50/90 to-amber-50/80 p-3.5 text-xs text-amber-950 shadow-sm"
                      >
                        <div className="flex items-start gap-2.5">
                          <WifiOff className="mt-0.5 h-4 w-4 shrink-0 text-amber-700" />
                          <div className="space-y-2 min-w-0">
                            <p className="font-bold text-[12px] text-amber-950 tracking-tight">
                              Server offline — local access mode
                            </p>
                            <p className="text-amber-900/95 leading-relaxed font-medium">
                              Cloud sign-in is unavailable. Use local credentials to unlock offline analytics on this device. Remote account recovery and signup are disabled until the server returns.
                            </p>
                            <ul className="grid grid-cols-1 gap-1 text-[11px] text-amber-900/90 list-disc pl-4">
                              <li>Inventory matrix &amp; Have vs Deserve allocation</li>
                              <li>Movement / aging snapshots stored in this browser</li>
                              <li>Excel &amp; PDF export of local working datasets</li>
                            </ul>
                          </div>
                        </div>
                      </motion.div>
                    )}
                    {message && (
                      <motion.div
                        key="message"
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        className="mb-4 flex items-start gap-2 rounded-xl border border-emerald-400/30 bg-emerald-50 p-3 text-xs text-emerald-700"
                      >
                        <Check className="mt-0.5 h-4 w-4 shrink-0" />
                        <span>{message}</span>
                      </motion.div>
                    )}
                    {errorMessage && (
                      <motion.div
                        key="error"
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        className="mb-4 flex items-start gap-2 rounded-xl border border-red-400/30 bg-red-50 p-3 text-xs text-red-700"
                      >
                        <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
                        <span>{errorMessage}</span>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  {/* Form */}
                  <form onSubmit={handleSubmit} className={`space-y-2.5${offlineLocalOnly ? " relative" : ""}`}>
                    {mode === 'signup' && (
                      <div>
                        <label className="block text-[10px] font-semibold text-[#3D5A73] mb-1.5 uppercase tracking-wider">
                          Full Name
                        </label>
                        <input
                          required
                          type="text"
                          value={name}
                          onChange={(e) => setName(e.target.value)}
                          placeholder="Enter your full name"
                          autoComplete="name"
                          className="w-full rounded-xl border border-[#B7D6EB] bg-white px-3.5 py-2.5 text-[13px] text-[#0B2545] placeholder:text-[#4A6A86] placeholder:font-medium outline-none shadow-[inset_0_1px_2px_rgba(11,37,69,0.04)] focus:border-[#14B4E8] focus:bg-white focus:ring-2 focus:ring-[#14B4E8]/20 transition disabled:opacity-60 disabled:cursor-not-allowed disabled:bg-[#F0F5F9]"
                        />
                      </div>
                    )}

                    <div>
                      <label className="flex items-center gap-1.5 text-[10px] font-semibold text-[#3D5A73] mb-1.5 uppercase tracking-wider">
                        <User className="h-3 w-3 text-[#14B4E8]" /> Username
                      </label>
                      <input
                        required
                        type="text"
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        placeholder="Enter your username"
                        autoComplete="username"
                        disabled={fieldsDisabled}
                        className="w-full rounded-xl border border-[#B7D6EB] bg-white px-3.5 py-2.5 text-[13px] text-[#0B2545] placeholder:text-[#4A6A86] placeholder:font-medium outline-none shadow-[inset_0_1px_2px_rgba(11,37,69,0.04)] focus:border-[#14B4E8] focus:bg-white focus:ring-2 focus:ring-[#14B4E8]/20 transition disabled:opacity-60 disabled:cursor-not-allowed disabled:bg-[#F0F5F9]"
                      />
                    </div>

                    {mode !== 'forgot' && (
                      <div>
                        <label className="flex items-center gap-1.5 text-[10px] font-semibold text-[#3D5A73] mb-1.5 uppercase tracking-wider">
                          <Lock className="h-3 w-3 text-[#14B4E8]" />
                          {mode === 'signup' ? 'Create Password' : 'Password'}
                        </label>
                        <div className="relative">
                          <input
                            required
                            type={showPassword ? 'text' : 'password'}
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            placeholder={
                              mode === 'signup' ? 'At least 4 characters' : 'Enter your password'
                            }
                            autoComplete={mode === 'signup' ? 'new-password' : 'current-password'}
                            disabled={fieldsDisabled}
                            className="w-full rounded-xl border border-[#B7D6EB] bg-white px-3.5 py-2.5 pr-11 text-[13px] text-[#0B2545] placeholder:text-[#4A6A86] placeholder:font-medium outline-none shadow-[inset_0_1px_2px_rgba(11,37,69,0.04)] focus:border-[#14B4E8] focus:ring-2 focus:ring-[#14B4E8]/20 transition disabled:opacity-60 disabled:cursor-not-allowed disabled:bg-[#F0F5F9]"
                          />
                          <button
                            type="button"
                            aria-label={showPassword ? 'Hide password' : 'Show password'}
                            onClick={() => setShowPassword((v) => !v)}
                            className="absolute inset-y-0 right-0 flex w-11 items-center justify-center text-[#5A7A96] hover:text-[#0B2545] transition"
                          >
                            {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                          </button>
                        </div>
                        {password && passwordHint && (
                          <p className={`mt-1.5 text-[11px] font-medium ${passwordHint.tone}`}>
                            {passwordHint.label}
                          </p>
                        )}
                        {mode === 'signup' && !password && (
                          <p className="mt-1.5 text-[11px] text-[#5A7A96]">
                            Use at least 4 characters. Mix letters and numbers for stronger security.
                          </p>
                        )}
                      </div>
                    )}

                    {mode === 'login' && (
                      <div className="flex items-center justify-between pt-0.5">
                        <label className="flex cursor-pointer items-center gap-2">
                          <input
                            type="checkbox"
                            checked={rememberMe}
                            onChange={(e) => setRememberMe(e.target.checked)}
                            className="h-3.5 w-3.5 rounded border-[#A9D9F0] bg-white accent-[#14B4E8]"
                          />
                          <span className="text-xs text-[#4F6B88]">Remember me</span>
                        </label>
                        <button
                          type="button"
                          onClick={() => switchMode('forgot')}
                          className="text-xs font-medium text-[#0C94D0] hover:text-[#0B6FB8] hover:underline transition"
                        >
                          Forgot password?
                        </button>
                      </div>
                    )}

                    {mode !== 'login' && (
                      <label className="flex cursor-pointer items-center gap-2">
                        <input
                          type="checkbox"
                          checked={agreedToTerms}
                          onChange={(e) => setAgreedToTerms(e.target.checked)}
                          className="h-3.5 w-3.5 rounded border-[#A9D9F0] bg-white accent-[#14B4E8]"
                        />
                        <span className="text-xs text-[#4F6B88]">I agree to the access terms.</span>
                      </label>
                    )}

                    {/* Optional MFA — reveals on demand after credentials */}
                    {mode === 'login' && (
                      <div className="space-y-2">
                        {!showMfaField ? (
                          <button
                            type="button"
                            onClick={() => setShowMfaField(true)}
                            className="text-[11px] font-medium text-[#0C94D0] hover:text-[#0B6FB8] hover:underline transition"
                          >
                            Have an authenticator code?
                          </button>
                        ) : (
                          <div>
                            <label className="flex items-center gap-1.5 text-[10px] font-semibold text-[#3D5A73] mb-1.5 uppercase tracking-wider">
                              <KeyRound className="h-3 w-3 text-[#14B4E8]" />
                              Authentication code
                            </label>
                            <input
                              type="text"
                              inputMode="numeric"
                              autoComplete="one-time-code"
                              value={mfaCode}
                              onChange={(e) => setMfaCode(e.target.value.replace(/\s/g, ''))}
                              placeholder="6-digit code"
                              maxLength={8}
                              disabled={fieldsDisabled}
                              className="w-full rounded-xl border border-[#B7D6EB] bg-white px-3.5 py-2.5 text-[13px] tracking-[0.2em] text-[#0B2545] placeholder:text-[#4A6A86] placeholder:font-medium placeholder:tracking-normal outline-none shadow-[inset_0_1px_2px_rgba(11,37,69,0.04)] focus:border-[#14B4E8] focus:ring-2 focus:ring-[#14B4E8]/20 transition disabled:opacity-60"
                            />
                            <p className="mt-1.5 text-[11px] text-[#5A7A96]">
                              Enter the code from your authenticator app if MFA is enabled on your account.
                            </p>
                          </div>
                        )}
                      </div>
                    )}

                    {/* Cloudflare Turnstile — clean widget when real site key is configured */}
                    {isTurnstileEnabled() && !offlineLocalOnly && (
                      <div
                        ref={turnstileRef}
                        className="w-full flex justify-center items-center py-1"
                      />
                    )}

                    <button
                      type="submit"
                      disabled={
                        isLoading ||
                        (mode === 'login' &&
                          isTurnstileEnabled() &&
                          !offlineLocalOnly &&
                          !turnstileReady)
                      }
                      style={{
                        background: 'linear-gradient(135deg, #0B6FB8 0%, #0C94D0 45%, #3AC6FF 100%)',
                        boxShadow:
                          '0 1px 0 rgba(255,255,255,0.25) inset, 0 12px 28px rgba(12, 148, 208, 0.35)',
                      }}
                      className="group relative w-full overflow-hidden rounded-xl text-white font-semibold text-[13px] py-3 ring-1 ring-[#14B4E8]/50 transition disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 hover:brightness-105 active:scale-[0.99]"
                    >
                      <span className="pointer-events-none absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/25 to-transparent transition-transform duration-700 group-hover:translate-x-full" />
                      {isLoading ? (
                        <Loader2 className="h-4 w-4 animate-spin text-white" />
                      ) : (
                        <Lock className="h-3.5 w-3.5 text-white/95" />
                      )}
                      <span className="relative">
                        {isLoading
                          ? 'Authenticating…'
                          : offlineLocalOnly && mode === 'login'
                            ? 'Sign in offline'
                            : submitLabel}
                      </span>
                    </button>
                  </form>

                  {/* Mode switcher */}
                  <div className="mt-3 pt-3 border-t border-[#E1EFF8]">
                    {mode === 'login' ? (
                      <p className="text-center text-xs text-[#4F6B88]">
                        Don&apos;t have an account?{' '}
                        <button
                          type="button"
                          onClick={() => switchMode('signup')}
                          className="font-semibold text-[#0C94D0] hover:text-[#0B6FB8] hover:underline transition"
                        >
                          Request access
                        </button>
                      </p>
                    ) : (
                      <p className="text-center text-xs text-[#4F6B88]">
                        <button
                          type="button"
                          onClick={() => switchMode('login')}
                          className="inline-flex items-center gap-1 font-semibold text-[#0C94D0] hover:text-[#0B6FB8] hover:underline transition"
                        >
                          <ChevronRight className="h-3 w-3 rotate-180" />
                          Back to sign in
                        </button>
                      </p>
                    )}
                  </div>

                  {/* Security info footer */}
                  <div className="mt-5 pt-3.5 border-t border-[#C5DCEB] flex items-center justify-center gap-2 text-[11px] text-[#1E3A54] font-mono uppercase tracking-wider">
                    <ShieldCheck className="h-3.5 w-3.5 text-[#0B6FB8]" />
                    <span className="font-semibold tracking-wide">Encrypted 256-Bit SSL · RBAC Enforced</span>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
};
