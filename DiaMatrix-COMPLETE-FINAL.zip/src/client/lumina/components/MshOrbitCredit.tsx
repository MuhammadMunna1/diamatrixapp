import React, { useEffect, useRef } from 'react';

/**
 * MshOrbitCredit
 * -----------------------------------------------------------------------
 * A rotating Endurance-style spacecraft ring, name curved around it in
 * bold glowing letters. The whole ring:
 *   1. Spins on its own axis continuously (like Endurance's rotation for
 *      artificial gravity) — pure CSS, always running.
 *   2. Orbits the screen along an ellipse (JS-driven, so we can smoothly
 *      hand off into step 3).
 *   3. Once per lap, curves toward the black hole that is already part of
 *      the background video, shrinking and fading as if falling into it,
 *      disappears briefly, then re-emerges and grows back to full size.
 * There's no second/fake black hole drawn here — it dives into the real
 * Gargantua-style black hole already in the login background video, so
 * BLACK_HOLE below is just a target point, not a rendered element. Tune
 * its xPct/yPct to match where the black hole actually sits in your
 * background video at typical screen sizes.
 * The whole thing loops forever. Reduced-motion users get a static,
 * centered, non-animated credit instead.
 *
 * Drop this file into src/client/components/, then in LoginPortal.tsx render
 * <MshOrbitCredit /> anywhere inside the video stage.
 * -----------------------------------------------------------------------
 */

// ── Orbit + dive-target geometry, tuned for a typical widescreen login
//    stage. All values are PERCENTAGES of the stage's width/height, so it
//    scales with the viewport. Adjust freely. ──
const ORBIT_CENTER = { xPct: 50, yPct: 46 };
const ORBIT_RADIUS = { xPct: 34, yPct: 27 };
/** The real black hole's approximate center in the background video — the
 * ring dives toward THIS point once per lap (nothing is drawn here). */
const BLACK_HOLE = { xPct: 47, yPct: 38 };

const CYCLE_MS = 28000; // full loop: orbit + dive + re-emerge (slower, easier to read)
const FALL_START = 0.62; // fraction of cycle where the dive begins
const FALL_END = 0.8; // fully "inside" the black hole by here
const HIDDEN_END = 0.86; // stays hidden until here
const EMERGE_END = 1.0; // back to full size/orbit by here (loops to 0)

function easeInCubic(t: number) {
  return t * t * t;
}
function easeOutCubic(t: number) {
  return 1 - Math.pow(1 - t, 3);
}

export const MshOrbitCredit: React.FC = () => {
  const stageRef = useRef<HTMLDivElement>(null);
  const ringRef = useRef<HTMLDivElement>(null);
  const rafRef = useRef<number | undefined>(undefined);
  const startRef = useRef<number | undefined>(undefined);
  const sizeRef = useRef({ w: 0, h: 0 });

  useEffect(() => {
    const prefersReduced =
      typeof window !== 'undefined' &&
      window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;
    if (prefersReduced) return;

    const stage = stageRef.current;
    const ring = ringRef.current;
    if (!stage || !ring) return;

    const measure = () => {
      const parent = stage.parentElement;
      sizeRef.current = {
        w: parent?.clientWidth || window.innerWidth,
        h: parent?.clientHeight || window.innerHeight,
      };
    };
    measure();
    window.addEventListener('resize', measure);

    const orbitPoint = (angle: number) => {
      const { w, h } = sizeRef.current;
      const cx = (ORBIT_CENTER.xPct / 100) * w;
      const cy = (ORBIT_CENTER.yPct / 100) * h;
      const rx = (ORBIT_RADIUS.xPct / 100) * w;
      const ry = (ORBIT_RADIUS.yPct / 100) * h;
      return { x: cx + rx * Math.cos(angle), y: cy + ry * Math.sin(angle) };
    };
    const blackHolePoint = () => {
      const { w, h } = sizeRef.current;
      return { x: (BLACK_HOLE.xPct / 100) * w, y: (BLACK_HOLE.yPct / 100) * h };
    };
    const lerp = (a: number, b: number, t: number) => a + (b - a) * t;

    const tick = (now: number) => {
      if (startRef.current === undefined) startRef.current = now;
      const elapsed = (now - startRef.current) % CYCLE_MS;
      const t = elapsed / CYCLE_MS;

      let x: number, y: number, scale: number, opacity: number;

      if (t < FALL_START) {
        // Normal orbit lap — one full revolution across this phase.
        const angle = (t / FALL_START) * Math.PI * 2;
        const p = orbitPoint(angle);
        x = p.x;
        y = p.y;
        scale = 1;
        opacity = 1;
      } else if (t < FALL_END) {
        // Falling into the black hole: curve from the lap's start point
        // toward the black hole center, shrinking and fading (ease-in,
        // like gravity accelerating it).
        const local = easeInCubic((t - FALL_START) / (FALL_END - FALL_START));
        const from = orbitPoint(0);
        const to = blackHolePoint();
        x = lerp(from.x, to.x, local);
        y = lerp(from.y, to.y, local);
        scale = lerp(1, 0.04, local);
        opacity = lerp(1, 0, Math.min(1, local * 1.3));
      } else if (t < HIDDEN_END) {
        // Swallowed — fully hidden at the black hole's center.
        const p = blackHolePoint();
        x = p.x;
        y = p.y;
        scale = 0.04;
        opacity = 0;
      } else {
        // Re-emerging: curve back out from the black hole to the orbit's
        // start point, growing and fading back in (ease-out).
        const local = easeOutCubic((t - HIDDEN_END) / (EMERGE_END - HIDDEN_END));
        const from = blackHolePoint();
        const to = orbitPoint(0);
        x = lerp(from.x, to.x, local);
        y = lerp(from.y, to.y, local);
        scale = lerp(0.04, 1, local);
        opacity = lerp(0, 1, Math.max(0, (local - 0.15) / 0.85));
      }

      ring.style.transform = `translate3d(${x}px, ${y}px, 0) translate(-50%, -50%) scale(${scale})`;
      ring.style.opacity = String(opacity);

      rafRef.current = requestAnimationFrame(tick);
    };

    rafRef.current = requestAnimationFrame(tick);
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
      window.removeEventListener('resize', measure);
    };
  }, []);

  return (
    <div ref={stageRef} className="msh-orbit-layer" aria-hidden>
      {/* Endurance-style rotating ring credit — dives into the REAL black
          hole already rendered in the background video (see BLACK_HOLE
          above), so nothing extra is drawn here. */}
      <div ref={ringRef} className="msh-ring-wrap">
        <div className="msh-ring-spin">
          <svg viewBox="0 0 200 200" className="msh-ring-svg">
            <defs>
              <path id="mshRingTextPath" d="M100,10 A90,90 0 1,1 99.9,10" fill="none" />
              <filter id="mshRingGlow" x="-60%" y="-60%" width="220%" height="220%">
                <feGaussianBlur stdDeviation="2.4" result="blur" />
                <feMerge>
                  <feMergeNode in="blur" />
                  <feMergeNode in="SourceGraphic" />
                </feMerge>
              </filter>
            </defs>

            {/* Cross-arm hub — like the reference station's central docking
                module with two straight arms reaching out to the ring. */}
            <g stroke="#e7e9ee" strokeWidth="2.2" opacity="0.85">
              <line x1="76" y1="100" x2="124" y2="100" />
              <line x1="100" y1="88" x2="100" y2="112" />
            </g>
            <rect x="93" y="90" width="14" height="20" rx="3" fill="#c7cbd3" stroke="#e7e9ee" strokeWidth="1.2" />
            <circle cx="100" cy="100" r="5.5" fill="#e7e9ee" opacity="0.9" />

            {/* Connecting truss ring — thin line linking every module together */}
            <circle cx="100" cy="100" r="68" fill="none" stroke="#c7cbd3" strokeWidth="1" opacity="0.4" />

            {/* Docked hab modules — chunky boxy capsules like the reference
                station photo, each with a dark window/panel stripe, joined
                to the truss ring by a short strut. This is what actually
                reads as "spacecraft" rather than a plain circle. */}
            <g>
              {Array.from({ length: 10 }).map((_, i) => {
                const a = (i / 10) * Math.PI * 2;
                const r = 68;
                const cx = 100 + r * Math.cos(a);
                const cy = 100 + r * Math.sin(a);
                const deg = (a * 180) / Math.PI + 90;
                return (
                  <g key={i} transform={`rotate(${deg} ${cx} ${cy})`}>
                    {/* short strut connecting the module to the truss ring */}
                    <line x1={cx} y1={cy - 6} x2={cx} y2={cy - 9.5} stroke="#c7cbd3" strokeWidth="1.4" />
                    {/* module body */}
                    <rect
                      x={cx - 6.5}
                      y={cy - 6}
                      width="13"
                      height="12"
                      rx="2.2"
                      fill="#e9ebef"
                      stroke="#9aa0ab"
                      strokeWidth="1"
                    />
                    {/* dark panel/window stripes, like the reference photo */}
                    <rect x={cx - 4.6} y={cy - 4.2} width="3.4" height="8.4" rx="0.8" fill="#1b1e24" />
                    <rect x={cx + 1.2} y={cy - 4.2} width="3.4" height="8.4" rx="0.8" fill="#1b1e24" />
                  </g>
                );
              })}
            </g>

            {/* Text ring — outside the modules so nothing overlaps the
                letters; bold WHITE glowing type, easy to read against any
                background. */}
            <text
              fontFamily="'Syne', sans-serif"
              fontWeight="800"
              fontSize="15.5"
              letterSpacing="4.5"
              fill="#ffffff"
              stroke="#0a0a0a"
              strokeWidth="0.55"
              paintOrder="stroke"
              filter="url(#mshRingGlow)"
            >
              <textPath href="#mshRingTextPath" startOffset="2%">
                DEVELOPED BY MSH  ✦  DEVELOPED BY MSH  ✦
              </textPath>
            </text>
          </svg>
        </div>
      </div>
    </div>
  );
};

export default MshOrbitCredit;
