import React, { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import {
  Search,
  HelpCircle,
  MessageSquare,
  User,
  Star,
  Clock,
  Home,
  ChevronDown,
  Download,
  Settings,
  LogOut,
  Sparkles,
  Layers,
  FolderLock,
  PackagePlus,
  ArrowRightLeft,
  FileSpreadsheet,
  Building2,
  Gem,
  Plus
} from 'lucide-react';
import { AuthUser, SalesTimeframe, AllocationMode } from '../types';
import { DiamondWorldLogo } from './DiamondWorldLogo';
import { BRAND } from '../brand';
import { AppTheme } from '../utils/settingsEngine';
import { ThemeSwitcher } from './ThemeSwitcher';

interface NetSuiteTopHeaderProps {
  activeView: string;
  activeReport: string;
  onNavigateView: (view: any, report?: any) => void;
  selectedTimeframe: SalesTimeframe;
  onTimeframeChange: (tf: SalesTimeframe) => void;
  allocationMode: AllocationMode;
  onAllocationModeChange: (mode: AllocationMode) => void;
  period: string;
  onPeriodChange: (val: string) => void;
  onOpenDailyUpload: () => void;
  onExportExcel: () => void;
  onExportPdf?: () => void;
  onOpenUploadHistory?: () => void;
  onToggleAICopilot: () => void;
  isAiDrawerOpen: boolean;
  onOpenOperations: () => void;
  onOpenUserManagement: () => void;
  onOpenSettings: () => void;
  currentUser: AuthUser | null;
  onLogout: () => void;
  onQuickSearchBranch?: (branch: string) => void;
  theme?: AppTheme;
  onThemeChange?: (theme: AppTheme) => void;
}

export const NetSuiteTopHeader: React.FC<NetSuiteTopHeaderProps> = ({
  activeView,
  activeReport,
  onNavigateView,
  selectedTimeframe,
  onTimeframeChange,
  allocationMode,
  onAllocationModeChange,
  period,
  onPeriodChange,
  onOpenDailyUpload,
  onExportExcel,
  onExportPdf,
  onOpenUploadHistory,
  onToggleAICopilot,
  isAiDrawerOpen,
  onOpenOperations,
  onOpenUserManagement,
  onOpenSettings,
  currentUser,
  onLogout,
  onQuickSearchBranch,
  theme = 'cosmic',
  onThemeChange,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [isReportsDropdownOpen, setIsReportsDropdownOpen] = useState(false);
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const [isFavoritesOpen, setIsFavoritesOpen] = useState(false);
  const [isRecentOpen, setIsRecentOpen] = useState(false);
  const userMenuButtonRef = useRef<HTMLButtonElement | null>(null);
  const [userMenuPosition, setUserMenuPosition] = useState({ top: 0, right: 16 });

  useEffect(() => {
    if (!isUserMenuOpen) return;

    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key !== 'Escape') return;
      event.preventDefault();
      event.stopPropagation();
      setIsUserMenuOpen(false);
    };

    window.addEventListener('keydown', closeOnEscape);
    return () => window.removeEventListener('keydown', closeOnEscape);
  }, [isUserMenuOpen]);

  useEffect(() => {
    if (!isUserMenuOpen) return;
    const updateUserMenuPosition = () => {
      const rect = userMenuButtonRef.current?.getBoundingClientRect();
      if (!rect) return;
      setUserMenuPosition({
        top: Math.round(rect.bottom + 8),
        right: Math.max(12, Math.round(window.innerWidth - rect.right)),
      });
    };
    updateUserMenuPosition();
    window.addEventListener('resize', updateUserMenuPosition);
    window.addEventListener('scroll', updateUserMenuPosition, true);
    return () => {
      window.removeEventListener('resize', updateUserMenuPosition);
      window.removeEventListener('scroll', updateUserMenuPosition, true);
    };
  }, [isUserMenuOpen]);

  const getBreadcrumbTitle = () => {
    if (activeView === 'dashboard' || activeView === 'menu') return 'Operations Cockpit';
    if (activeView === 'option_allocation') return 'Stock Distribution > Item-Wise Allocation & Redistribution';
    if (activeView === 'movement_aging') return 'Stock Intelligence > Movement, Velocity & Aging Analysis';
    if (activeView === 'consignment_shipment') return 'Reports > Refill Demand';
    if (activeView === 'reports') {
      const names: Record<string, string> = {
        refill_demand: 'Reports > Showroom Refill Demand Requisitions',
        excel_sheet: 'Reports > Master Inventory & Sales Matrix (Excel)',
        movement_summary: 'Reports > Movement Dispatch & Rebalancing Matrix',
        branches: 'Reports > Showroom Outlet Balances & Ratios',
        weights: 'Reports > Design-wise Stock Analysis',
        demand_booster: 'Reports > Demand Opportunity & Growth Booster',
        execution: 'Reports > Execution Report (Contribution · 3M Baseline · Hybrid)',
        stock_turn_rate: 'Reports > Stock Turn Rate Dashboard (Sales ÷ Stock)'
      };
      return names[activeReport] || 'Reports';
    }
    return 'Operations Cockpit';
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim() && onQuickSearchBranch) {
      onQuickSearchBranch(searchQuery.trim().toUpperCase());
      setSearchQuery('');
    }
  };

  return (
    <header className="w-full sticky top-0 z-[1000] bg-white/85 backdrop-blur-xl border-b border-[#D3E8F6]">
      
      {/* Titlebar — fluid logo/text via clamp, compact bar */}
      <div className="sw-titlebar px-2 sm:px-3">
        <button
          type="button"
          onClick={() => onNavigateView('dashboard')}
          className="flex items-center gap-2 sm:gap-3 text-left text-[#0B2545] min-w-0"
          title="Home"
        >
          <img
            src="/diamatrix-mark.svg"
            alt={BRAND.short}
            className="sw-brand-logo object-contain bg-transparent shrink-0 dmx-logo-3d"
            draggable={false}
          />
          <div className="flex flex-col leading-tight min-w-0 gap-0.5">
            <span className="sw-brand-title font-semibold tracking-tight truncate font-[Playfair_Display,Georgia,serif] text-[1.35rem]">
              {BRAND.short}
            </span>
            <span className="sw-brand-sub font-semibold opacity-95 hidden xs:block sm:block truncate max-w-[40vw] md:max-w-none">
              by {BRAND.company}
            </span>
          </div>
        </button>
        <span className="sw-brand-console opacity-90 hidden md:inline font-semibold shrink-0">{BRAND.console}</span>
      </div>

      {/* Toolbar — wraps on small screens, horizontal scroll if needed */}
      <div className="sw-workspace-toolbar bg-[#E6F4FC] border-b border-[#D3E8F6] px-2 sm:px-3 py-1.5 flex flex-wrap items-center justify-between gap-2 text-[11px]">
        
        {/* Module links live in left AppSideNav — toolbar keeps search + actions */}
        <div className="flex items-center gap-1.5 shrink-0 text-[10px] font-bold uppercase tracking-wider text-[#14B4E8]/80 px-1">
          <span className="hidden sm:inline">Workspace</span>
        </div>

        {/* Center: Global Search — full width on tablet+ */}
        <form onSubmit={handleSearchSubmit} className="flex-1 min-w-[140px] max-w-xl mx-0 sm:mx-2 order-last sm:order-none w-full sm:w-auto basis-full sm:basis-auto">
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-2.5 flex items-center pointer-events-none text-[#94a3b8]">
              <Search className="w-3.5 h-3.5" />
            </div>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search Showroom, Item / SKU / Variant, Requisitions..."
              className="w-full pl-8 pr-4 py-1.5 rounded-lg bg-white hover:bg-white focus:bg-white text-xs text-[#0B2545] placeholder-[#6B8AA8] border border-[#CFE6F5] focus:outline-none focus:border-[#14B4E8]/50 focus:ring-1 focus:ring-[#14B4E8]/20 transition-all font-medium"
            />
          </div>
        </form>

        {/* Right: Quick Action Items (Daily Upload, Feedback, User Profile) */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          
          {/* Daily Upload Quick Button — diamond-blue accent */}
          <button
            onClick={onOpenDailyUpload}
            className="hidden md:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gradient-to-r from-[#14B4E8] to-[#3AC6FF] hover:brightness-105 text-white font-bold text-xs shadow-md shadow-[#14B4E8]/30 transition-colors cursor-pointer"
            title="Upload Daily Sales & Closing Stock Excel Files"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Daily Intake</span>
          </button>

          {/* AI Copilot Button */}
          <button
            onClick={onToggleAICopilot}
            className={`hidden lg:flex items-center gap-1.5 px-2.5 py-1.5 rounded border transition-colors cursor-pointer text-xs font-semibold ${
              isAiDrawerOpen
                ? 'bg-[#14B4E8]/15 text-[#0B6FB8] border-[#14B4E8]/50'
                : 'bg-white text-[#0B2545] border-[#CFE6F5] hover:text-[#0B6FB8] hover:border-[#14B4E8]/60'
            }`}
            title={`Open ${BRAND.aiName}`}
          >
            <Sparkles className="w-3.5 h-3.5 text-[#14B4E8]" />
            <span>AI Copilot</span>
          </button>

          {/* User Profile Dropdown */}
          <div className="relative">
            <button
              ref={userMenuButtonRef}
              onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
              className="flex items-center gap-2 p-1 rounded hover:bg-[#E6F4FC] cursor-pointer transition-colors text-left"
              title="User Account Menu"
            >
              <div className="w-7 h-7 rounded-full bg-[#14B4E8] text-white flex items-center justify-center font-bold text-xs shadow-[0_0_12px_rgba(14, 165, 233,0.35)]">
                {currentUser?.name ? currentUser.name.slice(0, 2).toUpperCase() : 'SH'}
              </div>
              <div className="hidden xl:flex flex-col text-left">
                <span className="text-xs font-bold text-[#0B2545] leading-none">
                  {currentUser?.name || 'MD Shahadat Hossen'}
                </span>
                <span className="text-[9px] text-[#64748b] leading-tight mt-0.5">
                  DWL • {currentUser?.isOwner ? 'SYSTEM OWNER' : 'AUTHORIZED USER'}
                </span>
              </div>
              <ChevronDown className="w-3 h-3 text-[#64748b]" />
            </button>

            {/* Dropdown Menu */}
            {isUserMenuOpen && typeof document !== 'undefined' && createPortal(
              <div
                className="fixed w-60 bg-white rounded-xl shadow-2xl shadow-[#0B2545]/15 border border-[#D3E8F6] py-1 text-xs sw-top-layer-dropdown"
                style={{ top: userMenuPosition.top, right: userMenuPosition.right }}
              >
                <div className="px-3 py-2 border-b border-[#E1EFF8] bg-[#F6FAFD]">
                  <p className="font-bold text-[#0B2545]">{currentUser?.name || 'MD Shahadat Hossen'}</p>
                  <p className="text-[10px] text-[#94a3b8]">{currentUser?.username || 'shahadat'}</p>
                  <span className="inline-block mt-1 px-1.5 py-0.5 bg-[#14B4E8]/15 text-[#14B4E8] text-[9px] font-bold rounded">
                    Role: {currentUser?.role || 'Operations Administrator'}
                  </span>
                </div>
                {currentUser?.isOwner && (
                  <>
                    <button
                      onClick={() => {
                        setIsUserMenuOpen(false);
                        onOpenUserManagement();
                      }}
                      className="w-full px-3 py-2 text-left hover:bg-[#14B4E8]/10 flex items-center gap-2 text-[#0B2545] cursor-pointer"
                    >
                      <User className="w-3.5 h-3.5 text-[#64748b]" />
                      <span>Manage Users &amp; Permissions</span>
                    </button>
                    <button
                      onClick={() => {
                        setIsUserMenuOpen(false);
                        onOpenSettings();
                      }}
                      className="w-full px-3 py-2 text-left hover:bg-[#14B4E8]/10 flex items-center gap-2 text-[#0B2545] cursor-pointer"
                    >
                      <Settings className="w-3.5 h-3.5 text-[#64748b]" />
                      <span>ERP Display &amp; Number Preferences</span>
                    </button>
                  </>
                )}
                <div className="border-t border-[#e2e8f0] my-1" />
                <button
                  onClick={() => {
                    setIsUserMenuOpen(false);
                    onLogout();
                  }}
                  className="w-full px-3 py-2 text-left hover:bg-red-50 text-red-700 flex items-center gap-2 font-bold cursor-pointer"
                >
                  <LogOut className="w-3.5 h-3.5 text-red-600" />
                  <span>Sign Out</span>
                </button>
              </div>,
              document.body
            )}
          </div>
        </div>
      </div>

      {/* 3. SUB-HEADER BAR: Breadcrumb, Timeframe Switcher, and Quick Export */}
      <div className="bg-[#F6FAFD] border-b border-[#D3E8F6] px-3 sm:px-6 py-2 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
        
        {/* Left: Breadcrumb */}
        <div className="flex items-center gap-2">
          <h2 className="text-sm sm:text-base font-extrabold text-[#0B2545] tracking-tight">
            {getBreadcrumbTitle()}
          </h2>
        </div>

        {/* Right: Timeframe Switch & Export */}
        <div className="flex items-center gap-2 sm:gap-3 flex-wrap">
          
          {/* 3 Distribution Analysis Mode Buttons — switches full-app report */}
          <div className="flex items-center gap-1 text-[#64748b] text-[11px]">
            <span className="hidden sm:inline font-semibold">Distribution:</span>
          </div>
          <div className="flex items-center rounded-lg bg-white border border-[#CFE6F5] p-0.5 text-[11px] font-bold">
            {([
              { id: 'contribution' as AllocationMode, label: '① Contribution', tip: 'Full pool (DWL+all branches) by sales share — high sales gets more' },
              { id: 'baseline' as AllocationMode, label: '② 3M Baseline', tip: 'Avg monthly × 3 + scale factor' },
              { id: 'hybrid' as AllocationMode, label: '③ Hybrid', tip: 'max(contribution, baseline) then compress' },
              { id: 'liquidity' as AllocationMode, label: '④ Liquidity', tip: 'Capital Liquidity: sales ÷ aging; scale down if >90 days' },
              { id: 'demand_backup' as AllocationMode, label: '⑤ Demand-Backup', tip: '3M base + 20% high-performer + stock-out safety' },
              { id: 'coverage' as AllocationMode, label: '⑥ Coverage', tip: 'Every outlet ≥1 pc so sales can start; rest by sales share' },
            ]).map((m) => (
              <button
                key={m.id}
                type="button"
                title={m.tip}
                onClick={() => {
                  onAllocationModeChange(m.id);
                  // Jump to allocation matrix so user sees the live redistribution
                  if (activeView !== 'option_allocation') {
                    onNavigateView('option_allocation');
                  }
                }}
                className={`px-2.5 py-1 rounded-md cursor-pointer transition-all whitespace-nowrap ${
                  allocationMode === m.id
                    ? 'bg-[#0D9488] shadow-sm'
                    : 'hover:bg-[#F1F5F9]'
                }`}
                style={
                  allocationMode === m.id
                    ? { backgroundColor: '#0D9488', color: '#FFFFFF' }
                    : { color: '#1F2937' }
                }
              >
                {m.label}
              </button>
            ))}
          </div>

          <span className="text-[#cbd5e1] hidden sm:inline">•</span>

          <div className="flex items-center gap-1 text-[#64748b] text-[11px]">
            <span style={{ color: '#4B5563' }}>Sales:</span>
          </div>

          {/* Timeframe Switcher */}
          <div className="flex items-center rounded-lg bg-white border border-[#CFE6F5] p-0.5 text-[11px] font-bold">
            {(['1Y', '9M', '6M', '3M', '1M'] as SalesTimeframe[]).map((tf) => (
              <button
                key={tf}
                onClick={() => onTimeframeChange(tf)}
                className={`px-2.5 py-0.5 rounded cursor-pointer transition-all ${
                  selectedTimeframe === tf ? 'shadow-sm' : 'hover:bg-[#F1F5F9]'
                }`}
                style={
                  selectedTimeframe === tf
                    ? { backgroundColor: '#0D9488', color: '#FFFFFF' }
                    : { color: '#1F2937', backgroundColor: 'transparent' }
                }
              >
                {tf}
              </button>
            ))}
          </div>

          <span className="text-[#cbd5e1] hidden sm:inline">•</span>

          {/* Export Excel Button */}
          <button
            onClick={onExportExcel}
            className="inline-flex items-center gap-1 px-3 py-1 rounded-md text-[11px] font-bold transition-all cursor-pointer shadow-sm hover:brightness-110"
            style={{ backgroundColor: '#0B2545', color: '#FFFFFF' }}
            title="Export Excel Matrix"
          >
            <Download className="w-3 h-3" style={{ color: '#FFFFFF' }} />
            <span style={{ color: '#FFFFFF' }}>Export Excel</span>
          </button>

        </div>

      </div>

    </header>
  );
};
