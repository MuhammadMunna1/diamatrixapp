import React from 'react';
import { X, CheckCircle2, Layers, Shield, Database, Sparkles } from 'lucide-react';
import { BRAND } from '../brand';

interface AboutLuminaModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const MODULES = [
  'Login & role-based access (Owner / Admin / Analyst)',
  'Dual file upload — Stock + Sold (cents or Oracle range K/L)',
  'Master Inventory & Sales Matrix (Excel crosstab)',
  'Contribution / 3M Baseline / Hybrid allocation',
  'Intra-branch transfer & procurement recommendations',
  'Refill demand, movement & aging analysis',
  'Design / range-wise stock analysis',
  'All Reports hub with SAP-style filters',
  'DiaMatrix AI Crossmatch briefing',
  'Theme engine (Light / Obsidian / Midnight / Emerald)',
  'Settings, user management, export Excel',
];

export const AboutLuminaModal: React.FC<AboutLuminaModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-[80] flex items-center justify-center bg-black/50 p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="about-lumina-title"
      onClick={onClose}
    >
      <div
        className="w-full max-w-lg rounded-lg border shadow-2xl overflow-hidden"
        style={{
          background: 'var(--shell-panel)',
          borderColor: 'var(--shell-panel-border)',
          color: 'var(--shell-fg)',
        }}
        onClick={(e) => e.stopPropagation()}
      >
        <div
          className="px-4 py-3 flex items-center justify-between"
          style={{ background: 'var(--shell-titlebar)', color: 'var(--shell-titlebar-fg)' }}
        >
          <div className="flex items-center gap-3">
            <img src="/diamatrix-mark.svg" alt="" className="w-20 h-20 object-contain bg-transparent dmx-logo-3d dmx-logo-spin" />
            <div>
              <h2 id="about-lumina-title" className="text-sm font-bold tracking-wide">
                About {BRAND.short}
              </h2>
              <p className="text-[11px] opacity-80">{BRAND.company}</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1 rounded hover:bg-white/10"
            aria-label="Close"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="px-4 py-3 space-y-3 text-[12px]">
          <p className="italic opacity-80">{BRAND.tagline}</p>
          <div className="grid grid-cols-2 gap-2 text-[11px]">
            <div className="flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5 opacity-60" />
              Version <strong>{BRAND.version}</strong>
            </div>
            <div className="flex items-center gap-1.5">
              <Shield className="w-3.5 h-3.5 opacity-60" />
              Channel <strong>{BRAND.channel}</strong>
            </div>
            <div className="flex items-center gap-1.5 col-span-2">
              <Database className="w-3.5 h-3.5 opacity-60" />
              {BRAND.company} · Enterprise stock intelligence
            </div>
          </div>

          <div>
            <div className="text-[11px] font-bold uppercase tracking-wide opacity-70 mb-1.5 flex items-center gap-1">
              <Sparkles className="w-3 h-3" /> Licensed modules
            </div>
            <ul className="space-y-1 max-h-[220px] overflow-y-auto pr-1">
              {MODULES.map((m) => (
                <li key={m} className="flex items-start gap-1.5 text-[11px]">
                  <CheckCircle2 className="w-3 h-3 mt-0.5 shrink-0 text-emerald-600" />
                  <span>{m}</span>
                </li>
              ))}
            </ul>
          </div>

          <p className="text-[10px] opacity-60 border-t pt-2" style={{ borderColor: 'var(--shell-panel-border)' }}>
            Developed by MD Shahadat Hossen (Data Analytics) · © {new Date().getFullYear()}{' '}
            {BRAND.company}
          </p>
        </div>

        <div
          className="px-4 py-2 flex justify-end border-t"
          style={{ borderColor: 'var(--shell-panel-border)' }}
        >
          <button type="button" className="sw-btn-primary sw-btn" onClick={onClose}>
            OK
          </button>
        </div>
      </div>
    </div>
  );
};
