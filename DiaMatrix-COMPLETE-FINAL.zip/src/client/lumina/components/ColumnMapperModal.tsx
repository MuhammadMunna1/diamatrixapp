import React, { useMemo, useState, useEffect } from 'react';
import { ArrowRight, Columns3, Save, X, Sparkles } from 'lucide-react';
import {
  CANONICAL_FIELDS,
  CanonicalField,
  HeaderAnalysis,
  ColumnMapDict,
  rememberColumnMaps,
} from '../utils/columnMappingEngine';

// re-export helper for normalize if needed - inline here
function norm(h: string) {
  return String(h || '').trim().toLowerCase().replace(/[\s_#./\\-]+/g, '');
}

interface ColumnMapperModalProps {
  open: boolean;
  analysis: HeaderAnalysis;
  fileLabel?: string;
  onCancel: () => void;
  /** Called after user confirms; maps already saved to localStorage */
  onConfirm: (maps: ColumnMapDict) => void;
}

export const ColumnMapperModal: React.FC<ColumnMapperModalProps> = ({
  open,
  analysis,
  fileLabel,
  onCancel,
  onConfirm,
}) => {
  const initial = useMemo(() => {
    const m: Record<string, CanonicalField> = {};
    analysis.headers.forEach((h, i) => {
      if (!h) return;
      const det = analysis.detected[i];
      if (det) m[h] = det;
      else if (analysis.suggestions[h]) m[h] = analysis.suggestions[h];
      else m[h] = 'ignore';
    });
    return m;
  }, [analysis]);

  const [draft, setDraft] = useState<Record<string, CanonicalField>>(initial);

  useEffect(() => {
    setDraft(initial);
  }, [initial]);

  if (!open) return null;

  const setField = (header: string, field: CanonicalField) => {
    setDraft((prev) => ({ ...prev, [header]: field }));
  };

  const handleSave = () => {
    const maps: ColumnMapDict = {};
    Object.entries(draft).forEach(([header, field]) => {
      maps[norm(header)] = field;
    });
    rememberColumnMaps(maps);
    onConfirm(maps);
  };

  const mappedBranch = Object.values(draft).includes('branch');
  const mappedWeight = Object.values(draft).includes('weight');
  const canSave = mappedBranch || mappedWeight; // at least one critical

  return (
    <div
      className="fixed inset-0 z-[80] flex items-center justify-center p-4 bg-[#0B2545]/40 backdrop-blur-sm"
      role="dialog"
      aria-modal="true"
      aria-labelledby="column-mapper-title"
    >
      <div className="w-full max-w-2xl max-h-[90vh] overflow-hidden flex flex-col rounded-2xl bg-white border border-[#CFE6F5] shadow-[0_24px_64px_rgba(11,37,69,0.3)]">
        {/* Header */}
        <div className="px-5 py-4 border-b border-[#CFE6F5] bg-[#F6FAFD] flex items-start justify-between gap-3">
          <div className="flex items-start gap-3">
            <div className="h-10 w-10 rounded-xl bg-[#0B2545] text-white grid place-items-center shrink-0">
              <Columns3 className="w-5 h-5" />
            </div>
            <div>
              <h2 id="column-mapper-title" className="text-base font-bold text-[#0B2545]">
                Column Mapper
              </h2>
              <p className="text-xs text-[#4F6B88] mt-0.5 leading-relaxed">
                Fuzzy + synonym ইঞ্জিন কিছু কলাম নিশ্চিত করতে পারেনি
                {fileLabel ? (
                  <>
                    {' '}
                    (<span className="font-semibold text-[#0B2545]">{fileLabel}</span>)
                  </>
                ) : null}
                . ERP হেডার → Diamatrix ফিল্ড ম্যাপ করুন। একবার সেভ করলে পরের আপলোডে মনে থাকবে।
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onCancel}
            className="h-8 w-8 rounded-xl bg-white border border-[#CFE6F5] grid place-items-center text-[#0B2545] hover:bg-[#E6F4FC]"
            aria-label="Close"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-3 bg-white">
          {analysis.missingRequired.length > 0 && (
            <div className="rounded-xl border border-amber-300 bg-amber-50 px-3 py-2 text-xs text-amber-900 flex items-start gap-2">
              <Sparkles className="w-4 h-4 shrink-0 mt-0.5" />
              <span>
                Required field missing:{' '}
                <strong>
                  {analysis.missingRequired
                    .map((id) => CANONICAL_FIELDS.find((f) => f.id === id)?.label || id)
                    .join(', ')}
                </strong>
                . নিচের ড্রপডাউন দিয়ে ম্যাপ করুন।
              </span>
            </div>
          )}

          <div className="grid grid-cols-[1fr_auto_1fr] gap-2 text-[10px] font-semibold uppercase tracking-wide text-[#4F6B88] px-1">
            <span>ERP / File column</span>
            <span className="text-center">→</span>
            <span>Diamatrix field</span>
          </div>

          {analysis.headers.filter(Boolean).map((header) => {
            const wasAuto = analysis.detected[analysis.headers.indexOf(header)];
            const isUnmapped = !wasAuto;
            return (
              <div
                key={header}
                className={`grid grid-cols-[1fr_auto_1fr] gap-2 items-center rounded-xl border px-3 py-2.5 ${
                  isUnmapped
                    ? 'border-[#14B4E8] bg-[#E6F4FC]'
                    : 'border-[#CFE6F5] bg-[#F6FAFD]'
                }`}
              >
                <div className="min-w-0">
                  <div className="text-sm font-semibold text-[#0B2545] truncate font-mono">
                    {header}
                  </div>
                  {isUnmapped ? (
                    <div className="text-[10px] text-[#14B4E8] font-medium mt-0.5">
                      Unrecognized — please map
                    </div>
                  ) : (
                    <div className="text-[10px] text-[#4F6B88] mt-0.5">
                      Auto · {analysis.methods?.[analysis.headers.indexOf(header)] || 'exact'}
                      {analysis.confidences?.[analysis.headers.indexOf(header)] != null
                        ? ` · ${Math.round((analysis.confidences[analysis.headers.indexOf(header)] || 0) * 100)}%`
                        : ''}
                    </div>
                  )}
                </div>
                <ArrowRight className="w-4 h-4 text-[#14B4E8] shrink-0" />
                <select
                  value={draft[header] || 'ignore'}
                  onChange={(e) => setField(header, e.target.value as CanonicalField)}
                  className="w-full h-9 rounded-xl border border-[#CFE6F5] bg-white px-2 text-xs font-medium text-[#0B2545] outline-none focus:border-[#14B4E8]"
                >
                  {CANONICAL_FIELDS.map((f) => (
                    <option key={f.id} value={f.id}>
                      {f.label}
                      {f.labelBn ? ` · ${f.labelBn}` : ''}
                    </option>
                  ))}
                </select>
              </div>
            );
          })}

          <p className="text-[11px] text-[#4F6B88] leading-relaxed pt-1">
            উদাহরণ: ERP-এর <code className="bg-[#E6F4FC] px-1 rounded">Outlet_Code</code> → Diamatrix{' '}
            <strong>Branch</strong>. সেভের পর একই হেডার আবার জিজ্ঞেস করা হবে না।
          </p>
        </div>

        {/* Footer */}
        <div className="px-5 py-4 border-t border-[#CFE6F5] bg-[#F6FAFD] flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={onCancel}
            className="h-10 px-4 rounded-xl border border-[#CFE6F5] bg-white text-xs font-semibold text-[#0B2545] hover:bg-white"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleSave}
            disabled={!canSave}
            className="h-10 px-5 rounded-xl bg-[#0B2545] text-white text-xs font-semibold flex items-center gap-2 hover:bg-[#0A1F3D] disabled:opacity-40 shadow-[0_4px_12px_rgba(11,37,69,0.25)]"
          >
            <Save className="w-4 h-4" />
            Save mapping & continue
          </button>
        </div>
      </div>
    </div>
  );
};

export default ColumnMapperModal;
