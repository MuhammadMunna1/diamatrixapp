import React from 'react';
import { BRAND } from '../brand';

interface DiamondWorldLogoProps {
  className?: string;
  size?: number | string;
  color?: string;
  tone?: 'white' | 'black' | 'original';
  variant?: 'icon' | 'full';
}

/** DiaMatrix brand mark — D diamond icon / full wordmark */
export const DiamondWorldLogo: React.FC<DiamondWorldLogoProps> = ({
  className = 'w-16 h-16',
  size,
  variant = 'icon',
}) => {
  const style = size ? { width: size, height: size } : undefined;
  const src = variant === 'full' ? '/diamatrix-wordmark.svg' : '/diamatrix-mark.svg';

  return (
    <img
      src={src}
      alt={BRAND.short}
      className={`inline-block select-none shrink-0 object-contain bg-transparent dmx-logo-3d dmx-logo-spin ${className}`}
      style={style}
      draggable={false}
    />
  );
};
