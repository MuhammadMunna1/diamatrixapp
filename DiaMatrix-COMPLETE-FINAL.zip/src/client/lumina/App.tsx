import React, { useState, useMemo, useEffect } from 'react';
import { DEFAULT_RAW_RECORDS, DEFAULT_PERIOD } from './data/defaultDataset';
import { calculateRedistributionReport } from './utils/redistributionEngine';
import { RawInventoryRecord, SalesTimeframe, AllocationMode, AuthUser, SpecialMonth } from './types';
import {
  ReportFilterBar,
  ReportFilters,
  EMPTY_FILTERS,
  applyReportFilters
} from './components/ReportFilterBar';
import { learnFromRecords, applyIdentityToRecords } from './utils/dataIdentityEngine';
import { restoreSession, setCurrentSession, logoutCurrentSession } from './utils/authEngine';
import { AppSettings, getStoredSettings, applyThemeToDocument } from './utils/settingsEngine';
import { ErpStatusBar } from './components/ErpStatusBar';
import { AboutLuminaModal } from './components/AboutLuminaModal';
import { DemoDataBanner } from './components/DemoDataBanner';
import { LuminaSplash } from './components/LuminaSplash';
import { LoginPortal } from './components/LoginPortal';
import { UserManagementModal } from './components/UserManagementModal';
import { SettingsModal } from './components/SettingsModal';
import { OptionWiseAllocationView } from './components/OptionWiseAllocationView';
import { MovementAndAgingReportView } from './components/MovementAndAgingReportView';
import { RefillDemandReport } from './components/RefillDemandReport';
import { ExcelReportSheetView } from './components/ExcelReportSheetView';
import { OutletDesignMatrixReport } from './components/OutletDesignMatrixReport';
import { MovementSummaryView } from './components/MovementSummaryView';
import { BranchSummaryTable } from './components/BranchSummaryTable';
import { DesignWiseStockAnalysis } from './components/DesignWiseStockAnalysis';
import { DemandOpportunityAnalysis } from './components/DemandOpportunityAnalysis';
import { AICrossmatchReportView } from './components/AICrossmatchReportView';
import { StockTurnRateDashboard } from './components/StockTurnRateDashboard';
import { AllReportsHub, ReportKey } from './components/AllReportsHub';
import { OperationsDataDrawer } from './components/OperationsDataDrawer';
import { AIAssistantDrawer } from './components/AIAssistantDrawer';
import { BranchDetailModal } from './components/BranchDetailModal';
import { ProductLocationModal } from './components/ProductLocationModal';
import { DailyDualFileUploadModal } from './components/DailyDualFileUploadModal';
import { UploadHistoryPanel } from './components/UploadHistoryPanel';
import { NetSuiteTopHeader } from './components/NetSuiteTopHeader';
import { AppSideNav } from './components/AppSideNav';
import { NetSuiteHomeDashboard } from './components/NetSuiteHomeDashboard';
import { BRAND } from './brand';
import { saveDailySnapshot } from './utils/dailyStorageEngine';
import {
  bootstrapInventoryFromIdb,
  saveWorkingDataset,
  mergeRecordsAppend,
  ImportMode,
} from './utils/indexedDbEngine';
import {
  exportStyledExcelReport,
  exportReportPdf,
} from './utils/styledReportExport';
import {
  LayoutDashboard,
  FileSpreadsheet,
  ArrowRightLeft,
  Flame,
  Building2,
  Gem,
  ShieldCheck,
  PackagePlus,
  Files,
  Clock,
  Activity,
  SlidersHorizontal,
  ChevronRight,
  TrendingUp,
  FolderLock,
  Home,
  LayoutGrid,
  Sparkles,
  History,
  FileDown,
} from 'lucide-react';
import * as XLSX from 'xlsx';

export default function App() {
  // Authentication & System Settings state
  const [currentUser, setCurrentUser] = useState<AuthUser | null>(null);
  const [authLoading, setAuthLoading] = useState(true);

  React.useEffect(() => {
    const splashStartedAt = Date.now();
    let timeoutId: number | undefined;
    let cancelled = false;
    restoreSession().then(setCurrentUser).finally(() => {
      const remainingSplashTime = Math.max(0, 4000 - (Date.now() - splashStartedAt));
      timeoutId = window.setTimeout(() => {
        if (!cancelled) setAuthLoading(false);
      }, remainingSplashTime);
    });
    return () => {
      cancelled = true;
      if (timeoutId !== undefined) window.clearTimeout(timeoutId);
    };
  }, []);
  const [isUserManagementOpen, setIsUserManagementOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [appSettings, setAppSettings] = useState<AppSettings>(() => getStoredSettings());

  // Apply theme on initial load or settings change
  React.useEffect(() => {
    applyThemeToDocument(appSettings.theme);
  }, [appSettings.theme]);

  const [rawRecords, setRawRecords] = useState<RawInventoryRecord[]>(DEFAULT_RAW_RECORDS);
  /** demo = built-in sample; upload = user file; empty = cleared */
  const [dataSource, setDataSource] = useState<'demo' | 'upload' | 'empty'>('demo');
  const [lastUploadAt, setLastUploadAt] = useState<string | null>(null);
  const [demoBannerDismissed, setDemoBannerDismissed] = useState(false);
  const [isAboutOpen, setIsAboutOpen] = useState(false);
  const [period, setPeriod] = useState<string>(DEFAULT_PERIOD);
  const [selectedTimeframe, setSelectedTimeframe] = useState<SalesTimeframe>('3M');
  /** Festival / Exhibition / Promotion months marked at upload — excluded from normal average */
  const [specialMonths, setSpecialMonths] = useState<SpecialMonth[]>([]);
  // 3 analysis modes: contribution | baseline | hybrid — switches full-app distribution
  const [allocationMode, setAllocationMode] = useState<AllocationMode>('contribution');

  // Primary Navigation View - default to 'dashboard' (Overview Scorecard) matching user's reference layout
  const [activeView, setActiveView] = useState<
    'menu' | 'dashboard' | 'option_allocation' | 'movement_aging' | 'consignment_shipment' | 'reports'
  >('dashboard');

  // Sub-report selection when in 'reports' mode:
  // 'ai_crossmatch' = AI Mode report; all others = Manual engine views
  const [activeReport, setActiveReport] = useState<
    | 'refill_demand'
    | 'excel_sheet'
    | 'outlet_design_matrix'
    | 'movement_summary'
    | 'branches'
    | 'weights'
    | 'demand_booster'
    | 'ai_crossmatch'
    | 'execution'
    | 'stock_turn_rate'
  >('refill_demand');
  /** manual = Apply & Distribution engine UI; ai = AI Crossmatch Report */
  const [analysisMode, setAnalysisMode] = useState<'manual' | 'ai'>('manual');

  // Universal item selector. No product is hard-coded as the default.
  const [selectedWeightFilter, setSelectedWeightFilter] = useState<string>('');
  const [selectedBranchFilter, setSelectedBranchFilter] = useState<string>('');

  // NetSuite-style Stock & Sold filters (Branch ID, Cts range, Category)
  // All reports regenerate against the filtered slice of uploaded data.
  const [reportFilters, setReportFilters] = useState<ReportFilters>(EMPTY_FILTERS);

  const filteredRecords = useMemo(
    () => applyReportFilters(rawRecords, reportFilters),
    [rawRecords, reportFilters]
  );

  // Inspection Modals
  const [inspectingBranch, setInspectingBranch] = useState<string | null>(null);
  const [inspectingProduct, setInspectingProduct] = useState<string | null>(null);

  // Drawers & Modals
  const [isOperationsFolderOpen, setIsOperationsFolderOpen] = useState(false);
  const [isAiDrawerOpen, setIsAiDrawerOpen] = useState(false);
  const [isDailyUploadOpen, setIsDailyUploadOpen] = useState(false);
  const [isUploadHistoryOpen, setIsUploadHistoryOpen] = useState(false);

  // Global Escape handling: close the top-most app layer without changing navigation.
  // Nested dialogs (for example Column Mapper inside Daily Intake) handle Escape
  // themselves first and stop propagation so only the nested layer closes.
  React.useEffect(() => {
    const handleGlobalEscape = (event: KeyboardEvent) => {
      if (event.key !== 'Escape') return;

      if (isSettingsOpen) {
        event.preventDefault();
        setIsSettingsOpen(false);
        return;
      }
      if (isUserManagementOpen) {
        event.preventDefault();
        setIsUserManagementOpen(false);
        return;
      }
      if (isDailyUploadOpen) {
        event.preventDefault();
        setIsDailyUploadOpen(false);
        return;
      }
      if (isAiDrawerOpen) {
        event.preventDefault();
        setIsAiDrawerOpen(false);
        return;
      }
      if (isOperationsFolderOpen) {
        event.preventDefault();
        setIsOperationsFolderOpen(false);
        return;
      }
      if (isUploadHistoryOpen) {
        event.preventDefault();
        setIsUploadHistoryOpen(false);
        return;
      }
      if (isAboutOpen) {
        event.preventDefault();
        setIsAboutOpen(false);
        return;
      }
      if (inspectingProduct !== null) {
        event.preventDefault();
        setInspectingProduct(null);
        return;
      }
      if (inspectingBranch !== null) {
        event.preventDefault();
        setInspectingBranch(null);
      }
    };

    window.addEventListener('keydown', handleGlobalEscape);
    return () => window.removeEventListener('keydown', handleGlobalEscape);
  }, [
    isSettingsOpen,
    isUserManagementOpen,
    isDailyUploadOpen,
    isAiDrawerOpen,
    isOperationsFolderOpen,
    isUploadHistoryOpen,
    isAboutOpen,
    inspectingProduct,
    inspectingBranch,
  ]);

  // Analytical Report calculation — always from filtered upload data + timeframe
  // designMode = true only when user has typed a Design Name in the filter bar
  // → design-level matrix; otherwise category-level (Nosepin 7 Stone etc.) stock & sales
  const designModeActive = !!reportFilters.subCategory.trim();
  // Exact trailing-S filter (MOHS, BCTS) → keep individual outlet in matrix
  const preserveTrailingS = /^[a-zA-Z]{2,4}s$/i.test(reportFilters.branchId.trim());
  const report = useMemo(() => {
    return calculateRedistributionReport(
      filteredRecords,
      period,
      undefined,
      undefined,
      undefined,
      selectedTimeframe,
      allocationMode,
      specialMonths,
      designModeActive,
      preserveTrailingS
    );
  }, [
    filteredRecords,
    period,
    selectedTimeframe,
    allocationMode,
    specialMonths,
    designModeActive,
    preserveTrailingS,
  ]);

  /** Parse "DD-MM-YYYY to DD-MM-YYYY" (or ISO) and return approximate month span. */
  const inferMonthsFromPeriod = (periodText: string): number | null => {
    const p = periodText.trim();
    // Match DD-MM-YYYY to DD-MM-YYYY or YYYY-MM-DD to YYYY-MM-DD
    const m1 = p.match(/(\d{1,2})[-\/.](\d{1,2})[-\/.](\d{4})\s*(?:to|-|–|—)\s*(\d{1,2})[-\/.](\d{1,2})[-\/.](\d{4})/i);
    if (m1) {
      // DD-MM-YYYY
      const from = new Date(Number(m1[3]), Number(m1[2]) - 1, Number(m1[1]));
      const to = new Date(Number(m1[6]), Number(m1[5]) - 1, Number(m1[4]));
      if (!isNaN(from.getTime()) && !isNaN(to.getTime())) {
        const days = Math.abs(to.getTime() - from.getTime()) / (1000 * 60 * 60 * 24);
        return Math.max(1, Math.round(days / 30.44));
      }
    }
    const m2 = p.match(/(\d{4})[-\/.](\d{1,2})[-\/.](\d{1,2})\s*(?:to|-|–|—)\s*(\d{4})[-\/.](\d{1,2})[-\/.](\d{1,2})/i);
    if (m2) {
      const from = new Date(Number(m2[1]), Number(m2[2]) - 1, Number(m2[3]));
      const to = new Date(Number(m2[4]), Number(m2[5]) - 1, Number(m2[6]));
      if (!isNaN(from.getTime()) && !isNaN(to.getTime())) {
        const days = Math.abs(to.getTime() - from.getTime()) / (1000 * 60 * 60 * 24);
        return Math.max(1, Math.round(days / 30.44));
      }
    }
    return null;
  };

  const monthsToTimeframe = (months: number): SalesTimeframe => {
    if (months <= 1) return '1M';
    if (months <= 4) return '3M';
    if (months <= 7) return '6M';
    if (months <= 10) return '9M'; // 8–10 months → 9M (your 01-01 to 22-09 case)
    if (months <= 18) return '1Y';
    return '2Y';
  };

  
  // Load permanent inventory from IndexedDB (no re-upload needed next day)
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const { records, meta } = await bootstrapInventoryFromIdb();
        if (cancelled || !records.length) return;
        setRawRecords(records);
        if (meta?.period) {
          setPeriod(meta.period);
        }
        console.info(
          `[DiaMatrix] Restored ${records.length} rows from IndexedDB`,
          meta?.label || ''
        );
      } catch (e) {
        console.warn('IndexedDB bootstrap skipped', e);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  const handleImportRecords = (
    newRecords: RawInventoryRecord[],
    newPeriod?: string,
    newSpecialMonths?: SpecialMonth[],
    importMode: ImportMode = 'replace'
  ) => {
    // Intelligent identity: remember branch / cents / product shortcuts from this upload
    // so the next unorganized file still maps to the same unique names
    learnFromRecords(newRecords);
    let normalized = applyIdentityToRecords(newRecords);
    if (importMode === 'append') {
      // rawRecords from closure is current working set restored from IDB
      normalized = mergeRecordsAppend(rawRecords, normalized);
    }
    setRawRecords([...normalized]);
    setDataSource(normalized.length > 0 ? 'upload' : 'empty');
    setLastUploadAt(
      new Date().toLocaleString([], {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      })
    );
    setDemoBannerDismissed(false);
    if (newPeriod) setPeriod(newPeriod);
    // Always update special months on import (empty array clears previous tags)
    setSpecialMonths(newSpecialMonths && newSpecialMonths.length > 0 ? newSpecialMonths : []);

    // Infer SalesTimeframe from actual date span OR keyword so "9 month" data shows as 9M
    if (newPeriod) {
      const p = newPeriod.toLowerCase();
      const monthsFromDates = inferMonthsFromPeriod(newPeriod);

      if (monthsFromDates != null) {
        setSelectedTimeframe(monthsToTimeframe(monthsFromDates));
      } else if (p.includes('9 month') || p.includes('9m') || p.includes('nine month')) {
        setSelectedTimeframe('9M');
      } else if (p.includes('6 month') || p.includes('6m') || p.includes('180')) {
        setSelectedTimeframe('6M');
      } else if (p.includes('2 year') || p.includes('2y') || p.includes('730')) {
        setSelectedTimeframe('2Y');
      } else if (p.includes('1 year') || p.includes('1y') || p.includes('ytd') || p.includes('365')) {
        setSelectedTimeframe('1Y');
      } else if (p.includes('1 month') || p.includes('1m') || p.includes('30 day') || p.includes('7 day') || p.includes('15 day')) {
        setSelectedTimeframe('1M');
      } else {
        setSelectedTimeframe('3M');
      }
    }

    if (newRecords.length > 0) {
      const weights = Array.from(new Set(newRecords.map(r => r.weight))).sort((a, b) => {
        const na = parseFloat(a);
        const nb = parseFloat(b);
        if (!isNaN(na) && !isNaN(nb)) return na - nb;
        return a.localeCompare(b);
      });
      setSelectedWeightFilter(weights[0] || '');
    } else {
      setSelectedWeightFilter('');
    }
    setSelectedBranchFilter('');
    setInspectingBranch(null);
    setInspectingProduct(null);
    // New upload → reset NetSuite filters so full dataset is visible
    setReportFilters(EMPTY_FILTERS);
    // Land on Master Excel Matrix so allocation matrix is visible immediately
    setActiveView('reports');
    setActiveReport('excel_sheet');
    setIsDailyUploadOpen(false);

    // Persist for Upload History → reopen previous analysis later
    if (normalized.length > 0) {
      try {
        saveDailySnapshot(
          normalized,
          undefined,
          `Upload ${newPeriod || period} · ${normalized.length} rows`
        );
      } catch {
        /* quota — ignore */
      }
      // Permanent IndexedDB working set (survives restart — append next day)
      void saveWorkingDataset(normalized, {
        mode: 'replace', // already merged in-memory when importMode was append
        label:
          importMode === 'append'
            ? `Appended ${new Date().toLocaleDateString()} · ${normalized.length} rows`
            : `Upload ${newPeriod || period} · ${normalized.length} rows`,
        period: newPeriod || period,
      }).catch((e) => console.warn('IndexedDB save failed', e));
    }
  };

  const handleBranchSelect = (branch: string) => {
    setSelectedBranchFilter(branch);
    setInspectingBranch(branch);
  };

  const handleWeightSelect = (weight: string) => {
    setSelectedWeightFilter(weight);
    setInspectingProduct(weight);
  };

  const handleNavigateFromAlert = (tab: string) => {
    if (tab === 'option_allocation') {
      setActiveView('option_allocation');
    } else if (tab === 'movement_aging') {
      setActiveView('movement_aging');
    } else if (tab === 'consignment_shipment' || tab === 'refill_demand' || tab === 'procurement') {
      setActiveView('reports');
      setActiveReport('refill_demand');
    } else if (tab === 'redistribution') {
      setActiveView('reports');
      setActiveReport('movement_summary');
    } else if (tab === 'excel_sheet' || tab === 'matrix') {
      setActiveView('reports');
      setActiveReport('excel_sheet');
    } else if (tab === 'branches') {
      setActiveView('reports');
      setActiveReport('branches');
    } else {
      setActiveView('dashboard');
    }
  };

  const handleResetData = () => {
    setRawRecords(DEFAULT_RAW_RECORDS);
    setDataSource('demo');
    setLastUploadAt(null);
    setDemoBannerDismissed(false);
    setPeriod(DEFAULT_PERIOD);
    setSelectedBranchFilter('');
    setSelectedWeightFilter(DEFAULT_RAW_RECORDS[0]?.weight || '');
    setSelectedTimeframe('1Y');
  };

  /** Software-format Excel: colours, borders, merged headers, wrap text */
  const handleExportExcel = () => {
    exportStyledExcelReport(report, period, allocationMode);
  };

  /** Print → Save as PDF (landscape, colour matrix) */
  const handleExportPdf = () => {
    exportReportPdf(report, period, allocationMode);
  };

  // Authentication Gate: require an active server-side session.
  if (authLoading) {
    return <LuminaSplash message="Securing session…" />;
  }

  if (!currentUser) {
    return (
      <LoginPortal
        onLoginSuccess={(user) => {
          setCurrentUser(user);
          setCurrentSession(user);
        }}
      />
    );
  }

  // Dynamic header information matching the reference image layout
  const headerInfo = {
    dashboard: {
      title: '2026 Universal Jewelry Stock Redistribution & Operations',
      subtitle: `Portfolio Scorecard | Reporting Period: ${period} | Refreshed Live System`
    },
    option_allocation: {
      title: 'Universal Item Stock Allocation & Redistribution Matrix',
      subtitle: `Portfolio Scorecard | Sales Contribution, 3-Month Coverage & Protected Company Reserve`
    },
    movement_aging: {
      title: 'Inventory Velocity, Movement & Aging Analytics',
      subtitle: `Portfolio Scorecard | Dormant Stock, Aging Brackets & Turnover Velocity`
    },
    consignment_shipment: {
      title: 'Refill Demand Report',
      subtitle: `Portfolio Scorecard | Showroom Replenishment by Carat / Design Breakdown`
    },
    menu: {
      title: 'Enterprise ERP Modules Directory',
      subtitle: `Portfolio Scorecard | Central Launchpad & Operational Services`
    },
    reports: {
      refill_demand: {
        title: 'Refill Demand Report',
        subtitle: `Portfolio Scorecard | Replenishment by Carat · Design breakdown when style sheets uploaded`
      },
      excel_sheet: {
        title: 'Master Allocation Matrix',
        subtitle: `Portfolio Scorecard | Branch × (Carat · Design) matrix from uploaded stock & sold`
      },
      outlet_design_matrix: {
        title: 'Outlet × Cts / Design Matrix',
        subtitle: `Portfolio Scorecard | Outlet-wise stock, sold, contribution and movement across Cts / Design`
      },
      movement_summary: {
        title: 'Movement Summary & Transfer Orders',
        subtitle: `Portfolio Scorecard | Recommended Stock Balancing Actions & Inter-Branch Transfers`
      },
      branches: {
        title: 'Retail Showrooms & Branch Balance Ratios',
        subtitle: `Portfolio Scorecard | Overstock Risk, Deficit Assessment & Outlet Performance`
      },
      weights: {
        title: 'Design-wise Stock Analysis',
        subtitle: `Portfolio Scorecard | High-Turn, Low-Turn, Stock Coverage & Aging Segments`
      },
      demand_booster: {
        title: 'Demand Booster & Sales Opportunity Analytics',
        subtitle: `Portfolio Scorecard | High-Demand Outlets vs. Dormant Outlet Redistribution`
      },
      execution: {
        title: 'Execution Report',
        subtitle: `Portfolio Scorecard | Contribution · 3-Month Baseline · Hybrid distribution options`
      },
      stock_turn_rate: {
        title: 'Stock Turn Rate Dashboard',
        subtitle: `Portfolio Scorecard | Sales ÷ Current Stock · Fast / Slow Outlet Ranking`
      }
    }[activeReport] || {
      title: 'Analytical Reports Suite',
      subtitle: `Portfolio Scorecard | Universal Multi-Item Inventory Intelligence`
    }
  }[activeView];

  return (
    <div className="software-shell min-h-screen flex flex-col selection:bg-[#14B4E8] selection:text-[#0A1728]">
      
      {/* 1. Classic ERP top toolbar */}
      <NetSuiteTopHeader
        activeView={activeView}
        activeReport={activeReport}
        onNavigateView={(view, report) => {
          setActiveView(view as any);
          if (report) {
            setActiveReport(report as any);
            // Any report id forces reports workspace
            if (view !== 'dashboard' && view !== 'option_allocation' && view !== 'movement_aging') {
              setActiveView('reports');
            }
          }
        }}
        selectedTimeframe={selectedTimeframe}
        onTimeframeChange={setSelectedTimeframe}
        allocationMode={allocationMode}
        onAllocationModeChange={setAllocationMode}
        period={period}
        onPeriodChange={setPeriod}
        onOpenDailyUpload={() => setIsDailyUploadOpen(true)}
        onExportExcel={handleExportExcel}
        onExportPdf={handleExportPdf}
        onOpenUploadHistory={() => setIsUploadHistoryOpen(true)}
        onToggleAICopilot={() => setIsAiDrawerOpen(!isAiDrawerOpen)}
        isAiDrawerOpen={isAiDrawerOpen}
        onOpenOperations={() => setIsOperationsFolderOpen(true)}
        onOpenUserManagement={() => { if (currentUser?.isOwner) setIsUserManagementOpen(true); }}
        onOpenSettings={() => { if (currentUser?.isOwner) setIsSettingsOpen(true); }}
        currentUser={currentUser}
        onLogout={() => {
          void logoutCurrentSession().finally(() => {
            setCurrentUser(null);
            setCurrentSession(null);
          });
        }}
        onQuickSearchBranch={(branch) => {
          setInspectingBranch(branch);
        }}
        theme={appSettings.theme}
        onThemeChange={(theme) => {
          setAppSettings((prev) => ({ ...prev, theme }));
        }}
      />

      {/* Demo dataset warning — real ERP never hides that sample data is loaded */}
      <DemoDataBanner
        visible={dataSource === 'demo' && !demoBannerDismissed}
        onUpload={() => setIsDailyUploadOpen(true)}
        onDismiss={() => setDemoBannerDismissed(true)}
      />

      {/* Body: left module nav + main content */}
      <div className="flex flex-1 min-h-0 w-full">
        <AppSideNav
          activeView={activeView}
          activeReport={activeReport}
          onNavigateView={(view, reportKey) => {
            setActiveView(view as any);
            if (reportKey) {
              setActiveReport(reportKey as any);
              if (view !== 'dashboard' && view !== 'option_allocation' && view !== 'movement_aging') {
                setActiveView('reports');
              }
            }
          }}
          onExportExcel={handleExportExcel}
          onExportPdf={handleExportPdf}
          onOpenUploadHistory={() => setIsUploadHistoryOpen(true)}
          onOpenDailyUpload={() => setIsDailyUploadOpen(true)}
        />

      {/* 2. MAIN APPLICATION CONTENT AREA */}
      <main className="flex-1 w-full min-w-0 max-w-[1600px] mx-auto">

        {/* SAP-style filter bar — hidden on All Reports (hub has its own filter panel) */}
        {activeView !== 'reports' && (
          <div className="px-2 sm:px-4 pt-2">
            <ReportFilterBar
              rawRecords={rawRecords}
              filters={reportFilters}
              onFiltersChange={setReportFilters}
              filteredCount={filteredRecords.length}
              totalCount={rawRecords.length}
            />
          </div>
        )}
        
        {/* VIEW 1: NETSUITE HOME DASHBOARD (3-Column Layout: Reminders, Tiles, KPIs, Trends) */}
        {(activeView === 'dashboard' || activeView === 'menu') && (
          <NetSuiteHomeDashboard
            report={report}
            onNavigateView={(view, subReport) => {
              setActiveView(view);
              if (subReport) {
                setActiveReport(subReport);
              }
            }}
            onSelectBranch={handleBranchSelect}
            onSelectWeight={handleWeightSelect}
            selectedTimeframe={selectedTimeframe}
            onTimeframeChange={setSelectedTimeframe}
            onOpenDailyUpload={() => setIsDailyUploadOpen(true)}
          />
        )}

        {/* SUB-VIEW CONTAINER (When viewing deep modules: Option Allocation, Movement, Consignment, Reports) */}
        {activeView !== 'dashboard' && activeView !== 'menu' && (
          <div className="p-3 sm:p-5 space-y-4">
            
            {/* Quick Navigation Breadcrumb & Back to NetSuite Home */}
            <div className="rounded-xl p-2.5 flex items-center justify-between border border-[#A9D9F0] bg-[#E8F4FC] shadow-sm">
              <div className="flex items-center gap-2 text-xs">
                <button
                  onClick={() => setActiveView('dashboard')}
                  className="inline-flex items-center gap-1.5 px-3 py-1 rounded-md bg-[#14B4E8] hover:bg-[#0C94D0] text-white font-bold cursor-pointer transition-colors"
                >
                  <Home className="w-3.5 h-3.5" />
                  <span>← Return to Operations Cockpit</span>
                </button>
                <span className="text-[#64748B]">|</span>
                <span className="text-[#4F6B88]">
                  Active Module: <strong className="text-[#0284C7] uppercase font-mono">{activeView.replace('_', ' ')}</strong>
                </span>
              </div>

              {selectedBranchFilter && (
                <div className="flex items-center gap-1.5 bg-[#f1f5f9] border border-[#cbd5e1] rounded px-2.5 py-0.5 text-xs text-[#334155]">
                  <span>Filter: <strong>{selectedBranchFilter}</strong></span>
                  <button
                    onClick={() => setSelectedBranchFilter('')}
                    className="ml-1 text-rose-600 hover:text-rose-800 font-bold cursor-pointer"
                  >
                    ×
                  </button>
                </div>
              )}
            </div>

            {/* VIEW 2: OPTION-WISE ALLOCATION & TRANSFER ENGINE */}
            {activeView === 'option_allocation' && (
              <OptionWiseAllocationView
                report={report}
                selectedWeight={selectedWeightFilter}
                selectedTimeframe={selectedTimeframe}
                onTimeframeChange={setSelectedTimeframe}
                allocationMode={allocationMode}
                onAllocationModeChange={setAllocationMode}
                onSelectBranch={handleBranchSelect}
                onSelectWeight={(w) => setSelectedWeightFilter(w)}
                onBackToHome={() => setActiveView('dashboard')}
              />
            )}

            {/* VIEW 3: UNIFIED MOVEMENT & AGING ANALYSIS */}
            {activeView === 'movement_aging' && (
              <MovementAndAgingReportView
                report={report}
                rawRecords={filteredRecords}
                onSelectBranch={handleBranchSelect}
                onSelectWeight={handleWeightSelect}
                onBackToHome={() => setActiveView('dashboard')}
              />
            )}

            {/* VIEW 4: Refill Demand only (consignment removed — same as refill) */}
            {activeView === 'consignment_shipment' && (
              <RefillDemandReport
                report={report}
                onSelectBranch={handleBranchSelect}
                onSelectWeight={handleWeightSelect}
              />
            )}

            {/* VIEW 5: ALL REPORTS HUB */}
            {activeView === 'reports' && (
              <div className="space-y-4">
                <AllReportsHub
                  rawRecords={rawRecords}
                  filters={reportFilters}
                  onFiltersChange={setReportFilters}
                  period={period}
                  activeReport={activeReport as ReportKey}
                  filteredCount={filteredRecords.length}
                  totalCount={rawRecords.length}
                  selectedTimeframe={selectedTimeframe}
                  specialMonths={specialMonths}
                  onSelectReport={(key, mode) => {
                    setActiveReport(key);
                    setAnalysisMode(mode === 'ai' || key === 'ai_crossmatch' ? 'ai' : 'manual');
                  }}
                />

                {activeReport === 'ai_crossmatch' && (
                  <AICrossmatchReportView
                    report={report}
                    onSwitchToManual={() => {
                      setAnalysisMode('manual');
                      setActiveReport('excel_sheet');
                    }}
                  />
                )}

                {activeReport === 'refill_demand' && (
                  <RefillDemandReport report={report} onSelectBranch={handleBranchSelect} onSelectWeight={handleWeightSelect} />
                )}
                {activeReport === 'excel_sheet' && <ExcelReportSheetView report={report} allocationMode={allocationMode} onAllocationModeChange={setAllocationMode} onSelectBranch={handleBranchSelect} onSelectWeight={handleWeightSelect} />}
                {activeReport === 'outlet_design_matrix' && <OutletDesignMatrixReport report={report} onSelectBranch={handleBranchSelect} onSelectWeight={handleWeightSelect} />}
                {activeReport === 'movement_summary' && <MovementSummaryView report={report} onSelectBranch={handleBranchSelect} onSelectWeight={handleWeightSelect} />}
                {activeReport === 'branches' && <BranchSummaryTable report={report} onSelectBranch={handleBranchSelect} />}
                {activeReport === 'weights' && <DesignWiseStockAnalysis report={report} onSelectWeight={handleWeightSelect} />}
                {activeReport === 'demand_booster' && <DemandOpportunityAnalysis report={report} onSelectBranch={handleBranchSelect} onSelectWeight={handleWeightSelect} />}
                {activeReport === 'stock_turn_rate' && (
                  <StockTurnRateDashboard report={report} onSelectBranch={handleBranchSelect} />
                )}
              </div>
            )}

          </div>
        )}

      </main>
      </div>{/* end body flex: side nav + main */}

      {/* Classic ERP status bar (replaces marketing footer inside console) */}
      <ErpStatusBar
        userName={currentUser?.name}
        userRole={currentUser?.role}
        period={period}
        rowCount={filteredRecords.length}
        branchCount={report.branchSummaries?.length || 0}
        skuCount={report.weightSummaries?.length || 0}
        timeframe={selectedTimeframe}
        allocationMode={allocationMode}
        theme={appSettings.theme}
        dataSource={dataSource}
        lastUploadAt={lastUploadAt}
        onAbout={() => setIsAboutOpen(true)}
      />

      <AboutLuminaModal isOpen={isAboutOpen} onClose={() => setIsAboutOpen(false)} />

      {/* User Management & Access Control Modal */}
      <UserManagementModal
        isOpen={isUserManagementOpen}
        onClose={() => setIsUserManagementOpen(false)}
        currentUser={currentUser}
      />

      {/* Settings, Theme & Account Preferences Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        currentUser={currentUser}
        onUserUpdated={(updated) => {
          setCurrentUser(updated);
        }}
        settings={appSettings}
        onSettingsUpdated={(newSettings) => {
          setAppSettings(newSettings);
        }}
        onOpenUserManagement={() => {
          setIsSettingsOpen(false);
          setIsUserManagementOpen(true);
        }}
        onResetToDefaults={() => {
          handleResetData();
          setIsSettingsOpen(false);
        }}
        rawRecordsCount={rawRecords.length}
      />

      {/* Operations & Data Center (Drawer / Folder Mode) */}
      <OperationsDataDrawer
        isOpen={isOperationsFolderOpen}
        onClose={() => setIsOperationsFolderOpen(false)}
        report={report}
        rawRecords={rawRecords}
        onImportRecords={handleImportRecords}
        onNavigateTab={(tab) => {
          handleNavigateFromAlert(tab);
        }}
      />

      {/* Daily Dual File Upload Modal (Current Stock + Sold Out) */}
      <DailyDualFileUploadModal
        isOpen={isDailyUploadOpen}
          existingRecordCount={rawRecords.length}
        onClose={() => setIsDailyUploadOpen(false)}
        onImportRecords={handleImportRecords}
        onOpenAiMode={() => {
          setActiveView('reports');
          setAnalysisMode('ai');
          setActiveReport('ai_crossmatch');
        }}
        currentPeriod={period}
      />

      <UploadHistoryPanel
        isOpen={isUploadHistoryOpen}
        onClose={() => setIsUploadHistoryOpen(false)}
        onRestore={(records, label, periodHint) => {
          handleImportRecords(records, periodHint || period);
          setLastUploadAt(`History: ${label}`);
        }}
      />

      {/* Movement Analysis AI Copilot Drawer */}
      <AIAssistantDrawer
        isOpen={isAiDrawerOpen}
        onClose={() => setIsAiDrawerOpen(false)}
        report={report}
      />

      {/* Branch 360° Comprehensive Report Modal */}
      <BranchDetailModal
        branchName={inspectingBranch}
        onClose={() => setInspectingBranch(null)}
        report={report}
        onSelectProduct={(w) => {
          setInspectingBranch(null);
          setInspectingProduct(w);
        }}
        onSelectAnotherBranch={(b) => setInspectingBranch(b)}
      />

      {/* Product Location Tracker Modal */}
      <ProductLocationModal
        productWeight={inspectingProduct}
        onClose={() => setInspectingProduct(null)}
        report={report}
        onSelectBranch={(b) => {
          setInspectingProduct(null);
          setInspectingBranch(b);
        }}
        onSelectAnotherProduct={(w) => setInspectingProduct(w)}
      />

    </div>
  );
}
