/**
 * DiaMatrix — product branding + corporate design tokens
 * Primary: Deep Navy · Accent: Teal · Text: Slate/Charcoal
 */
export const BRAND = {
  /** Full product name */
  full: 'DiaMatrix',
  /** Short product name (UI chrome, tabs, badges) */
  short: 'DiaMatrix',
  /** Company legal / footer */
  company: 'Diamond World LTD',
  /** Tagline */
  tagline: 'The Intelligent Distribution Engine for Precious Assets',
  /** Legacy house line */
  houseLine: 'precious assets intelligence',
  /** Console / desktop label */
  console: 'DiaMatrix Desktop Console',
  /** AI assistant label */
  aiName: 'DiaMatrix AI',
  /** Live status chip */
  liveStatus: 'LIVE · DIAMATRIX',
  /** Product version */
  version: '2.0.0',
  /** Build channel */
  channel: 'Production',
} as const;

/** Corporate analytical palette — keep UI components on these tokens */
export const PALETTE = {
  navy: '#0B2545',
  navyDeep: '#06142B',
  navyMid: '#143A66',
  teal: '#0D9488',
  tealBright: '#14B8A6',
  tealSoft: '#CCFBF1',
  slate: '#1F2937',
  slateMuted: '#4B5563',
  surface: '#FFFFFF',
  surfaceMuted: '#F8FAFC',
  surfaceTint: '#F1F5F9',
  border: '#E2E8F0',
  success: '#047857',
  danger: '#B91C1C',
  warning: '#B45309',
  info: '#0E7490',
  onDark: '#FFFFFF',
  onLight: '#1F2937',
} as const;

export type BrandKeys = typeof BRAND;
export type PaletteKeys = typeof PALETTE;
