import { RawInventoryRecord } from '../types';
import {
  mergeOutletToParent,
  isTrailingSOutlet,
  intelligentNormalizeBranch,
} from './dataIdentityEngine';
import { saveSnapshotToIdb, getSnapshotsFromIdb, deleteSnapshotFromIdb } from './indexedDbEngine';

export interface DailyInventorySnapshot {
  id: string;
  date: string; // YYYY-MM-DD
  displayDate: string; // e.g. "Sep 20, 2026"
  timestamp: number;
  label: string;
  totalStock: number;
  totalSold: number;
  branchesCount: number;
  variantsCount: number;
  records: RawInventoryRecord[];
}

export interface DayOverDayMovementItem {
  branch: string;
  weight: string;
  previousStock: number;
  currentStock: number;
  stockDelta: number; // current - previous
  detectedUnitsSold: number; // stock reduction = units sold in retail outlet
  replenishedUnits: number;
  daysBetween: number;
  dailySalesVelocity: number;
  daysToStockout: number;
  averageStock: number;
  movementStatus: 'RAPID_OUTFLOW' | 'STEADY_MOVEMENT' | 'REPLENISHED' | 'STAGNANT_IDLE';
}

export interface MovementAgingAnalysisResult {
  previousSnapshot: DailyInventorySnapshot;
  currentSnapshot: DailyInventorySnapshot;
  daysBetween: number;
  totalUnitsSoldDetected: number;
  totalUnitsReplenished: number;
  averageStockLevel: number;
  averageDailySalesRunRate: number;
  items: DayOverDayMovementItem[];
  topMovingOutlets: { branch: string; unitsSold: number }[];
  topMovingVariants: { weight: string; unitsSold: number }[];
  stagnantItemsCount: number;
}

const STORAGE_KEY = 'oracle_retail_daily_snapshots_v2';

/**
 * Loads all saved daily snapshots from localStorage
 */
export function getSavedSnapshots(): DailyInventorySnapshot[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed)) {
      return parsed.sort((a, b) => b.timestamp - a.timestamp);
    }
    return [];
  } catch (err) {
    console.error('Failed to parse snapshots from localStorage:', err);
    return [];
  }
}

/**
 * Saves a daily inventory snapshot into localStorage
 */
export function saveDailySnapshot(
  records: RawInventoryRecord[],
  dateStr?: string,
  customLabel?: string
): DailyInventorySnapshot {
  const now = new Date();
  const date = dateStr || now.toISOString().slice(0, 10);
  const displayDate = now.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric'
  });

  const totalStock = records.reduce((s, r) => s + (r.currentStock || 0), 0);
  const totalSold = records.reduce((s, r) => s + (r.soldQty || 0), 0);
  const branches = new Set(records.map(r => r.branch));
  const weights = new Set(records.map(r => r.weight));

  const snapshot: DailyInventorySnapshot = {
    id: `snap-${date}-${Date.now()}`,
    date,
    displayDate,
    timestamp: now.getTime(),
    label: customLabel || `Daily Entry (${displayDate}) - ${totalStock} Pcs Stock`,
    totalStock,
    totalSold,
    branchesCount: branches.size,
    variantsCount: weights.size,
    records
  };

  try {
    const existing = getSavedSnapshots();
    // Keep last 30 snapshots to respect quota
    const updated = [snapshot, ...existing.filter(s => s.date !== date)].slice(0, 30);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  } catch (err) {
    console.error('Failed to save snapshot to localStorage:', err);
  }

  // Permanent IndexedDB copy (survives quota issues better for large sets)
  try {
    void saveSnapshotToIdb(snapshot);
  } catch {
    /* non-blocking */
  }

  return snapshot;
}

/** Remove one snapshot by id */
export function deleteSnapshot(id: string): void {
  try {
    const existing = getSavedSnapshots().filter((s) => s.id !== id);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(existing));
  } catch (err) {
    console.error('Failed to delete snapshot:', err);
  }
  try {
    void deleteSnapshotFromIdb(id);
  } catch {
    /* ignore */
  }
}

/** Prefer IndexedDB history when available (async) */
export async function getSavedSnapshotsAsync(): Promise<DailyInventorySnapshot[]> {
  try {
    const fromIdb = await getSnapshotsFromIdb();
    if (fromIdb.length) return fromIdb;
  } catch {
    /* fall through */
  }
  return getSavedSnapshots();
}

/**
 * Compares two snapshots to generate the automated Day-over-Day Movement & Aging Analysis.
 * Implements the user's rule:
 * "jodi ami goto kal stock entry di shekhane 2 pcs thake abar ajke dilam shekhane 1 pcs thake
 * tarmane 1 pcs sale hoyeche koto dine sales hoolo average sales, average stock koto chilo egula dekha jay"
 */
/**
 * Build stock map keyed by exact outlet + weight.
 * Also index parent code so sub-branch (MOHS) can align with parent (MOH)
 * when one snapshot still carries the trailing-S code and the other was merged.
 */
function buildStockMaps(records: RawInventoryRecord[]): {
  exact: Map<string, number>;
  byParent: Map<string, number>;
  displayBranch: Map<string, string>;
} {
  const exact = new Map<string, number>();
  const byParent = new Map<string, number>();
  const displayBranch = new Map<string, string>();
  for (const r of records || []) {
    const branchRaw = String(r.branch || '').trim();
    if (!branchRaw) continue;
    const branchNorm = intelligentNormalizeBranch(branchRaw);
    const weight = String(r.weight || '').trim();
    const stock = Number(r.currentStock) || 0;
    const exactKey = `${branchNorm}__${weight}`;
    exact.set(exactKey, (exact.get(exactKey) || 0) + stock);
    displayBranch.set(exactKey, branchNorm);
    const parent = mergeOutletToParent(branchNorm);
    const parentKey = `${parent}__${weight}`;
    byParent.set(parentKey, (byParent.get(parentKey) || 0) + stock);
    if (!displayBranch.has(parentKey)) displayBranch.set(parentKey, parent);
    // Prefer showing trailing-S code when present
    if (isTrailingSOutlet(branchNorm)) {
      displayBranch.set(exactKey, branchNorm);
    }
  }
  return { exact, byParent, displayBranch };
}

function lookupStock(
  maps: { exact: Map<string, number>; byParent: Map<string, number> },
  branch: string,
  weight: string,
): number {
  const exactKey = `${branch}__${weight}`;
  if (maps.exact.has(exactKey)) return maps.exact.get(exactKey) || 0;
  const parent = mergeOutletToParent(branch);
  const parentKey = `${parent}__${weight}`;
  if (maps.exact.has(parentKey)) return maps.exact.get(parentKey) || 0;
  // Sum family only when looking up from parent against sub-coded rows
  if (!isTrailingSOutlet(branch) && maps.byParent.has(parentKey)) {
    return maps.byParent.get(parentKey) || 0;
  }
  return 0;
}

export function compareSnapshots(
  prevSnapshot: DailyInventorySnapshot,
  currSnapshot: DailyInventorySnapshot
): MovementAgingAnalysisResult {
  const prevMaps = buildStockMaps(prevSnapshot.records || []);
  const currMaps = buildStockMaps(currSnapshot.records || []);

  const allKeys = new Set<string>([
    ...Array.from(prevMaps.exact.keys()),
    ...Array.from(currMaps.exact.keys()),
  ]);
  // Include parent keys so sub-branch ↔ parent alignment surfaces in the audit
  for (const k of prevMaps.byParent.keys()) allKeys.add(k);
  for (const k of currMaps.byParent.keys()) allKeys.add(k);
  const daysDiff = Math.max(
    1,
    Math.round(Math.abs(currSnapshot.timestamp - prevSnapshot.timestamp) / (1000 * 60 * 60 * 24))
  );

  const items: DayOverDayMovementItem[] = [];
  let totalUnitsSoldDetected = 0;
  let totalUnitsReplenished = 0;

  const branchSalesMap: Record<string, number> = {};
  const weightSalesMap: Record<string, number> = {};
  let stagnantCount = 0;

  const seenPair = new Set<string>();
  allKeys.forEach(key => {
    const sep = key.indexOf('__');
    if (sep < 0) return;
    const branch = key.slice(0, sep);
    const weight = key.slice(sep + 2);
    // Deduplicate when both exact sub-branch and parent keys exist for same stock
    const parent = mergeOutletToParent(branch);
    const canonPair = `${parent}__${weight}__${isTrailingSOutlet(branch) ? branch : parent}`;
    if (seenPair.has(canonPair)) return;
    // Prefer exact trailing-S row when both exist
    if (!isTrailingSOutlet(branch) && allKeys.has(`${parent}s__${weight}`)) {
      return;
    }
    seenPair.add(canonPair);

    const prevStock = lookupStock(prevMaps, branch, weight);
    const currStock = lookupStock(currMaps, branch, weight);
    const stockDelta = currStock - prevStock;

    let detectedUnitsSold = 0;
    let replenishedUnits = 0;

    if (stockDelta < 0) {
      // Stock decreased -> units sold in outlet
      detectedUnitsSold = Math.abs(stockDelta);
      totalUnitsSoldDetected += detectedUnitsSold;
      branchSalesMap[branch] = (branchSalesMap[branch] || 0) + detectedUnitsSold;
      weightSalesMap[weight] = (weightSalesMap[weight] || 0) + detectedUnitsSold;
    } else if (stockDelta > 0) {
      replenishedUnits = stockDelta;
      totalUnitsReplenished += replenishedUnits;
    }

    const avgStock = (prevStock + currStock) / 2;
    const velocity = detectedUnitsSold / daysDiff;
    const daysToStockout = velocity > 0 ? Math.round(currStock / velocity) : 999;

    let movementStatus: DayOverDayMovementItem['movementStatus'] = 'STAGNANT_IDLE';
    if (detectedUnitsSold >= 2 || (detectedUnitsSold > 0 && currStock === 0)) {
      movementStatus = 'RAPID_OUTFLOW';
    } else if (detectedUnitsSold > 0) {
      movementStatus = 'STEADY_MOVEMENT';
    } else if (replenishedUnits > 0) {
      movementStatus = 'REPLENISHED';
    } else {
      stagnantCount++;
    }

    items.push({
      branch,
      weight,
      previousStock: prevStock,
      currentStock: currStock,
      stockDelta,
      detectedUnitsSold,
      replenishedUnits,
      daysBetween: daysDiff,
      dailySalesVelocity: Math.round(velocity * 100) / 100,
      daysToStockout,
      averageStock: Math.round(avgStock * 10) / 10,
      movementStatus
    });
  });

  // Sort items: rapid outflow first
  items.sort((a, b) => b.detectedUnitsSold - a.detectedUnitsSold || a.daysToStockout - b.daysToStockout);

  const topMovingOutlets = Object.entries(branchSalesMap)
    .map(([branch, unitsSold]) => ({ branch, unitsSold }))
    .sort((a, b) => b.unitsSold - a.unitsSold);

  const topMovingVariants = Object.entries(weightSalesMap)
    .map(([weight, unitsSold]) => ({ weight, unitsSold }))
    .sort((a, b) => b.unitsSold - a.unitsSold);

  const totalCurrentStock = currSnapshot.totalStock;
  const totalPreviousStock = prevSnapshot.totalStock;
  const averageStockLevel = Math.round(((totalPreviousStock + totalCurrentStock) / 2) * 10) / 10;
  const averageDailySalesRunRate = Math.round((totalUnitsSoldDetected / daysDiff) * 100) / 100;

  return {
    previousSnapshot: prevSnapshot,
    currentSnapshot: currSnapshot,
    daysBetween: daysDiff,
    totalUnitsSoldDetected,
    totalUnitsReplenished,
    averageStockLevel,
    averageDailySalesRunRate,
    items,
    topMovingOutlets,
    topMovingVariants,
    stagnantItemsCount: stagnantCount
  };
}

/**
 * Initializes baseline historical snapshots if user visits for the first time,
 * demonstrating yesterday vs today stock transition with exact sold detection.
 */
export function ensureInitialHistoricalData(currentRecords: RawInventoryRecord[]): DailyInventorySnapshot[] {
  const saved = getSavedSnapshots();
  if (saved.length >= 2) return saved;

  const now = new Date();
  const todayStr = now.toISOString().slice(0, 10);
  const yesterday = new Date(now.getTime() - 24 * 60 * 60 * 1000);
  const yesterdayStr = yesterday.toISOString().slice(0, 10);

  // Generate realistic yesterday records where outlets had +1 or +2 pieces that were sold today
  const yesterdayRecords: RawInventoryRecord[] = currentRecords.map((r, i) => {
    // If the outlet has sales, simulate that yesterday they had +1 piece in stock before selling it
    const hadSale = (r.soldQty || 0) > 0 && (i % 3 === 0 || r.currentStock === 0);
    const addedPrevStock = hadSale ? 1 : 0;
    return {
      ...r,
      id: `prev-${r.id}`,
      currentStock: r.currentStock + addedPrevStock
    };
  });

  const prevDisplayDate = yesterday.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  const currDisplayDate = now.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });

  const prevSnap: DailyInventorySnapshot = {
    id: `snap-${yesterdayStr}-init`,
    date: yesterdayStr,
    displayDate: prevDisplayDate,
    timestamp: yesterday.getTime(),
    label: `Baseline Previous Stock (${prevDisplayDate})`,
    totalStock: yesterdayRecords.reduce((s, r) => s + r.currentStock, 0),
    totalSold: yesterdayRecords.reduce((s, r) => s + (r.soldQty || 0), 0),
    branchesCount: new Set(yesterdayRecords.map(r => r.branch)).size,
    variantsCount: new Set(yesterdayRecords.map(r => r.weight)).size,
    records: yesterdayRecords
  };

  const currSnap: DailyInventorySnapshot = {
    id: `snap-${todayStr}-current`,
    date: todayStr,
    displayDate: currDisplayDate,
    timestamp: now.getTime(),
    label: `Current Live Audit (${currDisplayDate})`,
    totalStock: currentRecords.reduce((s, r) => s + r.currentStock, 0),
    totalSold: currentRecords.reduce((s, r) => s + (r.soldQty || 0), 0),
    branchesCount: new Set(currentRecords.map(r => r.branch)).size,
    variantsCount: new Set(currentRecords.map(r => r.weight)).size,
    records: currentRecords
  };

  const initialList = [currSnap, prevSnap];
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(initialList));
  } catch (err) {
    console.error('Failed to write initial snapshots:', err);
  }

  return initialList;
}

/* -------------------------------------------------------------------------- */
/* Offline RBAC seal — local capability grant when cloud auth is unavailable  */
/* -------------------------------------------------------------------------- */

const OFFLINE_AUTH_SEAL_KEY = 'diamatrix_offline_auth_seal_v1';

export interface OfflineCapabilityGrant {
  userId: string;
  username: string;
  role: string;
  grantedAt: number;
  canViewAnalytics: boolean;
  canEdit: boolean;
  canUpload: boolean;
  canExport: boolean;
  /** Feature keys available while disconnected */
  offlineFeatures: string[];
}

export function getOfflineAuthSeal(): OfflineCapabilityGrant | null {
  try {
    const raw = localStorage.getItem(OFFLINE_AUTH_SEAL_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as OfflineCapabilityGrant;
    if (!parsed?.userId || !parsed?.username) return null;
    return parsed;
  } catch {
    return null;
  }
}

export function setOfflineAuthSeal(grant: OfflineCapabilityGrant): void {
  try {
    localStorage.setItem(OFFLINE_AUTH_SEAL_KEY, JSON.stringify(grant));
  } catch {
    /* quota / private mode */
  }
}

export function clearOfflineAuthSeal(): void {
  try {
    localStorage.removeItem(OFFLINE_AUTH_SEAL_KEY);
  } catch {
    /* ignore */
  }
}

/** True when a valid offline capability seal exists for RBAC-gated analytics. */
export function hasOfflineAnalyticsAccess(): boolean {
  const seal = getOfflineAuthSeal();
  return Boolean(seal?.canViewAnalytics);
}
