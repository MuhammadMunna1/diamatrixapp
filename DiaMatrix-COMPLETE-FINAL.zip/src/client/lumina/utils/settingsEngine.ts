import { SalesTimeframe } from '../types';

export type AppTheme = 'cosmic' | 'obsidian' | 'light' | 'midnight' | 'emerald' | 'royal-gold' | 'platinum-gold';
export type TableDensity = 'compact' | 'standard' | 'comfortable';
export type CurrencyFormat = 'BDT' | 'USD' | 'EUR' | 'INR';
export type NumberNotation = 'south_asian' | 'international';
export type RedistributionStrategy = 'proportional' | 'aggressive_velocity' | 'balanced_safety';

export interface AppSettings {
  theme: AppTheme;
  density: TableDensity;
  currency: CurrencyFormat;
  numberNotation: NumberNotation;
  defaultTimeframe: SalesTimeframe;
  strategy: RedistributionStrategy;
  minBranchSafetyBuffer: number;
  agingWarningDays: number;
  autoSaveSession: boolean;
  highlightDeficits: boolean;
}

export const DEFAULT_SETTINGS: AppSettings = {
  theme: 'light',
  density: 'standard',
  currency: 'BDT',
  numberNotation: 'south_asian',
  defaultTimeframe: '1Y',
  strategy: 'proportional',
  minBranchSafetyBuffer: 0,
  agingWarningDays: 180,
  autoSaveSession: true,
  highlightDeficits: true
};

const SETTINGS_KEY = 'dwl_analytics_app_settings';
const THEME_PALETTE_VERSION_KEY = 'dwl_theme_palette_version';
const THEME_PALETTE_VERSION = 'light-enterprise-v2';

function normalizeTheme(theme: unknown): AppTheme {
  if (theme === 'obsidian' || theme === 'light' || theme === 'midnight' || theme === 'emerald' || theme === 'cosmic' || theme === 'royal-gold' || theme === 'platinum-gold') {
    return theme;
  }
  return 'light';
}

export function getStoredSettings(): AppSettings {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (!raw) {
      localStorage.setItem(SETTINGS_KEY, JSON.stringify(DEFAULT_SETTINGS));
      localStorage.setItem(THEME_PALETTE_VERSION_KEY, THEME_PALETTE_VERSION);
      return DEFAULT_SETTINGS;
    }
    const parsed = JSON.parse(raw);
    const hasPaletteMigration = localStorage.getItem(THEME_PALETTE_VERSION_KEY) === THEME_PALETTE_VERSION;
    const theme = hasPaletteMigration ? normalizeTheme(parsed.theme) : 'light';
    const settings = { ...DEFAULT_SETTINGS, ...parsed, theme: 'light' as AppTheme };
    if (!hasPaletteMigration) {
      localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
      localStorage.setItem(THEME_PALETTE_VERSION_KEY, THEME_PALETTE_VERSION);
    }
    return settings;
  } catch (e) {
    return DEFAULT_SETTINGS;
  }
}

export function saveStoredSettings(settings: AppSettings): void {
  try {
    const lightSettings = { ...settings, theme: 'light' as AppTheme };
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(lightSettings));
    localStorage.setItem(THEME_PALETTE_VERSION_KEY, THEME_PALETTE_VERSION);
    applyThemeToDocument('light');
  } catch (e) {
    console.error('Failed to save settings:', e);
  }
}

export function applyThemeToDocument(_theme: AppTheme): void {
  const root = document.documentElement;
  root.classList.remove('theme-obsidian', 'theme-light', 'theme-midnight', 'theme-emerald', 'theme-cosmic', 'theme-royal-gold', 'theme-platinum-gold', 'dark');
  root.classList.add('theme-light');
  root.setAttribute('data-theme', 'light');
  try {
    root.style.colorScheme = 'light';
  } catch {
    /* ignore */
  }
}


/** Cycle next theme (header / keyboard helper) */
export function cycleTheme(current: AppTheme): AppTheme {
  return current === 'light' ? 'cosmic' : 'light';
}

export function formatCurrencyValue(val: number, currency: CurrencyFormat = 'BDT'): string {
  const symbols: Record<CurrencyFormat, string> = {
    BDT: '৳',
    USD: '$',
    EUR: '€',
    INR: '₹'
  };
  const sym = symbols[currency] || '৳';
  return `${sym}${val.toLocaleString()}`;
}
