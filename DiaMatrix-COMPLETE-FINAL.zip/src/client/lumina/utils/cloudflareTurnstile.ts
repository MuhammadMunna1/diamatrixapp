/**
 * Cloudflare Turnstile — bot protection for Sign In.
 *
 * Production setup:
 *   1. Cloudflare Dashboard → Turnstile → Add site
 *   2. VITE_TURNSTILE_SITE_KEY  (public widget key)
 *   3. TURNSTILE_SECRET_KEY     (server-only siteverify secret)
 *
 * When no real site key is set the widget is not rendered (no test banner / extra text)
 * and local login is allowed. Set real keys for the clean "Verify you are human" checkbox.
 *
 * @see https://developers.cloudflare.com/turnstile/
 */

declare global {
  interface Window {
    turnstile?: {
      render: (
        el: string | HTMLElement,
        options: {
          sitekey: string;
          theme?: 'light' | 'dark' | 'auto';
          size?: 'normal' | 'compact' | 'flexible';
          callback?: (token: string) => void;
          'error-callback'?: () => void;
          'expired-callback'?: () => void;
          'timeout-callback'?: () => void;
        },
      ) => string;
      reset: (widgetId?: string) => void;
      remove: (widgetId?: string) => void;
      getResponse: (widgetId?: string) => string | undefined;
    };
    onTurnstileLoad?: () => void;
  }
}

/** Official Cloudflare always-pass test key (shows "For testing only" banner — avoid in UI). */
const TURNSTILE_TEST_SITE_KEY = '1x00000000000000000000AA';

/**
 * Public site key from env. Empty string when unset so we never show the test banner.
 */
export function getTurnstileSiteKey(): string {
  try {
    const env = (import.meta as any)?.env;
    const key = String(env?.VITE_TURNSTILE_SITE_KEY || '').trim();
    // Reject the known test key so the testing banner never appears in the form.
    if (key && key !== TURNSTILE_TEST_SITE_KEY) return key;
  } catch {
    /* ignore */
  }
  return '';
}

/** True when a real (non-test) site key is configured — widget will be shown. */
export function isTurnstileEnabled(): boolean {
  return Boolean(getTurnstileSiteKey());
}

/** @deprecated use isTurnstileEnabled(); kept for call-site compatibility */
export function isTurnstileTestMode(): boolean {
  return !isTurnstileEnabled();
}

const SCRIPT_ID = 'cf-turnstile-api';
const SCRIPT_SRC = 'https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit';

let scriptPromise: Promise<void> | null = null;

/** Load Turnstile API once (explicit render). */
export function loadTurnstileScript(): Promise<void> {
  if (typeof window === 'undefined') return Promise.resolve();
  if (window.turnstile) return Promise.resolve();
  if (scriptPromise) return scriptPromise;

  scriptPromise = new Promise((resolve, reject) => {
    const existing = document.getElementById(SCRIPT_ID);
    if (existing) {
      if (window.turnstile) {
        resolve();
        return;
      }
      existing.addEventListener('load', () => resolve());
      existing.addEventListener('error', () => reject(new Error('Turnstile script failed')));
      return;
    }

    const s = document.createElement('script');
    s.id = SCRIPT_ID;
    s.src = SCRIPT_SRC;
    s.async = true;
    s.defer = true;
    s.onload = () => resolve();
    s.onerror = () => {
      scriptPromise = null;
      reject(new Error('Could not load Cloudflare Turnstile'));
    };
    document.head.appendChild(s);
  });

  return scriptPromise;
}

/**
 * Verify token with backend (Cloudflare siteverify).
 * When Turnstile is not enabled (no real key), always allow.
 */
export async function verifyTurnstileToken(token: string): Promise<{ ok: boolean; error?: string }> {
  if (!isTurnstileEnabled()) {
    return { ok: true };
  }

  if (!token || !token.trim()) {
    return { ok: false, error: 'Complete the security check.' };
  }

  try {
    const res = await fetch('/api/auth/turnstile/verify', {
      method: 'POST',
      credentials: 'include',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ token }),
    });
    if (res.ok) {
      const data = await res.json().catch(() => ({}));
      if (data.success === false) {
        return { ok: false, error: data.error || 'Security check failed. Try again.' };
      }
      return { ok: true };
    }
    const data = await res.json().catch(() => ({}));
    return { ok: false, error: data.error || 'Security verification unavailable.' };
  } catch {
    return { ok: false, error: 'Could not reach security service. Check network.' };
  }
}
