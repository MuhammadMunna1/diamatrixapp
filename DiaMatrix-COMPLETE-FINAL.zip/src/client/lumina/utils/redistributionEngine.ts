import {
  RawInventoryRecord,
  BranchSummary,
  WeightSummary,
  TransferOrder,
  ProcurementOrder,
  ActionAlert,
  RedistributionReport,
  CategoryConfig,
  SalesTimeframe,
  AllocationMode,
  StockAgingBucket,
  ConsignmentRecommendation,
  OptionAllocationSummary,
  OptionAllocationRow,
  SpecialMonth
} from '../types';
import { ALL_BRANCHES, ALL_WEIGHTS, DEFAULT_PERIOD } from '../data/defaultDataset';
import { CATEGORY_PRESETS } from '../data/categoryPresets';
import {
  intelligentNormalizeBranch,
  mergeOutletToParent,
  isTrailingSOutlet,
  isOnlineBranch,
  isExcludedOutlet,
} from './dataIdentityEngine';

/**
 * For matrix / reports: combine BLYS→BLY, DNMS→DNM, RANS→RAN, SAV→RUP, etc.
 * FAIR, BAC, Online never enter matrix / outlet counts. JAS = Jashore (main).
 */

/** Coerce to a finite non-negative number (anomalies → 0). */
export function safeNonNeg(value: unknown, fallback = 0): number {
  const n = typeof value === 'number' ? value : Number(value);
  if (!Number.isFinite(n) || n < 0) return fallback;
  return n;
}

/** Safe division — never returns Infinity/NaN; empty denominator → fallback. */
export function safeDiv(numerator: unknown, denominator: unknown, fallback = 0): number {
  const n = safeNonNeg(numerator, 0);
  const d = typeof denominator === 'number' ? denominator : Number(denominator);
  if (!Number.isFinite(d) || d === 0) return fallback;
  const q = n / d;
  return Number.isFinite(q) ? q : fallback;
}

/** Round to integer pcs without producing negative stock targets. */
export function safeAllocUnits(value: unknown): number {
  const n = safeNonNeg(value, 0);
  return Math.max(0, Math.round(n));
}

function canonBranch(b: string, preserveTrailingS: boolean): string {
  const norm = intelligentNormalizeBranch(b || '');
  if (isExcludedOutlet(norm) || isOnlineBranch(norm)) return 'ONLS';
  if (preserveTrailingS && isTrailingSOutlet(norm)) return norm;
  return mergeOutletToParent(norm);
}

const timeframeMonths = (timeframe: SalesTimeframe): number => ({
  '1M': 1, '3M': 3, '6M': 6, '9M': 9, '1Y': 12, '2Y': 24
}[timeframe]);

/**
 * Capital Liquidity (Aging) weights.
 * weight = sales_contribution / max(average_shelf_aging_days, 1)
 * If aging > 90 days the weight is scaled down proportionally so slow-aging
 * outlets receive less new capital (inventory) and liquidity is freed.
 */
export function calculateCapitalLiquidityWeights(
  outlets: Array<{
    branch: string;
    sales_contribution: number;
    average_shelf_aging_days: number;
    current_stock: number;
  }>,
  availablePool: number
): Array<{
  branch: string;
  liquidityWeight: number;
  agingPenalty: number;
  recommendedMoveQty: number;
  reason: string;
}> {
  const AGING_THRESHOLD = 90;
  const scored = outlets.map((o) => {
    const aging = Math.max(1, safeNonNeg(o.average_shelf_aging_days, 1) || 1);
    const contrib = safeNonNeg(o.sales_contribution, 0);
    const rawWeight = safeDiv(contrib, aging, 0);
    const agingPenalty =
      aging > AGING_THRESHOLD ? safeDiv(AGING_THRESHOLD, aging, 1) : 1;
    const liquidityWeight = rawWeight * agingPenalty;
    return {
      branch: o.branch,
      liquidityWeight,
      agingPenalty,
      aging,
      contrib,
      current_stock: Math.max(0, Number(o.current_stock) || 0),
    };
  });
  const totalWeight = scored.reduce((s, r) => s + r.liquidityWeight, 0);
  const pool = Math.max(0, Math.floor(availablePool));
  return scored
    .map((r) => {
      const share = safeDiv(r.liquidityWeight, totalWeight, 0);
      const recommendedMoveQty = Math.round(pool * share);
      const reason =
        r.aging > AGING_THRESHOLD
          ? `Aging ${Math.round(r.aging)}d > ${AGING_THRESHOLD}d — allocation scaled by ${(r.agingPenalty * 100).toFixed(0)}% for capital liquidity`
          : `Healthy aging ${Math.round(r.aging)}d — full sales-weighted share`;
      return {
        branch: r.branch,
        liquidityWeight: Math.round(r.liquidityWeight * 10000) / 10000,
        agingPenalty: Math.round(r.agingPenalty * 1000) / 1000,
        recommendedMoveQty,
        reason,
      };
    })
    .sort((a, b) => b.recommendedMoveQty - a.recommendedMoveQty);
}

/**
 * Demand-Backup & Safety ideal demand for one outlet.
 * Ideal = 3-month base stock
 *        + 20% bonus if high-performing branch
 *        + forced safety buffer when current stock is 0 (stock-out event)
 */
export function calculateIdealDemandBackup(input: {
  salesAvgMonthly: number;
  isHighPerformer: boolean;
  currentStock: number;
  growthMultiplier?: number;
  stockOutSafetyUnits?: number;
}): {
  base3M: number;
  highPerformerBonus: number;
  stockOutSafety: number;
  totalIdealDemand: number;
} {
  const salesAvg = safeNonNeg(input.salesAvgMonthly, 0);
  const stock = safeNonNeg(input.currentStock, 0);
  const growth = Math.max(1, safeNonNeg(input.growthMultiplier, 1) || 1);
  const base3M = salesAvg * 3;
  const highPerformerBonus = input.isHighPerformer ? base3M * 0.2 * growth : 0;
  const stockOutSafety =
    stock <= 0 && salesAvg > 0
      ? Math.max(1, safeNonNeg(input.stockOutSafetyUnits, Math.ceil(salesAvg)))
      : 0;
  const totalIdealDemand = Math.max(0, base3M + highPerformerBonus + stockOutSafety);
  return {
    base3M: Math.round(base3M * 100) / 100,
    highPerformerBonus: Math.round(highPerformerBonus * 100) / 100,
    stockOutSafety,
    totalIdealDemand: Math.round(totalIdealDemand * 100) / 100,
  };
}

/** Shared Have-vs-Deserve target calculation for dashboard moves and option analysis.
 *  Modes (all respect Demand-Backup & Capital Liquidity when aging map is provided):
 *  - contribution  → sales share of company pool
 *  - baseline      → 3-month ideal demand (+20% high-performer, stock-out safety)
 *  - hybrid        → max(contribution, baseline), then compress to live stock
 *  Capital Liquidity: when average_shelf_aging_days > 90, target is scaled down.
 */
function buildAllocationTargets(
  branches: { branch: string; stock: number; sales: number; avgAgingDays?: number }[],
  totalCompanyStock: number,
  timeframe: SalesTimeframe,
  mode: AllocationMode,
  specialMonthCount = 0,
  growthMultiplier = 1
): { rawTargets: Record<string, number>; targets: Record<string, number>; compression: number; scaleFactor: number; totalTarget: number } {
  const AGING_THRESHOLD = 90;
  const months = Math.max(1, timeframeMonths(timeframe) || 1);
  const specialCount = safeNonNeg(specialMonthCount, 0);
  const pool = safeNonNeg(totalCompanyStock, 0);
  const normalizedMonths =
    months + 0.8 * Math.min(Math.max(0, months - 1), specialCount);
  const list = Array.isArray(branches) ? branches : [];
  const totalSales = list.reduce((sum, b) => sum + safeNonNeg(b?.sales, 0), 0);
  const averageMonthlySales = safeDiv(
    totalSales,
    normalizedMonths * Math.max(1, list.length),
    0,
  );
  const drafts = list.map((b) => {
    const sales = safeNonNeg(b?.sales, 0);
    const stock = safeNonNeg(b?.stock, 0);
    const avgMonthly = safeDiv(sales, normalizedMonths, 0);
    const isHighPerformer = avgMonthly > averageMonthlySales;
    const demand = calculateIdealDemandBackup({
      salesAvgMonthly: avgMonthly,
      isHighPerformer,
      currentStock: stock,
      growthMultiplier,
    });
    const baseline = safeNonNeg(demand.totalIdealDemand, 0);
    const contribution = safeDiv(pool * sales, totalSales, 0);
    const aging = Math.max(1, safeNonNeg(b?.avgAgingDays, 1) || 1);
    const liquidityFactor =
      aging > AGING_THRESHOLD ? safeDiv(AGING_THRESHOLD, aging, 1) : 1;
    const liquidityWeight = safeDiv(sales, totalSales, 0) * liquidityFactor;
    return {
      branch: String(b?.branch || '').trim() || 'UNKNOWN',
      sales,
      stock,
      contribution,
      baseline,
      liquidityFactor,
      liquidityWeight,
      stockOut: stock <= 0 && sales > 0,
    };
  });
  const totalLiquidityWeight = drafts.reduce((sum, d) => sum + safeNonNeg(d.liquidityWeight, 0), 0);
  const idealBaselineTotal = drafts.reduce((sum, d) => sum + safeNonNeg(d.baseline, 0), 0);
  const scaleFactor = safeDiv(pool, idealBaselineTotal, 1);
  // Coverage: every outlet must hold product so sales can start (even 0 sales history).
  // min 1 pc each if pool allows; remainder of company stock by sales share.
  const nOutlets = Math.max(1, drafts.length);
  const minPerOutlet =
    mode === 'coverage' && pool >= nOutlets
      ? 1
      : 0;
  const coverageFloorTotal = minPerOutlet * nOutlets;
  const residualPool = Math.max(0, pool - coverageFloorTotal);
  const rawTargets: Record<string, number> = {};
  drafts.forEach((d) => {
    let target: number;
    switch (mode) {
      case 'contribution':
        target = safeNonNeg(d.contribution, 0);
        break;
      case 'baseline':
      case 'demand_backup':
        target = safeNonNeg(d.baseline, 0);
        break;
      case 'liquidity':
        target = safeDiv(pool * d.liquidityWeight, totalLiquidityWeight, 0);
        break;
      case 'coverage': {
        const salesShare = safeDiv(d.sales, totalSales, 1 / nOutlets);
        target = minPerOutlet + residualPool * salesShare;
        break;
      }
      case 'hybrid':
      default:
        target =
          Math.max(safeNonNeg(d.contribution, 0), safeNonNeg(d.baseline, 0)) *
          safeNonNeg(d.liquidityFactor, 1);
        break;
    }
    if (d.stockOut && target < 1) target = 1;
    // Never emit negative or non-finite Deserve quantities
    rawTargets[d.branch] = safeNonNeg(target, 0);
  });
  const rawTotal = Object.values(rawTargets).reduce((sum, n) => sum + safeNonNeg(n, 0), 0);
  const compression = rawTotal > pool && rawTotal > 0 ? safeDiv(pool, rawTotal, 1) : 1;
  const scaled = drafts.map((d) => {
    const exact = safeNonNeg(rawTargets[d.branch], 0) * compression;
    return {
      branch: d.branch,
      exact,
      fraction: exact - Math.floor(exact),
      sales: d.sales,
    };
  });
  const targetTotal = Math.min(
    Math.floor(pool),
    Math.max(0, Math.round(rawTotal * compression)),
  );
  const targets: Record<string, number> = {};
  let assigned = 0;
  scaled.forEach((d) => {
    targets[d.branch] = Math.max(0, Math.floor(d.exact));
    assigned += targets[d.branch];
  });
  scaled.sort(
    (a, b) =>
      b.fraction - a.fraction ||
      b.sales - a.sales ||
      a.branch.localeCompare(b.branch),
  );
  for (
    let remaining = Math.max(0, targetTotal - assigned), i = 0;
    remaining > 0 && scaled.length;
    remaining--, i++
  ) {
    const row = scaled[i % scaled.length];
    targets[row.branch] = safeNonNeg(targets[row.branch], 0) + 1;
  }
  // Final clamp — sum of targets must not exceed live company pool
  let sumTargets = Object.values(targets).reduce((s, n) => s + n, 0);
  if (sumTargets > pool && pool >= 0) {
    const order = [...scaled].sort((a, b) => targets[b.branch] - targets[a.branch]);
    let excess = sumTargets - Math.floor(pool);
    for (const row of order) {
      if (excess <= 0) break;
      const cur = targets[row.branch] || 0;
      const cut = Math.min(cur, excess);
      targets[row.branch] = cur - cut;
      excess -= cut;
    }
  }
  return {
    rawTargets,
    targets,
    compression,
    scaleFactor,
    totalTarget: Object.values(targets).reduce((s, n) => s + n, 0),
  };
}

export function calculateRedistributionReport(
  records: RawInventoryRecord[],
  period: string = DEFAULT_PERIOD,
  categoryConfig?: CategoryConfig,
  baseBranches?: string[],
  baseWeights?: string[],
  selectedTimeframe: SalesTimeframe = '1Y',
  allocationMode: AllocationMode = 'contribution',
  specialMonths?: SpecialMonth[],
  /** When true (user searched a Design Name), matrix uses "carat · design" rows.
   *  When false, aggregate to pure carat = main category stock & sales view. */
  designMode: boolean = false,
  /** When true, do not merge MOHS→MOH (user asked for that exact outlet only). */
  preserveTrailingS: boolean = false
): RedistributionReport {
  const activeCategory: CategoryConfig = categoryConfig || CATEGORY_PRESETS[0];

  /**
   * Category vs style layer (prevents double-count / wrong matrix):
   * - designMode OFF → prefer rows without itemCode (main Nosepin 7 Stone stock & sold)
   * - designMode ON  → prefer rows with itemCode (NP7SD* breakdown); fallback to all if none
   * Style sheets are partial breakdowns of the same category stock — never mix both layers.
   */
  const hasCategoryLayer = records.some((r) => !(r.itemCode || r.variant || '').trim());
  const hasDesignLayer = records.some((r) => !!(r.itemCode || r.variant || '').trim());
  let viewRecords = records;
  if (designMode && hasDesignLayer) {
    viewRecords = records.filter((r) => !!(r.itemCode || r.variant || '').trim());
  } else if (!designMode && hasCategoryLayer) {
    viewRecords = records.filter((r) => !(r.itemCode || r.variant || '').trim());
  }

  const normalizedRecords = viewRecords.map((r) => ({
    ...r,
    branch: canonBranch(r.branch, preserveTrailingS),
  }));

  // Determine branch list — exclude Online, FAIR, BAC and other non-outlets
  const isReportableBranch = (b: string) => !isOnlineBranch(b) && !isExcludedOutlet(b);
  let branches: string[];
  if (baseBranches && baseBranches.length > 0) {
    const bSet = new Set<string>(baseBranches.map((b) => canonBranch(b, preserveTrailingS)));
    normalizedRecords.forEach((r) => {
      if (r.branch) bSet.add(r.branch);
    });
    branches = Array.from(bSet).filter(isReportableBranch);
  } else if (normalizedRecords.length > 0) {
    const bSet = new Set<string>();
    normalizedRecords.forEach((r) => {
      if (r.branch) bSet.add(r.branch);
    });
    branches = Array.from(bSet).filter(isReportableBranch);
  } else {
    branches = [...ALL_BRANCHES].filter(isReportableBranch);
  }

  // Drop Online / FAIR / invalid codes from calculation pool
  records = normalizedRecords.filter((r) => isReportableBranch(r.branch));

  /** Item key: pure carat (category level) OR "0.02 · NP7SD1" only when designMode is on */
  const itemKeyOf = (r: RawInventoryRecord): string => {
    const w = String(r.weight || '').trim();
    if (designMode) {
      const code = (r.itemCode || r.variant || '').trim();
      if (code) return `${w} · ${code}`;
    }
    return w;
  };

  // Determine items / weights list (design-aware composite keys when available)
  let weights: string[];
  if (baseWeights && baseWeights.length > 0) {
    const wSet = new Set<string>(baseWeights);
    records.forEach(r => { if (r.weight) wSet.add(itemKeyOf(r)); });
    weights = Array.from(wSet);
  } else if (records.length > 0) {
    const wSet = new Set<string>();
    records.forEach(r => { if (r.weight) wSet.add(itemKeyOf(r)); });
    weights = Array.from(wSet);
  } else {
    weights = [...ALL_WEIGHTS];
  }

  // Sort: design name first (A–Z), then carat ascending within each design.
  // Category-only (no design) rows stay grouped at the top by carat.
  weights.sort((a, b) => {
    const parseKey = (s: string) => {
      const parts = s.split(' · ');
      const num = parseFloat(parts[0]);
      return {
        num: isNaN(num) ? null : num,
        design: (parts[1] || '').trim().toUpperCase(),
        raw: s,
      };
    };
    const A = parseKey(a);
    const B = parseKey(b);
    // Rows without design come before design-level rows
    if (!A.design && B.design) return -1;
    if (A.design && !B.design) return 1;
    // Same design (or both empty) → sort by carat
    if (A.design === B.design) {
      if (A.num !== null && B.num !== null && A.num !== B.num) return A.num - B.num;
      if (A.num !== null && B.num === null) return -1;
      if (A.num === null && B.num !== null) return 1;
      return A.raw.localeCompare(B.raw);
    }
    // Different designs → alphabetical by design name
    return A.design.localeCompare(B.design);
  });

  const isWarehouseBranch = (b: string) => {
    const lower = b.toLowerCase().trim();
    // DWL is the company's central warehouse — never treated as a retail showroom
    return lower === 'dwl' ||
      lower.startsWith('dwl ') ||
      lower.endsWith(' dwl') ||
      lower.includes('warehouse') ||
      lower.includes('central') ||
      lower.includes('hub') ||
      lower.includes('distribution center') ||
      lower === 'dc' ||
      lower.endsWith(' dc');
  };

  // Matrix cells setup
  const matrixCells: Record<string, Record<string, {
    sold: number;
    stock: number;
    sales3M?: number;
    sales6M?: number;
    sales1Y?: number;
    sales2Y?: number;
    moveIn: number;
    moveOut: number;
    netMove: number;
  }>> = {};

  branches.forEach((b) => {
    matrixCells[b] = {};
    weights.forEach((w) => {
      matrixCells[b][w] = { sold: 0, stock: 0, sales3M: 0, sales6M: 0, sales1Y: 0, sales2Y: 0, moveIn: 0, moveOut: 0, netMove: 0 };
    });
  });

  // Track multi-period and age statistics per record
  const branchPeriodSold: Record<string, { m3: number; m6: number; y1: number; y2: number }> = {};
  const branchAgingMap: Record<string, { fresh: number; aging: number; slow: number; old: number; dormant: number }> = {};
  const branchAvgAging: Record<string, { totalAgeStock: number; totalStock: number }> = {};
  const weightPeriodSold: Record<string, { m3: number; m6: number; y1: number; y2: number; totalAge: number; ageCount: number }> = {};

  branches.forEach(b => {
    branchPeriodSold[b] = { m3: 0, m6: 0, y1: 0, y2: 0 };
    branchAgingMap[b] = { fresh: 0, aging: 0, slow: 0, old: 0, dormant: 0 };
    branchAvgAging[b] = { totalAgeStock: 0, totalStock: 0 };
  });

  weights.forEach(w => {
    weightPeriodSold[w] = { m3: 0, m6: 0, y1: 0, y2: 0, totalAge: 0, ageCount: 0 };
  });

  records.forEach((r) => {
    const ik = itemKeyOf(r);
    if (!matrixCells[r.branch]) matrixCells[r.branch] = {};
    if (!matrixCells[r.branch][ik]) {
      matrixCells[r.branch][ik] = { sold: 0, stock: 0, sales3M: 0, sales6M: 0, sales1Y: 0, sales2Y: 0, moveIn: 0, moveOut: 0, netMove: 0 };
    }

    const sold = Number(r.soldQty) || 0;
    const stock = Number(r.currentStock) || 0;

    // Multi-period sales resolution
    const s3m = r.sales3M !== undefined ? r.sales3M : Math.max(0, Math.round(sold * 0.4));
    const s6m = r.sales6M !== undefined ? r.sales6M : Math.max(0, Math.round(sold * 0.7));
    const s1y = r.sales1Y !== undefined ? r.sales1Y : sold;
    const s2y = r.sales2Y !== undefined ? r.sales2Y : Math.max(0, Math.round(sold * 1.8));

    // Inventory Age in Days
    const ageDays = r.ageDays !== undefined ? r.ageDays : (stock > 0 && sold === 0 ? 310 : 65);

    // Active timeframe sold for the matrix. Prefer explicit period fields. When an
    // upload only contains one aggregate period (commonly stored in sales1Y),
    // prorate that aggregate to the selected window instead of silently treating
    // a 9M/6M upload as a full 1Y value. This keeps every timeframe internally
    // consistent with the uploaded reporting window.
    const inferPeriodMonths = (text: string): number => {
      const m = String(text || '').match(/(?:^|\D)(\d{1,2})\s*(?:month|months|m)(?:\D|$)/i);
      if (m) return Math.max(1, Math.min(24, Number(m[1])));
      const dates = String(text || '').match(/(\d{1,2}[\/-]\d{1,2}[\/-]\d{2,4}).*?(\d{1,2}[\/-]\d{1,2}[\/-]\d{2,4})/);
      if (dates) {
        const parse = (x: string) => {
          const [a,b,c] = x.split(/[\/-]/).map(Number);
          const year = c < 100 ? 2000 + c : c;
          return new Date(year, b - 1, a);
        };
        const a=parse(dates[1]), b=parse(dates[2]);
        const days=Math.abs(b.getTime()-a.getTime())/86400000;
        if (Number.isFinite(days) && days > 0) return Math.max(1, Math.min(24, Math.round(days/30.4375)));
      }
      return 12;
    };
    const uploadMonths = inferPeriodMonths(period);
    const selectedMonths = timeframeMonths(selectedTimeframe);
    const prorateAggregate = (aggregate: number) => {
      if (aggregate <= 0) return 0;
      if (uploadMonths <= 0 || uploadMonths === selectedMonths) return aggregate;
      // Never inflate a shorter uploaded window into a longer observed window.
      if (selectedMonths >= uploadMonths) return aggregate;
      return Math.max(0, Math.round(aggregate * (selectedMonths / uploadMonths)));
    };
    let activeTimeframeSold = s1y;
    if (selectedTimeframe === '1M') activeTimeframeSold = s3m > 0 ? Math.max(0, Math.round(s3m / 3)) : prorateAggregate(s1y || sold);
    else if (selectedTimeframe === '3M') activeTimeframeSold = s3m > 0 ? s3m : prorateAggregate(s1y || sold);
    else if (selectedTimeframe === '6M') activeTimeframeSold = s6m > 0 ? s6m : prorateAggregate(s1y || sold);
    else if (selectedTimeframe === '9M') activeTimeframeSold = uploadMonths === 9 ? Math.max(0, s1y || sold) : prorateAggregate(s1y || sold);
    else if (selectedTimeframe === '2Y') activeTimeframeSold = s2y > 0 ? s2y : (uploadMonths >= 24 ? s1y || sold : Math.max(0, Math.round((s1y || sold) * 24 / Math.max(1, uploadMonths))));
    else activeTimeframeSold = uploadMonths === 12 ? Math.max(0, s1y || sold) : prorateAggregate(s1y || sold);

    matrixCells[r.branch][ik].sold += activeTimeframeSold;
    matrixCells[r.branch][ik].stock += stock;
    matrixCells[r.branch][ik].sales3M = (matrixCells[r.branch][ik].sales3M || 0) + s3m;
    matrixCells[r.branch][ik].sales6M = (matrixCells[r.branch][ik].sales6M || 0) + s6m;
    matrixCells[r.branch][ik].sales1Y = (matrixCells[r.branch][ik].sales1Y || 0) + s1y;
    matrixCells[r.branch][ik].sales2Y = (matrixCells[r.branch][ik].sales2Y || 0) + s2y;

    if (branchPeriodSold[r.branch]) {
      branchPeriodSold[r.branch].m3 += s3m;
      branchPeriodSold[r.branch].m6 += s6m;
      branchPeriodSold[r.branch].y1 += s1y;
      branchPeriodSold[r.branch].y2 += s2y;
    }

    if (branchAgingMap[r.branch] && stock > 0) {
      if (ageDays <= 90) branchAgingMap[r.branch].fresh += stock;
      else if (ageDays <= 180) branchAgingMap[r.branch].aging += stock;
      else if (ageDays <= 365) branchAgingMap[r.branch].slow += stock;
      else if (ageDays <= 730) branchAgingMap[r.branch].old += stock;
      else branchAgingMap[r.branch].dormant += stock;
    }
    if (branchAvgAging[r.branch] && stock > 0) {
      branchAvgAging[r.branch].totalAgeStock += ageDays * stock;
      branchAvgAging[r.branch].totalStock += stock;
    }

    if (weightPeriodSold[ik]) {
      weightPeriodSold[ik].m3 += s3m;
      weightPeriodSold[ik].m6 += s6m;
      weightPeriodSold[ik].y1 += s1y;
      weightPeriodSold[ik].y2 += s2y;
      if (stock > 0) {
        weightPeriodSold[ik].totalAge += ageDays * stock;
        weightPeriodSold[ik].ageCount += stock;
      }
    }
  });

  // Track weight-level company metrics
  const weightMetricsMap: Record<string, {
    sold: number;
    stock: number;
    moveIn: number;
    moveOut: number;
    unmetShortage: number;
  }> = {};

  weights.forEach((w) => {
    weightMetricsMap[w] = { sold: 0, stock: 0, moveIn: 0, moveOut: 0, unmetShortage: 0 };
  });

  branches.forEach((b) => {
    weights.forEach((w) => {
      const cell = matrixCells[b][w];
      weightMetricsMap[w].sold += cell.sold;
      weightMetricsMap[w].stock += cell.stock;
    });
  });

  // Automated Redistribution Matching Engine
  const transferOrders: TransferOrder[] = [];
  const procurementOrders: ProcurementOrder[] = [];

  weights.forEach((w) => {
    // Rebuild every matrix/report mode from the same DWL-inclusive live pool.
    const retail = branches.filter(b => !isWarehouseBranch(b));
    const companyStock = branches.reduce((s, b) => s + Math.max(0, matrixCells[b][w].stock || 0), 0);
    const drafts = retail.map(branch => {
      const ageAcc = branchAvgAging[branch];
      const avgAgingDays =
        ageAcc && ageAcc.totalStock > 0
          ? ageAcc.totalAgeStock / ageAcc.totalStock
          : 0;
      return {
        branch,
        stock: Math.max(0, matrixCells[branch][w].stock || 0),
        sales: Math.max(0, matrixCells[branch][w].sold || 0),
        avgAgingDays,
      };
    });
    const totalSales = drafts.reduce((sum, d) => sum + d.sales, 0);
    const targets = buildAllocationTargets(drafts, companyStock, selectedTimeframe, allocationMode, specialMonths?.length || 0);
    const donors: { branch: string; qty: number; warehouse: boolean }[] = [];
    const receivers: { branch: string; qty: number; sold: number }[] = [];
    branches.forEach(branch => {
      const current = Math.max(0, Math.round(matrixCells[branch][w].stock || 0));
      if (isWarehouseBranch(branch)) { if (current) donors.push({ branch, qty: current, warehouse: true }); return; }
      const d = drafts.find(x => x.branch === branch)!; const net = (targets.targets[d.branch] || 0) - current;
      if (net > 0) receivers.push({ branch, qty: net, sold: d.sales }); else if (net < 0) donors.push({ branch, qty: -net, warehouse: false });
    });
    donors.sort((a, b) => Number(b.warehouse) - Number(a.warehouse) || b.qty - a.qty); receivers.sort((a, b) => b.sold - a.sold || b.qty - a.qty);
    let donorIndex = 0;
    receivers.forEach(receiver => { while (receiver.qty > 0 && donorIndex < donors.length) {
      const donor = donors[donorIndex]; const qty = Math.min(donor.qty, receiver.qty);
      transferOrders.push({ id: `TR-${w.replace(/[^a-zA-Z0-9]/g, '')}-${donor.branch.substring(0, 3)}-${receiver.branch.substring(0, 3)}`, weight: w, fromBranch: donor.branch, toBranch: receiver.branch, qty, priority: receiver.sold > 0 ? 'HIGH' : 'MEDIUM', reason: `${allocationMode} matrix allocation target`, impactScore: receiver.sold, status: 'RECOMMENDED' });
      matrixCells[donor.branch][w].moveOut += qty; matrixCells[donor.branch][w].netMove -= qty; matrixCells[receiver.branch][w].moveIn += qty; matrixCells[receiver.branch][w].netMove += qty; weightMetricsMap[w].moveIn += qty; weightMetricsMap[w].moveOut += qty;
      donor.qty -= qty; receiver.qty -= qty; if (donor.qty === 0) donorIndex++;
    }});
    /*
     * IMPORTANT: allocation shortage and procurement shortage are different things.
     *
     * `receivers` measures Have < Deserve and therefore tells us how much stock
     * should move between outlets. It must NOT be used as a new-buy quantity.
     * A new purchase is required only when the selected-period demand for this
     * item is greater than the total live company stock (after allowing the
     * network to redistribute that stock).
     */
    const selectedPeriodDemand = totalSales;
    const procurementGap = Math.max(0, Math.ceil(selectedPeriodDemand - companyStock));
    weightMetricsMap[w].unmetShortage = procurementGap;

    if (procurementGap > 0) {
      procurementOrders.push({
        weight: w,
        qtyToBuy: procurementGap,
        soldDemand: selectedPeriodDemand,
        availableStock: companyStock,
        urgency: selectedPeriodDemand > 0 && companyStock === 0 ? 'HIGH' : 'MEDIUM',
        rationale: `Have vs Deserve redistribution is complete first. Selected-period demand (${selectedPeriodDemand} ${activeCategory.itemUnit}) exceeds total live company stock (${companyStock} ${activeCategory.itemUnit}) by ${procurementGap} ${activeCategory.itemUnit}; this residual is the true new-buy requirement.`
      });
    }
    return;
  });

  // Compile Branch Summaries
  const branchSummaries: BranchSummary[] = branches.map((b) => {
    let totalSold = 0;
    let totalCurrentStock = 0;
    let totalMoveIn = 0;
    let totalMoveOut = 0;
    let variantsNeedingAction = 0;

    weights.forEach((w) => {
      const cell = matrixCells[b][w];
      totalSold += cell.sold;
      totalCurrentStock += cell.stock;
      totalMoveIn += cell.moveIn;
      totalMoveOut += cell.moveOut;

      if (cell.moveIn > 0 || cell.moveOut > 0) {
        variantsNeedingAction++;
      }
    });

    const isWarehouse = isWarehouseBranch(b);
    const netChange = totalMoveIn - totalMoveOut;
    const sellThroughRate = (totalSold + totalCurrentStock) > 0
      ? (totalSold / (totalSold + totalCurrentStock)) * 100
      : 0;

    const overstockScore = totalSold === 0 && totalCurrentStock > 0
      ? totalCurrentStock * 20
      : Math.max(0, totalCurrentStock - totalSold) * 10;

    const shortageScore = totalCurrentStock === 0 && totalSold > 0
      ? totalSold * 25
      : Math.max(0, totalSold - totalCurrentStock) * 12;

    let status: BranchSummary['status'] = 'BALANCED';
    if (isWarehouse) {
      status = 'WAREHOUSE';
    } else if (totalCurrentStock === 0 && totalSold > 0) {
      status = 'SHORTAGE';
    } else if (totalMoveIn > totalMoveOut && totalMoveIn >= 2) {
      status = 'SHORTAGE';
    } else if (totalSold === 0 && totalCurrentStock > 0) {
      status = 'OVERSTOCKED';
    } else if (totalMoveOut > totalMoveIn && totalMoveOut >= 2) {
      status = 'OVERSTOCKED';
    }

    const bAging = branchAgingMap[b] || { fresh: 0, aging: 0, slow: 0, old: 0, dormant: 0 };
    const bPeriods = branchPeriodSold[b] || { m3: 0, m6: 0, y1: 0, y2: 0 };

    return {
      branch: b,
      totalSold,
      totalSold3M: bPeriods.m3,
      totalSold6M: bPeriods.m6,
      totalSold1Y: bPeriods.y1,
      totalSold2Y: bPeriods.y2,
      totalCurrentStock,
      totalMoveIn,
      totalMoveOut,
      netChange,
      variantsNeedingAction,
      isWarehouse,
      sellThroughRate,
      overstockScore,
      shortageScore,
      status,
      agingBreakdown: {
        freshPcs: bAging.fresh,
        agingPcs: bAging.aging,
        slowPcs: bAging.slow,
        oldPcs: bAging.old,
        dormantPcs: bAging.dormant
      }
    };
  });

  // Compile Weight Summaries
  const weightSummaries: WeightSummary[] = weights.map((w) => {
    const wm = weightMetricsMap[w];
    const weightNum = parseFloat(w) || 0;
    const wPeriods = weightPeriodSold[w] || { m3: 0, m6: 0, y1: 0, y2: 0, totalAge: 0, ageCount: 0 };

    let velocityCategory: WeightSummary['velocityCategory'] = 'Slow-Moving';
    if (wm.sold >= 3) velocityCategory = 'Best-Seller';
    else if (wm.sold >= 1) velocityCategory = 'Steady';
    else if (wm.stock > 0 && wm.sold === 0) velocityCategory = 'Zero-Sales Stock';

    // Sell-through is a bounded rate: sold / (sold + closing stock).
    // Do not use sold / stock (which can exceed 100% and is a different metric).
    const sellThroughDenominator = wm.sold + wm.stock;
    const turnoverRatio = sellThroughDenominator > 0
      ? Math.round((wm.sold / sellThroughDenominator) * 1000) / 10
      : 0;
    const avgAge = wPeriods.ageCount > 0 ? Math.round(wPeriods.totalAge / wPeriods.ageCount) : 60;

    return {
      weight: w,
      weightNum,
      soldQty: wm.sold,
      sold3M: wPeriods.m3,
      sold6M: wPeriods.m6,
      sold1Y: wPeriods.y1,
      sold2Y: wPeriods.y2,
      currentStock: wm.stock,
      moveInNeeded: wm.moveIn,
      moveOutNeeded: wm.moveOut,
      unmetShortage: wm.unmetShortage,
      velocityCategory,
      turnoverRatio,
      averageAgeDays: avgAge
    };
  });

  // Top rankings
  const retailBranches = branchSummaries.filter((b) => !b.isWarehouse);

  // Top 5 Selling Outlets
  const top5SellingBranches = [...retailBranches]
    .sort((a, b) => b.totalSold - a.totalSold)
    .slice(0, 5);

  // Lowest 5 Selling Outlets (Slow performers with idle stock)
  const lowest5SellingBranches = [...retailBranches]
    .sort((a, b) => a.totalSold - b.totalSold || b.totalCurrentStock - a.totalCurrentStock)
    .slice(0, 5);

  const topOverstockedBranches = [...branchSummaries]
    .filter((b) => !b.isWarehouse && b.totalCurrentStock > 0)
    .sort((a, b) => b.overstockScore - a.overstockScore)
    .slice(0, 5);

  const topShortageBranches = [...branchSummaries]
    .filter((b) => !b.isWarehouse)
    .sort((a, b) => b.shortageScore - a.shortageScore)
    .slice(0, 5);

  const top5BestSellingWeights = [...weightSummaries]
    .sort((a, b) => b.soldQty - a.soldQty)
    .slice(0, 5);

  const top5SlowMovingWeights = [...weightSummaries]
    .filter((w) => w.currentStock > 0 && w.soldQty === 0)
    .sort((a, b) => b.currentStock - a.currentStock)
    .slice(0, 5);

  const lowest5SellingWeights = [...weightSummaries]
    .sort((a, b) => a.soldQty - b.soldQty || b.currentStock - a.currentStock)
    .slice(0, 5);

  // Global Totals
  const totalSold = branchSummaries.reduce((sum, b) => sum + b.totalSold, 0);
  const totalSold3M = branchSummaries.reduce((sum, b) => sum + (b.totalSold3M || 0), 0);
  const totalSold6M = branchSummaries.reduce((sum, b) => sum + (b.totalSold6M || 0), 0);
  const totalSold1Y = branchSummaries.reduce((sum, b) => sum + (b.totalSold1Y || 0), 0);
  const totalSold2Y = branchSummaries.reduce((sum, b) => sum + (b.totalSold2Y || 0), 0);
  const totalCurrentStock = branchSummaries.reduce((sum, b) => sum + b.totalCurrentStock, 0);
  const totalMoveIn = branchSummaries.reduce((sum, b) => sum + b.totalMoveIn, 0);
  const totalMoveOut = branchSummaries.reduce((sum, b) => sum + b.totalMoveOut, 0);
  const netStockPosition = totalMoveIn - totalMoveOut;
  const totalNewStockToBuy = procurementOrders.reduce((sum, p) => sum + p.qtyToBuy, 0);
  const variantsNeedingActionCount = transferOrders.length + procurementOrders.length;

  // Build Comprehensive Stock Aging Analysis Buckets
  let totalPiecesFresh = 0;
  let totalPiecesAging = 0;
  let totalPiecesSlow = 0;
  let totalPiecesOld = 0;
  let totalPiecesDormant = 0;

  const trapped0_90: any[] = [];
  const trapped91_180: any[] = [];
  const trapped181_365: any[] = [];
  const trapped1_2y: any[] = [];
  const trapped2y_plus: any[] = [];

  records.forEach((r) => {
    const stock = Number(r.currentStock) || 0;
    if (stock <= 0) return;
    const sold = Number(r.soldQty) || 0;
    const age = r.ageDays !== undefined ? r.ageDays : (sold === 0 ? 310 : 65);

    const itemData = {
      branch: r.branch,
      weight: r.weight,
      qty: stock,
      daysOld: age,
      salesInBranch: sold
    };

    if (age <= 90) {
      totalPiecesFresh += stock;
      trapped0_90.push(itemData);
    } else if (age <= 180) {
      totalPiecesAging += stock;
      trapped91_180.push(itemData);
    } else if (age <= 365) {
      totalPiecesSlow += stock;
      if (sold === 0) trapped181_365.push(itemData);
    } else if (age <= 730) {
      totalPiecesOld += stock;
      if (sold === 0) trapped1_2y.push(itemData);
    } else {
      totalPiecesDormant += stock;
      trapped2y_plus.push(itemData);
    }
  });

  const totalStockForAging = Math.max(1, totalCurrentStock);

  const agingBuckets: StockAgingBucket[] = [
    {
      bucket: "0-90 Days",
      description: "Fresh Inventory (High customer turnover window)",
      totalPieces: totalPiecesFresh,
      percentage: Math.round((totalPiecesFresh / totalStockForAging) * 100),
      status: 'HEALTHY',
      affectedBranchesCount: new Set(trapped0_90.map(t => t.branch)).size,
      trappedItems: trapped0_90.slice(0, 5)
    },
    {
      bucket: "91-180 Days",
      description: "Normal Holding Period (Requires monitoring)",
      totalPieces: totalPiecesAging,
      percentage: Math.round((totalPiecesAging / totalStockForAging) * 100),
      status: 'MODERATE',
      affectedBranchesCount: new Set(trapped91_180.map(t => t.branch)).size,
      trappedItems: trapped91_180.slice(0, 5)
    },
    {
      bucket: "181-365 Days",
      description: "Slow-Moving Inventory (Should rotate between outlets)",
      totalPieces: totalPiecesSlow,
      percentage: Math.round((totalPiecesSlow / totalStockForAging) * 100),
      status: 'ATTENTION',
      affectedBranchesCount: new Set(trapped181_365.map(t => t.branch)).size,
      trappedItems: trapped181_365.slice(0, 6)
    },
    {
      bucket: "1-2 Years",
      description: "Stagnant Stock (Locked capital in idle locations)",
      totalPieces: totalPiecesOld,
      percentage: Math.round((totalPiecesOld / totalStockForAging) * 100),
      status: 'CRITICAL',
      affectedBranchesCount: new Set(trapped1_2y.map(t => t.branch)).size,
      trappedItems: trapped1_2y.slice(0, 6)
    },
    {
      bucket: ">2 Years",
      description: "Dormant / Dead Stock (Urgent transfer or remake needed)",
      totalPieces: totalPiecesDormant,
      percentage: Math.round((totalPiecesDormant / totalStockForAging) * 100),
      status: 'DEAD_STOCK',
      affectedBranchesCount: new Set(trapped2y_plus.map(t => t.branch)).size,
      trappedItems: trapped2y_plus.slice(0, 6)
    }
  ];

  // Consignment & New Shipment Planner (Products that will boost sales)
  const consignmentRecommendations: ConsignmentRecommendation[] = [];

  weightSummaries.forEach((w) => {
    const totalSold1Y = w.sold1Y || w.soldQty;
    const stock = w.currentStock;
    const demandDeficit = Math.max(0, totalSold1Y - stock);
    const isCriticalStockout = stock === 0 && totalSold1Y > 0;
    const isUnderstocked = stock > 0 && totalSold1Y >= stock;

    if (isCriticalStockout || isUnderstocked || (totalSold1Y >= 2 && stock <= 1)) {
      const recommendedQty = isCriticalStockout
        ? Math.max(2, Math.round(totalSold1Y * 2))
        : Math.max(2, Math.round(totalSold1Y * 1.5) - stock);
      const estimatedUnitPrice = activeCategory.estimatedAvgUnitPrice || 45000;
      const projectedSalesUplift = recommendedQty * estimatedUnitPrice * 0.85;

      consignmentRecommendations.push({
        weight: w.weight,
        category: activeCategory.itemTypeNoun,
        currentNetworkStock: stock,
        recentSalesDemand: totalSold1Y,
        demandVelocity: totalSold1Y >= 5 ? 'VERY_HIGH' : (totalSold1Y >= 2 ? 'HIGH' : 'MODERATE'),
        stockoutRisk: stock === 0 ? 'CRITICAL' : (stock <= 1 ? 'HIGH' : 'MODERATE'),
        recommendedConsignmentPcs: Math.max(1, recommendedQty),
        estimatedSalesUpliftBdt: Math.round(projectedSalesUplift),
        marketReason: stock === 0
          ? `High market customer demand (${totalSold1Y} pcs sold out). Complete network stockout (0 pcs available). New procurement order required immediately to capture sales.`
          : `Proven customer demand (${totalSold1Y} pcs sold). Network stock (${stock} pcs) is depleted. Reordering ${recommendedQty} pcs will boost overall revenue.`
      });
    }
  });

  consignmentRecommendations.sort((a, b) => {
    if (a.stockoutRisk === 'CRITICAL' && b.stockoutRisk !== 'CRITICAL') return -1;
    if (b.stockoutRisk === 'CRITICAL' && a.stockoutRisk !== 'CRITICAL') return 1;
    return b.recentSalesDemand - a.recentSalesDemand;
  });

  // Actionable Alerts
  const actionAlerts: ActionAlert[] = [];

  if (topShortageBranches.length > 0 && topShortageBranches[0].totalCurrentStock === 0) {
    actionAlerts.push({
      id: "alert-shortage-1",
      type: "CRITICAL_SHORTAGE",
      title: `Critical Stockout at ${topShortageBranches[0].branch}`,
      description: `${topShortageBranches[0].branch} generated ${topShortageBranches[0].totalSold} units of demand for ${activeCategory.name} but has ZERO available units on shelves.`,
      branch: topShortageBranches[0].branch,
      actionText: `Execute Move IN of ${topShortageBranches[0].totalMoveIn || 1} ${activeCategory.itemUnit} immediately to prevent sales walkout.`,
      priority: "URGENT"
    });
  }

  if (topOverstockedBranches.length > 0 && topOverstockedBranches[0].totalSold === 0) {
    actionAlerts.push({
      id: "alert-overstock-1",
      type: "OVERSTOCK_WARNING",
      title: `Idle Capital Lockup at ${topOverstockedBranches[0].branch}`,
      description: `${topOverstockedBranches[0].branch} holds ${topOverstockedBranches[0].totalCurrentStock} ${activeCategory.itemUnit} inventory with 0 period sales, creating holding cost and capital lockup.`,
      branch: topOverstockedBranches[0].branch,
      actionText: `Authorize Move OUT transfer order to reallocate inventory to high-velocity locations.`,
      priority: "WARNING"
    });
  }

  if (consignmentRecommendations.length > 0) {
    const topRec = consignmentRecommendations[0];
    actionAlerts.push({
      id: "alert-consignment-1",
      type: "PROCUREMENT_REQUIRED",
      title: `Consignment Requisition: Import ${topRec.weight} ct (${topRec.recommendedConsignmentPcs} pcs)`,
      description: `High sales demand (${topRec.recentSalesDemand} sold) vs only ${topRec.currentNetworkStock} in network stock. Ordering new consignment will boost revenue by $${topRec.estimatedSalesUpliftBdt.toLocaleString()}.`,
      actionText: `Include in upcoming factory import order.`,
      priority: "URGENT"
    });
  }

  transferOrders.forEach((to, idx) => {
    if (idx < 2) {
      actionAlerts.push({
        id: `alert-transfer-${to.id}`,
        type: "TRANSFER_OPPORTUNITY",
        title: `Dispatch Transfer: ${to.weight} (${to.fromBranch} → ${to.toBranch})`,
        description: `Transfer ${to.qty} ${activeCategory.itemUnit} of ${to.weight} from overstocked branch (${to.fromBranch}) to stockout branch (${to.toBranch}).`,
        branch: to.toBranch,
        weight: to.weight,
        actionText: "Ready to print dispatch slip",
        priority: to.priority === 'CRITICAL' ? 'URGENT' : 'WARNING'
      });
    }
  });

  return {
    period,
    selectedTimeframe,
    specialMonths: specialMonths && specialMonths.length > 0 ? specialMonths : undefined,
    categoryConfig: activeCategory,
    totalSold,
    totalSold3M,
    totalSold6M,
    totalSold1Y,
    totalSold2Y,
    totalCurrentStock,
    totalMoveIn,
    totalMoveOut,
    netStockPosition,
    totalNewStockToBuy,
    variantsNeedingActionCount,
    branchSummaries,
    weightSummaries,
    top5SellingBranches,
    lowest5SellingBranches,
    topOverstockedBranches,
    topShortageBranches,
    top5BestSellingWeights,
    top5SlowMovingWeights,
    lowest5SellingWeights,
    transferOrders,
    procurementOrders,
    actionAlerts,
    agingBuckets,
    consignmentRecommendations,
    matrix: {
      branches,
      weights,
      cells: matrixCells
    }
  };
}

/**
 * Multi-mode "Have vs Deserve" allocation engine.
 *
 * DWL (and central/warehouse/hub) = company warehouse stock — NOT a retail outlet.
 * TOTAL_COMPANY_STOCK includes every branch + DWL for the selected item.
 *
 * Three switchable modes (top-bar buttons drive the whole app):
 *
 * 1. contribution — pure sales share:
 *      Deserve = TOTAL_COMPANY_STOCK × (branchSales / totalRetailSales)
 *
 * 2. baseline — Demand-Backup & Safety (Excel 3-month model):
 *      AVERAGE_SALES = sold / periodMonths
 *      Base3M = AVERAGE_SALES × 3
 *      HighPerformerBonus = Base3M × 20% (if branch avg > company avg)
 *      StockOutSafety = max(1, ceil(AvgMonthly)) when current stock = 0
 *      Ideal Demand = Base3M + HighPerformerBonus + StockOutSafety
 *      SCALE = TOTAL_COMPANY_STOCK / Σ Ideal Demand
 *
 * Capital Liquidity (Aging) — applied to ALL modes after mode target is set:
 *      liquidityWeight = sales_contribution / max(avg_shelf_aging_days, 1)
 *      if aging > 90 days → target × (90 / aging)
 *

 * 3. hybrid — max(contribution, 3-month baseline + eligible bonus), then fair-compress to live stock
 *
 * Net_Move = Final_Demand − CURRENT_STOCK → "+N" / "-N" / "0"
 */
export function getOptionAllocationSummary(
  report: RedistributionReport,
  itemKey: string,
  timeframe: SalesTimeframe = '3M',
  growthMultiplier: number = 1.0,
  allocationMode: AllocationMode = 'contribution'
): OptionAllocationSummary {
  const branches = [...report.matrix.branches];
  const isWarehouseBranch = (branch: string) => {
    const lower = branch.toLowerCase().trim();
    return lower === 'dwl' ||
      lower.startsWith('dwl ') ||
      lower.endsWith(' dwl') ||
      lower.includes('warehouse') ||
      lower.includes('central') ||
      lower.includes('hub') ||
      lower.includes('distribution center') ||
      lower === 'dc' ||
      lower.endsWith(' dc');
  };

  const warehouseBranches = branches.filter(isWarehouseBranch);
  const retailBranches = branches.filter(b => !isWarehouseBranch(b));
  const cellFor = (branch: string) => report.matrix.cells[branch]?.[itemKey] || {
    sold: 0,
    stock: 0,
    sales3M: 0,
    sales6M: 0,
    sales1Y: 0,
    sales2Y: 0,
    moveIn: 0,
    moveOut: 0,
    netMove: 0
  };

  const periodMonths =
    timeframe === '1M' ? 1 :
    timeframe === '3M' ? 3 :
    timeframe === '6M' ? 6 :
    timeframe === '9M' ? 9 :
    timeframe === '2Y' ? 24 : 12;

  // Festival / Exhibition / Promotion months must not inflate normal average.
  // Assume special months sell ~1.8× normal month → normalize baseline run-rate.
  const specialCount = Math.min(
    periodMonths - 1,
    Math.max(0, (report.specialMonths && report.specialMonths.length) || 0)
  );
  const FESTIVAL_LIFT_FACTOR = 1.8;
  const effectiveDivisor =
    specialCount > 0
      ? periodMonths + (FESTIVAL_LIFT_FACTOR - 1) * specialCount
      : periodMonths;

  // TOTAL stock for this particular item across ALL outlets + DWL warehouse
  const totalCompanyStock = branches.reduce(
    (sum, branch) => sum + (Number(cellFor(branch).stock) || 0),
    0
  );
  const warehouseStock = warehouseBranches.reduce(
    (sum, branch) => sum + Math.max(0, Number(cellFor(branch).stock) || 0),
    0
  );

  const effectiveGrowth = Math.max(1, Number(growthMultiplier) || 1);

  const soldForTimeframe = (c: {
    sold: number; stock: number;
    sales3M?: number; sales6M?: number; sales1Y?: number; sales2Y?: number;
  }): number => {
    if (timeframe === '1M') return Math.max(0, Math.round((Number(c.sales3M) || 0) / 3));
    if (timeframe === '3M') return Math.max(0, Number(c.sales3M) || 0);
    if (timeframe === '6M') return Math.max(0, Number(c.sales6M) || 0);
    if (timeframe === '9M') {
      return Math.max(0, Number(c.sales1Y) || Number(c.sold) || Math.round((Number(c.sales3M) || 0) * 3));
    }
    if (timeframe === '2Y') return Math.max(0, Number(c.sales2Y) || 0);
    return Math.max(0, Number(c.sales1Y) || Number(c.sold) || 0);
  };

  type BranchDraft = {
    branch: string;
    currentStock: number;
    soldQty: number;
    salesPeriod: number;
    sales3M: number;
    sales6M: number;
    sales1Y: number;
    sales2Y: number;
    salesAvgMonthly: number;
    baselineDemand: number;
    isWarehouse: boolean;
  };

  const drafts: BranchDraft[] = branches.map(branch => {
    const c = cellFor(branch);
    const sold3M = Math.max(0, Number(c.sales3M) || 0);
    const sold6M = Math.max(0, Number(c.sales6M) || 0);
    const sold1Y = Math.max(0, Number(c.sales1Y) || 0);
    const sold2Y = Math.max(0, Number(c.sales2Y) || 0);
    const salesPeriod = soldForTimeframe(c);
    const currentStock = Math.max(0, Number(c.stock) || 0);
    // Normalized monthly average: festival months do not inflate baseline
    const salesAvgMonthly = effectiveDivisor > 0 ? salesPeriod / effectiveDivisor : 0;
    // Safety baseline always represents three months of normalized average sales.
    const baselineDemand = Math.max(0, salesAvgMonthly * 3);

    return {
      branch,
      currentStock,
      soldQty: salesPeriod,
      salesPeriod,
      sales3M: sold3M,
      sales6M: sold6M,
      sales1Y: sold1Y,
      sales2Y: sold2Y,
      salesAvgMonthly,
      baselineDemand,
      isWarehouse: isWarehouseBranch(branch)
    };
  });

  const retailDrafts = drafts.filter(d => !d.isWarehouse);
  const totalRetailSales = retailDrafts.reduce((s, d) => s + d.salesPeriod, 0);
  /** Approximate average shelf age (days) from branch aging buckets when available. */
  const branchAgeEstimate = (branch: string): number => {
    const summary = (report.branchSummaries || []).find((b) => b.branch === branch);
    const a = summary?.agingBreakdown;
    if (!a) return 0;
    const total =
      (a.freshPcs || 0) +
      (a.agingPcs || 0) +
      (a.slowPcs || 0) +
      (a.oldPcs || 0) +
      (a.dormantPcs || 0);
    if (total <= 0) return 0;
    const weighted =
      (a.freshPcs || 0) * 45 +
      (a.agingPcs || 0) * 135 +
      (a.slowPcs || 0) * 270 +
      (a.oldPcs || 0) * 540 +
      (a.dormantPcs || 0) * 900;
    return weighted / total;
  };
  const targetPlan = buildAllocationTargets(
    retailDrafts.map(d => ({
      branch: d.branch,
      stock: d.currentStock,
      sales: d.salesPeriod,
      avgAgingDays: branchAgeEstimate(d.branch),
    })),
    totalCompanyStock,
    timeframe,
    allocationMode,
    specialCount,
    effectiveGrowth
  );
  const scaleFactor = targetPlan.scaleFactor;
  const finalDemandMap = targetPlan.rawTargets;
  const totalRetailTarget = targetPlan.totalTarget;
  const scaledCompressionFactor = targetPlan.compression;
  const roundedTargets = targetPlan.targets;
  const meanMonthlySales = retailDrafts.length
    ? retailDrafts.reduce((sum, d) => sum + d.salesAvgMonthly, 0) / retailDrafts.length
    : 0;
  const highPerformer = new Set(retailDrafts.filter(d => d.salesAvgMonthly > meanMonthlySales).map(d => d.branch));

  const totalAssigned = Object.values(roundedTargets).reduce((s, n) => s + n, 0);
  // Remaining after retail assignment stays as DWL / enterprise protected reserve
  const protectedReserve = Math.max(0, Math.floor(totalCompanyStock - totalAssigned));
  const distributableWarehouseStock = Math.max(0, warehouseStock - Math.min(warehouseStock, protectedReserve));

  const totalEnterpriseSales3M = retailDrafts.reduce((sum, d) => sum + d.sales3M, 0);
  const modeLabel =
    allocationMode === 'contribution' ? 'Full Pool by Sales Share' :
    allocationMode === 'baseline' ? '3-Month Baseline + Scale' :
    allocationMode === 'liquidity' ? 'Capital Liquidity (Sales ÷ Aging)' :
    allocationMode === 'demand_backup' ? 'Demand-Backup & Safety (3M + 20% + Stock-Out)' :
    allocationMode === 'coverage' ? 'Universal Coverage (≥1 pc every outlet)' :
    'Hybrid (Contribution ∪ Baseline)';

  const rows: OptionAllocationRow[] = drafts.map(d => {
    if (d.isWarehouse) {
      return {
        branch: d.branch,
        currentStock: d.currentStock,
        soldQty: d.soldQty,
        salesPeriod: d.salesPeriod,
        sales3M: d.sales3M,
        sales6M: d.sales6M,
        sales1Y: d.sales1Y,
        sales2Y: d.sales2Y,
        salesAvgMonthly: Math.round(d.salesAvgMonthly * 100) / 100,
        salesContributionPct: 0,
        contributionDeserveQty: 0,
        safetyFloorQty: 0,
        deservedStock: 0,
        variance: d.currentStock,
        action: 'WITHDRAW' as const,
        actionQty: Math.max(0, d.currentStock - protectedReserve),
        status: 'WAREHOUSE' as const,
        statusFlag: '🏢' as const,
        scaledFactor: Math.round(scaleFactor * 1000) / 1000,
        rationale: `DWL / Warehouse. Total item pool ${totalCompanyStock} pcs includes this ${d.currentStock} pcs. Distributes to showrooms by ${modeLabel}. Protected reserve ${protectedReserve} pcs.`,
        capQty: undefined,
        growthTargetStock: 0,
        opportunityStock: 0
      };
    }

    const deservedStock = Math.max(0, roundedTargets[d.branch] || 0);
    const netMove = Math.round(deservedStock - d.currentStock);
    const variance = d.currentStock - deservedStock;
    const action: OptionAllocationRow['action'] =
      netMove > 0 ? 'SEND' : netMove < 0 ? 'WITHDRAW' : 'BALANCED';
    const status: OptionAllocationRow['status'] =
      netMove > 0 ? 'LESS_STOCK' : netMove < 0 ? 'OVERSTOCK' : 'BALANCED';
    const statusFlag: OptionAllocationRow['statusFlag'] =
      netMove > 0 ? '📉' : netMove < 0 ? '⚠️' : '✓';

    const salesShare = totalRetailSales > 0 ? d.salesPeriod / totalRetailSales : 0;
    const contributionDeserve = safeAllocUnits(safeDiv(totalCompanyStock * salesShare, 1, 0));
    const baselineRounded = Math.round(d.baselineDemand);

    return {
      branch: d.branch,
      currentStock: d.currentStock,
      soldQty: d.soldQty,
      salesPeriod: d.salesPeriod,
      sales3M: d.sales3M,
      sales6M: d.sales6M,
      sales1Y: d.sales1Y,
      sales2Y: d.sales2Y,
      salesAvgMonthly: Math.round(d.salesAvgMonthly * 100) / 100,
      salesContributionPct: Math.round(salesShare * 1000) / 10,
      contributionDeserveQty: contributionDeserve,
      safetyFloorQty: baselineRounded,
      capQty: allocationMode !== 'contribution' && highPerformer.has(d.branch)
        ? Math.round(d.baselineDemand * 1.2 * effectiveGrowth) : undefined,
      deservedStock,
      variance,
      action,
      actionQty: Math.abs(netMove),
      status,
      statusFlag,
      scaledFactor: Math.round((allocationMode === 'contribution' ? 1 : scaleFactor) * 1000) / 1000,
      rationale:
        allocationMode === 'contribution'
          ? `Sales share ${(salesShare * 100).toFixed(1)}% of total ${totalCompanyStock} pcs (incl. DWL) → deserve ${deservedStock} pcs.`
          : allocationMode === 'baseline'
            ? `Avg ${d.salesAvgMonthly.toFixed(1)}/mo × 3 = baseline ${baselineRounded}${highPerformer.has(d.branch) ? ` + 20% high-performer bonus` : ''}. Scale ${scaleFactor.toFixed(2)}× → final ${deservedStock} pcs.`
            : `Hybrid: contribution ${contributionDeserve} vs baseline ${baselineRounded} → final ${deservedStock} pcs of ${totalCompanyStock} pool.`,
      growthTargetStock: highPerformer.has(d.branch)
        ? Math.round(d.baselineDemand * 1.2 * effectiveGrowth)
        : Math.round(d.baselineDemand),
      opportunityStock: Math.max(0, deservedStock - d.currentStock)
    };
  });

  // Transfer pairs: overstock / DWL → understock
  const donors = rows
    .filter(r => r.action === 'WITHDRAW')
    .map(r => ({ branch: r.branch, qty: r.actionQty, isWh: r.status === 'WAREHOUSE' }))
    .sort((a, b) => {
      // Prefer DWL warehouse as first donor
      if (a.isWh && !b.isWh) return -1;
      if (!a.isWh && b.isWh) return 1;
      return b.qty - a.qty;
    });
  const receivers = rows
    .filter(r => r.action === 'SEND')
    .map(r => ({ branch: r.branch, qty: r.actionQty, sales: r.salesPeriod }))
    .sort((a, b) => b.sales - a.sales || b.qty - a.qty);

  const transferPairs: OptionAllocationSummary['transferPairs'] = [];
  let di = 0;
  let ri = 0;
  while (di < donors.length && ri < receivers.length) {
    const donor = donors[di];
    const receiver = receivers[ri];
    const qty = Math.min(donor.qty, receiver.qty);
    if (qty > 0) {
      transferPairs.push({
        fromBranch: donor.branch,
        toBranch: receiver.branch,
        qty,
        reason: donor.isWh
          ? `DWL warehouse releases ${qty} pcs to ${receiver.branch} (deserve gap).`
          : `${donor.branch} surplus ${qty} pcs → ${receiver.branch} Move IN.`
      });
      donor.qty -= qty;
      receiver.qty -= qty;
    }
    if (donor.qty <= 0) di++;
    if (receiver.qty <= 0) ri++;
  }

  const totalExcessToWithdraw = rows
    .filter(r => r.status === 'OVERSTOCK')
    .reduce((sum, r) => sum + r.actionQty, 0);
  const totalShortageToSend = rows
    .filter(r => r.status === 'LESS_STOCK')
    .reduce((sum, r) => sum + r.actionQty, 0);

  return {
    weight: itemKey,
    totalCompanyStock,
    totalSoldPeriod: retailDrafts.reduce((sum, d) => sum + d.salesPeriod, 0),
    totalEnterpriseSales3M,
    totalRetailTargetBeforeCompression: Math.round(totalRetailTarget * 10) / 10,
    scaledCompressionFactor: Math.round(scaledCompressionFactor * 1000) / 1000,
    protectedReserve,
    distributableWarehouseStock,
    timeframe,
    allocationMode,
    growthMultiplier: effectiveGrowth,
    availableCompanyBuffer: protectedReserve,
    warehouseStock,
    rows: rows.sort(
      (a, b) => Math.abs(b.variance) - Math.abs(a.variance) || b.salesPeriod - a.salesPeriod
    ),
    totalExcessToWithdraw,
    totalShortageToSend,
    lowVelocityFloor: 0,
    highVelocityThreshold: 0,
    highVelocitySafetyMultiplier: 1.2,
    lowVelocityCapStock: 0,
    transferPairs
  };
}

/**
 * Parses raw CSV or TSV text uploaded by the user into RawInventoryRecord[]
 */
export function parseRawInventoryCSV(csvText: string): RawInventoryRecord[] {
  const lines = csvText.trim().split(/\r?\n/);
  if (lines.length <= 1) return [];

  const headers = lines[0].split(/[,\t]/).map((h) => h.trim().toLowerCase().replace(/[\s_]/g, ''));
  
  let branchIdx = headers.findIndex((h) => h.includes('branch'));
  let weightIdx = headers.findIndex((h) => h.includes('weight') || h.includes('particular') || h.includes('carat') || h.includes('size'));
  let soldIdx = headers.findIndex((h) => h.includes('sold') || h.includes('sales') || h.includes('soldqty'));
  let stockIdx = headers.findIndex((h) => h.includes('stock') || h.includes('currentstock') || h.includes('qty'));

  if (branchIdx === -1) branchIdx = 0;
  if (weightIdx === -1) weightIdx = 1;
  if (soldIdx === -1) soldIdx = 2;
  if (stockIdx === -1) stockIdx = 3;

  const records: RawInventoryRecord[] = [];

  for (let i = 1; i < lines.length; i++) {
    const row = lines[i].split(/[,\t]/).map((v) => v.trim().replace(/^["']|["']$/g, ''));
    if (row.length < 2) continue;

    const branch = row[branchIdx] || "Main Branch";
    let weight = row[weightIdx] || "0.25";
    if (!isNaN(parseFloat(weight))) {
      weight = parseFloat(weight).toFixed(2);
    }
    const soldQty = parseInt(row[soldIdx], 10) || 0;
    const currentStock = parseInt(row[stockIdx], 10) || 0;

    records.push({
      id: `raw-${i}-${Date.now()}`,
      branch,
      weight,
      soldQty,
      currentStock,
      sales3M: Math.max(0, Math.round(soldQty * 0.4)),
      sales6M: Math.max(0, Math.round(soldQty * 0.7)),
      sales1Y: soldQty,
      sales2Y: Math.max(0, Math.round(soldQty * 1.8)),
      ageDays: currentStock > 0 && soldQty === 0 ? 320 : 65
    });
  }

  return records;
}
