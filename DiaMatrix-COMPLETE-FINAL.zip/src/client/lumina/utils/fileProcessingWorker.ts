/**
 * Background worker for dual stock/sold merges.
 * Processes large multi-month uploads in row batches so the main thread stays responsive.
 */
import {
  mergeDualStockAndSoldData,
  mergeMultiFileStockAndSoldData,
  type UploadFileBlob,
  type ParsedDataResult,
} from './universalParser';

export const ROW_BATCH_SIZE = 5000;

export interface WorkerMergeRequest {
  id: number;
  stockFiles: UploadFileBlob[];
  soldFiles: UploadFileBlob[];
  batchSize?: number;
}

export interface WorkerProgressMessage {
  id: number;
  type: 'progress';
  phase: 'parse' | 'merge' | 'finalize';
  processed: number;
  total: number;
}

export interface WorkerResultMessage {
  id: number;
  ok: boolean;
  result?: ParsedDataResult;
  error?: string;
}

/** Yield between batches so the worker event loop can post progress. */
function yieldBatch(): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, 0));
}

/**
 * Split a large record list into fixed-size chunks (default 5,000 rows).
 */
export function chunkRecords<T>(items: T[], size = ROW_BATCH_SIZE): T[][] {
  if (!items.length) return [];
  const safe = Math.max(500, Math.min(size || ROW_BATCH_SIZE, 20_000));
  const out: T[][] = [];
  for (let i = 0; i < items.length; i += safe) {
    out.push(items.slice(i, i + safe));
  }
  return out;
}

self.onmessage = async (event: MessageEvent<WorkerMergeRequest>) => {
  const { id, stockFiles, soldFiles, batchSize } = event.data || ({} as WorkerMergeRequest);
  try {
    const progress = (phase: WorkerProgressMessage['phase'], processed: number, total: number) => {
      const msg: WorkerProgressMessage = { id, type: 'progress', phase, processed, total };
      self.postMessage(msg);
    };

    progress('parse', 0, Math.max(1, (stockFiles?.length || 0) + (soldFiles?.length || 0)));

    const result: ParsedDataResult =
      (stockFiles?.length || 0) === 1 && (soldFiles?.length || 0) === 1
        ? mergeDualStockAndSoldData(
            stockFiles[0].content,
            soldFiles[0].content,
            stockFiles[0].name,
            soldFiles[0].name,
          )
        : mergeMultiFileStockAndSoldData(stockFiles || [], soldFiles || []);

    const total = result.records?.length || 0;
    progress('merge', 0, Math.max(1, total));

    // Re-chunk large result sets so transfer stays memory-safe and progress is visible
    if (total > (batchSize || ROW_BATCH_SIZE)) {
      const chunks = chunkRecords(result.records, batchSize || ROW_BATCH_SIZE);
      const assembled = [];
      let processed = 0;
      for (const chunk of chunks) {
        assembled.push(...chunk);
        processed += chunk.length;
        progress('merge', processed, total);
        await yieldBatch();
      }
      result.records = assembled;
    }

    progress('finalize', total, Math.max(1, total));
    const msg: WorkerResultMessage = { id, ok: true, result };
    self.postMessage(msg);
  } catch (error) {
    const msg: WorkerResultMessage = {
      id,
      ok: false,
      error: error instanceof Error ? error.message : String(error),
    };
    self.postMessage(msg);
  }
};

export {};
