/**
 * Intelligent Data Identity Engine
 * --------------------------------
 * Learns and remembers branch names, carat/cents, product shortcuts from every upload.
 * Even unorganized files (mixed headers, short codes, price ranges, outlet-wise layouts)
 * are normalized to stable unique identities so reports stay consistent.
 */

import { RawInventoryRecord } from '../types';

const STORAGE_KEY = 'dwl_data_identity_v1';

export interface BranchIdentity {
  canonical: string;       // e.g. "GUL"
  aliases: string[];       // e.g. ["Gulshan", "gulshan-01", "GULSHAN"]
  lastSeen: number;
  hitCount: number;
}

export interface WeightIdentity {
  canonical: string;       // e.g. "0.24" (always 2-decimal when numeric)
  aliases: string[];       // e.g. ["0.24ct", "24 cent", ".24", "24c"]
  numericValue: number | null;
  lastSeen: number;
  hitCount: number;
}

export interface ProductIdentity {
  canonical: string;       // preferred display name
  aliases: string[];       // shortcuts user typed
  lastSeen: number;
  hitCount: number;
}

export interface DataIdentityStore {
  branches: Record<string, BranchIdentity>;
  weights: Record<string, WeightIdentity>;
  products: Record<string, ProductIdentity>;
  updatedAt: number;
}

/** Seed known Diamond World outlet codes + common full names */
const BRANCH_SEED: Record<string, string[]> = {
  DWL: ['dwl', 'diamond wold ltd', 'diamond world ltd', 'diamond world', 'reserved', 'warehouse', 'central warehouse', 'reserved or warehouse'],
  BCT: ['bct', 'bashundhara', 'bashundhara city'],
  BLY: ['bly', 'baily road', 'baily-road', 'bailey road'],
  BLYS: ['blys', 'baily road store', 'baily-road store'],
  BMK: ['bmk', 'baitul mukarram'],
  BOG: ['bog', 'bogura', 'bogra'],
  BSL: ['bsl', 'barishal showroom', 'barisal showroom'],
  CHU: ['chu', 'chuadanga'],
  CTG: ['ctg', 'chittagong #01', 'chittagong - #01', 'chattogram #01', 'chittagong'],
  KBH: ['kbh', 'chittagong #02', 'chittagong - #02', 'chattogram #02', 'chitagong #02'],
  CUM: ['cum', 'cumilla', 'comilla'],
  DMD: ['dmd', 'dhanmondi'],
  DNM: ['dnm', 'dhaka new market', 'new market'],
  DNMS: ['dnms', 'dhaka new market store'],
  GAZ: ['gaz', 'gazipur'],
  GUL: ['gul', 'gulshan', 'gulshan-1', 'gulshan 1', 'gulshan-01'],
  JAS: ['jas', 'jashore', 'jessore'],
  KHU: ['khu', 'khulna'],
  MIR: ['mir', 'mirpur'],
  MOH: ['moh', 'mohammadpur'],
  MYM: ['mym', 'mymensingh'],
  NAK: ['nak', 'noakhali showroom', 'noakhali'],
  NAR: ['nar', 'narayanganj showroom', 'narayanganj'],
  NOR: ['nor', 'narshingdhi showroom', 'narshingdhi', 'narshingdi'],
  ONLS: ['onls', 'online', 'e-commerce', 'ecommerce', 'e commerce', 'web'],
  PCT: ['pct', 'pink city showroom', 'pink city'],
  RAJ: ['raj', 'rajshahi'],
  RAN: ['ran', 'rangpur showroom'],
  RANS: ['rans', 'rangpur showroom store'],
  RUP: ['rup', 'rupayan shop square showroom'],
  SAV: ['sav', 'rupayan shop square showroom store'],
  SYL: ['syl', 'sylhet'],
  UTT: ['utt', 'uttara'],
};

/** Official codes only (branch master image). */
export const OFFICIAL_BRANCH_CODES = Object.keys(BRANCH_SEED);

/**
 * Explicit sub-store → parent for "Same" outlets that are NOT pure trailing-S.
 * Trailing-S (BLYS→BLY, DNMS→DNM, RANS→RAN) also listed for clarity.
 * SAV → RUP is the special pair from the official branch list.
 */
const SUBSTORE_TO_PARENT: Record<string, string> = {
  BLYS: 'BLY',
  DNMS: 'DNM',
  RANS: 'RAN',
  SAV: 'RUP',
};

/** Parent → sub-store codes (filter can break down by sub-store). */
const PARENT_TO_SUBSTORES: Record<string, string[]> = {
  BLY: ['BLYS'],
  DNM: ['DNMS'],
  RAN: ['RANS'],
  RUP: ['SAV'],
};

function emptyStore(): DataIdentityStore {
  return { branches: {}, weights: {}, products: {}, updatedAt: Date.now() };
}

function loadStore(): DataIdentityStore {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return seedStore(emptyStore());
    const parsed = JSON.parse(raw) as DataIdentityStore;
    if (!parsed.branches) return seedStore(emptyStore());
    return seedStore(parsed);
  } catch {
    return seedStore(emptyStore());
  }
}

function saveStore(store: DataIdentityStore) {
  try {
    store.updatedAt = Date.now();
    localStorage.setItem(STORAGE_KEY, JSON.stringify(store));
  } catch (err) {
    console.warn('dataIdentityEngine: localStorage save failed', err);
  }
}

function seedStore(store: DataIdentityStore): DataIdentityStore {
  Object.entries(BRANCH_SEED).forEach(([canonical, aliases]) => {
    const key = canonical.toUpperCase();
    if (!store.branches[key]) {
      store.branches[key] = {
        canonical: key,
        aliases: aliases.map((a) => a.toLowerCase()),
        lastSeen: 0,
        hitCount: 0
      };
    } else {
      const existing = new Set(store.branches[key].aliases.map((a) => a.toLowerCase()));
      aliases.forEach((a) => existing.add(a.toLowerCase()));
      store.branches[key].aliases = Array.from(existing);
    }
  });
  return store;
}

function normKey(s: string): string {
  return String(s || '')
    .toLowerCase()
    .replace(/[#._\-/\\|,;:()[\]{}'"]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

// ─── Carat / Cents / Weight intelligence ───────────────────────────────────

/**
 * Understand many carat/cents forms:
 *  0.24 | .24 | 0.24ct | 0.24 carat | 24 cent | 24c | 24 cents | 24ct
 *  Also passes through non-numeric product names unchanged (after shortcut resolve).
 */
/**
 * Map Oracle range codes to a sort/filter numeric value when possible.
 * K30 → 0.30, K90 → 0.90, L01 → 1.01, L10 → 1.10
 * Returns null if not a recognized range code.
 */
export function rangeCodeToNumber(code: string): number | null {
  const s = String(code || '').trim().toUpperCase();
  const m = s.match(/^([A-Z])(\d{2,3})$/);
  if (!m) return null;
  const letter = m[1];
  const digits = m[2];
  const n = parseInt(digits, 10);
  if (isNaN(n)) return null;
  // K-series ≈ 0.xx (K30=0.30), L-series ≈ 1.xx (L01=1.01, L10=1.10)
  if (letter === 'K') return n / 100;
  if (letter === 'L') return 1 + n / 100;
  // Other letter series: keep as letter-order + fraction for sorting
  const base = letter.charCodeAt(0) - 64; // A=1 …
  return base + n / 1000;
}

export function intelligentNormalizeWeight(raw: string, store?: DataIdentityStore): string {
  const s = String(raw || '').trim();
  if (!s) return 'Item-1';

  const st = store || loadStore();

  // Known product / weight alias?
  const nk = normKey(s);
  for (const id of Object.values(st.weights)) {
    if (normKey(id.canonical) === nk || id.aliases.some((a) => normKey(a) === nk)) {
      id.hitCount += 1;
      id.lastSeen = Date.now();
      return id.canonical;
    }
  }
  for (const id of Object.values(st.products)) {
    if (normKey(id.canonical) === nk || id.aliases.some((a) => normKey(a) === nk)) {
      id.hitCount += 1;
      id.lastSeen = Date.now();
      return id.canonical;
    }
  }

  // Oracle range codes (K30, L01…) — keep uppercase code as canonical key
  if (/^[A-Za-z]\d{2,3}$/.test(s)) {
    return s.toUpperCase();
  }

  // "24 cent" / "24 cents" / "24c" → 0.24
  const centMatch = s.match(/^(\d+)\s*(c|cent|cents)\b/i);
  if (centMatch) {
    const cents = parseInt(centMatch[1], 10);
    if (!isNaN(cents)) return (cents / 100).toFixed(2);
  }

  // Strip unit words
  const cleaned = s
    .replace(/\b(ct|cts|carat|carats|gm|g|pcs|pc|piece|pieces|unit|units)\b/gi, '')
    .replace(/,/g, '')
    .trim();

  // Pure number
  if (/^[-+]?[0-9]*\.?[0-9]+$/.test(cleaned)) {
    const num = parseFloat(cleaned);
    if (!isNaN(num)) {
      if (
        Number.isInteger(num) &&
        num >= 1 &&
        num <= 99 &&
        /cent|\bc\b/i.test(s)
      ) {
        return (num / 100).toFixed(2);
      }
      return num.toFixed(2);
    }
  }

  // ".24" style
  if (/^\.\d+$/.test(cleaned)) {
    const num = parseFloat('0' + cleaned);
    if (!isNaN(num)) return num.toFixed(2);
  }

  // Keep product / SKU name as-is (trimmed)
  return s;
}

// ─── Branch intelligence ───────────────────────────────────────────────────

/**
 * Parent outlet for "Same" pairs + trailing-S codes.
 * BLYS→BLY, DNMS→DNM, RANS→RAN, SAV→RUP, BCTS→BCT, MOHS→MOH.
 * Used when COMBINING for matrix/reports — not when user filters exact sub-store.
 */
export function mergeOutletToParent(code: string): string {
  const up = String(code || '').toUpperCase().trim();
  if (!up) return up;
  // Never merge warehouse / online
  if (up === 'DWL' || up === 'ONL' || up === 'ONLS' || up === 'ONLINE' || up === 'WHL') return up;
  // Explicit Same pairs (official branch list)
  if (SUBSTORE_TO_PARENT[up]) return SUBSTORE_TO_PARENT[up];
  // Trailing S on 2–4 letter outlet codes (BCTS→BCT, MOHS→MOH, …)
  if (up.length >= 3 && /^[A-Z]{2,4}S$/.test(up)) return up.slice(0, -1);
  return up;
}

/** True if code is a sub-store / trailing-S variant (BLYS, DNMS, RANS, SAV, …) */
export function isTrailingSOutlet(code: string): boolean {
  const up = String(code || '').toUpperCase().trim();
  if (up === 'DWL' || up === 'ONL' || up === 'ONLS' || up === 'ONLINE' || up === 'WHL') return false;
  if (SUBSTORE_TO_PARENT[up]) return true;
  return /^[A-Z]{2,4}S$/.test(up);
}

/** Online / E-Commerce — never show in matrix or move reports. */
export function isOnlineBranch(branch: string): boolean {
  const up = String(branch || '').toUpperCase().trim();
  if (!up) return false;
  if (up === 'ONLS' || up === 'ONL' || up === 'ONLINE') return true;
  const lower = up.toLowerCase();
  return (
    lower.includes('online') ||
    lower.includes('e-commerce') ||
    lower.includes('ecommerce') ||
    lower.includes('e commerce')
  );
}

/**
 * Non-outlet codes — never in outlet count / matrix / reports.
 * FAIR = not a showroom · BAC = invalid · TOTAL rows · Online.
 */
const EXCLUDED_OUTLET_CODES = new Set([
  'FAIR',
  'BAC',
  'ONL',
  'ONLS',
  'ONLINE',
  'TOTAL',
  'TOTALS',
  'ALL',
  'N/A',
  'NA',
  'UNKNOWN',
]);

export function isExcludedOutlet(branch: string): boolean {
  const up = String(branch || '').toUpperCase().trim();
  if (!up) return true;
  if (EXCLUDED_OUTLET_CODES.has(up)) return true;
  if (isOnlineBranch(up)) return true;
  if (up.startsWith('TOTAL') || up.includes('TOTAL:') || up.includes('TOTAL :')) return true;
  if (up === 'FAIR' || /^FAIR\b/.test(up)) return true;
  return false;
}

/** Warehouse / DWL — stock only; no Move IN/OUT, Contribution in retail columns. */
export function isWarehouseBranchCode(branch: string): boolean {
  const lower = String(branch || '').toLowerCase().trim();
  return (
    lower === 'dwl' ||
    lower.startsWith('dwl ') ||
    lower.endsWith(' dwl') ||
    lower.includes('warehouse') ||
    lower.includes('central stock') ||
    lower.includes('reserved')
  );
}

/** Parent + all sub-store codes for filter family match (e.g. RUP → [RUP, SAV]). */
export function getOutletFamilyCodes(code: string): string[] {
  const up = String(code || '').toUpperCase().trim();
  if (!up) return [];
  const parent = mergeOutletToParent(up);
  const subs = PARENT_TO_SUBSTORES[parent] || [];
  // Also include generic trailing-S of parent if not already listed
  const trailingS = parent.length >= 2 && parent.length <= 4 ? `${parent}S` : '';
  const family = new Set<string>([parent, ...subs]);
  if (trailingS) family.add(trailingS);
  family.add(up);
  return Array.from(family);
}

/**
 * Normalize branch for storage — KEEP trailing S (BCTS stays BCTS).
 * Matrix engine merges via mergeOutletToParent; filter can target exact S code.
 */
export function intelligentNormalizeBranch(raw: string, store?: DataIdentityStore): string {
  const s = String(raw || '').trim();
  if (!s) return 'UNKNOWN';

  const st = store || loadStore();
  const nk = normKey(s);

  // Exact / alias match only on the code as stored (do not collapse S here)
  for (const id of Object.values(st.branches)) {
    if (normKey(id.canonical) === nk || id.aliases.some((a) => normKey(a) === nk)) {
      id.hitCount += 1;
      id.lastSeen = Date.now();
      return id.canonical;
    }
  }

  // Code-like short name (2–5 letters) → uppercase, preserve trailing S
  if (/^[a-zA-Z]{2,5}$/.test(s) && !/\s/.test(s)) {
    return s.toUpperCase();
  }

  // "Chittagong - #01" / "Branch-01" style → strip noise, try match
  const stripped = nk
    .replace(/\bbranch\b/g, '')
    .replace(/\bstore\b/g, '')
    .replace(/\boutlet\b/g, '')
    .replace(/\bshowroom\b/g, '')
    .replace(/\d+/g, '')
    .trim();

  for (const id of Object.values(st.branches)) {
    if (id.aliases.some((a) => stripped.includes(normKey(a)) || normKey(a).includes(stripped))) {
      if (stripped.length >= 3) {
        id.hitCount += 1;
        id.lastSeen = Date.now();
        return id.canonical;
      }
    }
  }

  // New branch — short codes uppercase; keep S suffix identity
  if (s.length <= 5 && /^[a-zA-Z0-9]+$/.test(s)) return s.toUpperCase();
  return s;
}

// ─── Learning from uploads ─────────────────────────────────────────────────

export function learnFromRecords(records: RawInventoryRecord[]): void {
  if (!records || records.length === 0) return;
  const store = loadStore();

  records.forEach((r) => {
    // Branch
    const bCanon = intelligentNormalizeBranch(r.branch, store);
    const bKey = bCanon.toUpperCase();
    if (!store.branches[bKey]) {
      store.branches[bKey] = {
        canonical: bCanon,
        aliases: [normKey(r.branch)],
        lastSeen: Date.now(),
        hitCount: 1
      };
    } else {
      const aliases = new Set(store.branches[bKey].aliases.map(normKey));
      aliases.add(normKey(r.branch));
      store.branches[bKey].aliases = Array.from(aliases);
      store.branches[bKey].hitCount += 1;
      store.branches[bKey].lastSeen = Date.now();
    }

    // Weight / product
    const wCanon = intelligentNormalizeWeight(r.weight, store);
    const wNum = parseFloat(wCanon);
    const isNumeric = !isNaN(wNum) && /^[-+]?[0-9]*\.?[0-9]+$/.test(wCanon);

    if (isNumeric) {
      const wKey = wCanon;
      if (!store.weights[wKey]) {
        store.weights[wKey] = {
          canonical: wCanon,
          aliases: [normKey(r.weight)],
          numericValue: wNum,
          lastSeen: Date.now(),
          hitCount: 1
        };
      } else {
        const aliases = new Set(store.weights[wKey].aliases.map(normKey));
        aliases.add(normKey(r.weight));
        store.weights[wKey].aliases = Array.from(aliases);
        store.weights[wKey].hitCount += 1;
        store.weights[wKey].lastSeen = Date.now();
      }
    } else {
      const pKey = normKey(wCanon);
      if (!store.products[pKey]) {
        store.products[pKey] = {
          canonical: wCanon,
          aliases: [normKey(r.weight)],
          lastSeen: Date.now(),
          hitCount: 1
        };
      } else {
        const aliases = new Set(store.products[pKey].aliases.map(normKey));
        aliases.add(normKey(r.weight));
        store.products[pKey].aliases = Array.from(aliases);
        store.products[pKey].hitCount += 1;
        store.products[pKey].lastSeen = Date.now();
      }
    }
  });

  saveStore(store);
}

/** Normalize a full record list in-place style (returns new array) */
export function applyIdentityToRecords(records: RawInventoryRecord[]): RawInventoryRecord[] {
  const store = loadStore();
  return records.map((r) => ({
    ...r,
    branch: intelligentNormalizeBranch(r.branch, store),
    weight: intelligentNormalizeWeight(r.weight, store)
  }));
}

export function getIdentitySnapshot(): DataIdentityStore {
  return loadStore();
}


/** Full names — FINAL official master (image). No JA / DIN / MR2 / FAIR. */
const BRANCH_DISPLAY_NAMES: Record<string, string> = {
  BCT: 'Bashundhara City',
  BLY: 'Baily Road',
  BLYS: 'Baily Road Store',
  BMK: 'Baitul Mukarram',
  BOG: 'Bogura',
  BSL: 'Barishal Showroom',
  CHU: 'Chuadanga',
  CTG: 'Chittagong #01',
  CUM: 'Cumilla',
  DMD: 'Dhanmondi',
  DNM: 'Dhaka New Market',
  DNMS: 'Dhaka New Market Store',
  DWL: 'Diamond World LTD',
  GAZ: 'Gazipur',
  GUL: 'Gulshan',
  JAS: 'Jashore',
  KBH: 'Chittagong #02',
  KHU: 'Khulna',
  MIR: 'Mirpur',
  MOH: 'Mohammadpur',
  MYM: 'Mymensingh',
  NAK: 'Noakhali Showroom',
  NAR: 'Narayanganj Showroom',
  NOR: 'Narshingdhi Showroom',
  ONLS: 'Online',
  PCT: 'Pink City Showroom',
  RAJ: 'Rajshahi',
  RAN: 'Rangpur Showroom',
  RANS: 'Rangpur Showroom Store',
  RUP: 'Rupayan Shop Square Showroom',
  SAV: 'Rupayan Shop Square Showroom Store',
  SYL: 'Sylhet',
  UTT: 'Uttara',
};

export function isOfficialBranch(code: string): boolean {
  const up = String(code || '').toUpperCase().trim();
  return up in BRANCH_DISPLAY_NAMES || up in BRANCH_SEED;
}

/**
 * Always prefer official full outlet name from the branch master list.
 * Resolves shortcuts (JAS → Jashore) and known aliases; never shows FAIR.
 */
export function getBranchDisplayName(branch: string): string {
  const raw = String(branch || '').trim();
  if (!raw) return '—';
  const up = raw.toUpperCase();
  if (isExcludedOutlet(up)) return '—';

  // Direct shortcut match
  if (BRANCH_DISPLAY_NAMES[up]) return BRANCH_DISPLAY_NAMES[up];

  // Parent of sub-store (BLYS → Baily Road Store still has own name; parent map for merged codes)
  const parent = mergeOutletToParent(up);
  if (BRANCH_DISPLAY_NAMES[up]) return BRANCH_DISPLAY_NAMES[up];
  if (parent !== up && BRANCH_DISPLAY_NAMES[parent] && !isTrailingSOutlet(up)) {
    return BRANCH_DISPLAY_NAMES[parent];
  }

  // Alias scan against seed (e.g. "Jessore" → Jashore, "Chittagong" → Chittagong #01)
  const nk = normKey(raw);
  for (const [code, aliases] of Object.entries(BRANCH_SEED)) {
    if (normKey(code) === nk || aliases.some((a) => normKey(a) === nk)) {
      return BRANCH_DISPLAY_NAMES[code] || code;
    }
    if (aliases.some((a) => nk.includes(normKey(a)) || normKey(a).includes(nk))) {
      if (nk.length >= 3) return BRANCH_DISPLAY_NAMES[code] || code;
    }
  }

  // Already a full name that matches a display value
  for (const [code, name] of Object.entries(BRANCH_DISPLAY_NAMES)) {
    if (normKey(name) === nk) return name;
  }

  return raw;
}

/** Official retail outlet codes only (excludes DWL, Online, FAIR). */
export function getOfficialRetailOutletCodes(): string[] {
  return Object.keys(BRANCH_DISPLAY_NAMES).filter(
    (c) => !isWarehouseBranchCode(c) && !isExcludedOutlet(c),
  );
}

export function registerBranchAlias(canonical: string, alias: string): void {
  const store = loadStore();
  const key = canonical.toUpperCase();
  if (!store.branches[key]) {
    store.branches[key] = {
      canonical: key,
      aliases: [normKey(alias)],
      lastSeen: Date.now(),
      hitCount: 0
    };
  } else {
    const aliases = new Set(store.branches[key].aliases.map(normKey));
    aliases.add(normKey(alias));
    store.branches[key].aliases = Array.from(aliases);
  }
  saveStore(store);
}

export function registerWeightAlias(canonical: string, alias: string): void {
  const store = loadStore();
  const wCanon = intelligentNormalizeWeight(canonical, store);
  if (!store.weights[wCanon]) {
    store.weights[wCanon] = {
      canonical: wCanon,
      aliases: [normKey(alias)],
      numericValue: parseFloat(wCanon) || null,
      lastSeen: Date.now(),
      hitCount: 0
    };
  } else {
    const aliases = new Set(store.weights[wCanon].aliases.map(normKey));
    aliases.add(normKey(alias));
    store.weights[wCanon].aliases = Array.from(aliases);
  }
  saveStore(store);
}

/**
 * Soft-match price-range style headers in messy sheets.
 * e.g. "0.02-0.20", "2c-20c", "price 5000-10000" → used as filter hints, not row keys.
 */
export function parseRangeToken(token: string): { from: number; to: number } | null {
  const s = String(token || '').trim();
  // Cts range
  const cts = s.match(/(\d*\.?\d+)\s*(?:ct|cts|carat)?\s*[-–—to]+\s*(\d*\.?\d+)/i);
  if (cts) {
    let a = parseFloat(cts[1]);
    let b = parseFloat(cts[2]);
    if (/cent/i.test(s) || (a >= 1 && a <= 99 && b >= 1 && b <= 99 && !s.includes('.'))) {
      a = a / 100;
      b = b / 100;
    }
    if (!isNaN(a) && !isNaN(b)) return { from: Math.min(a, b), to: Math.max(a, b) };
  }
  return null;
}
