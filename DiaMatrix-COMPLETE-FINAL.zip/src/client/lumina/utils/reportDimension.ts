import type { RedistributionReport } from '../types';

/**
 * Presentation-only dimension detection.
 * It does NOT change calculations or parsing. It only decides whether a
 * report's first item dimension should be labelled Carat/Ct or Amount.
 */
export function getReportDimension(report: RedistributionReport): {
  label: string;
  unit: string;
  isAmount: boolean;
} {
  const keys = (report.matrix?.weights || []).map(String).filter(Boolean);
  const config = report.categoryConfig;
  const configText = `${config?.itemLabel || ''} ${config?.itemUnit || ''}`.toLowerCase();

  const explicitAmount = /amount|value|price|money|bdt|taka|৳|usd|eur|inr/.test(configText);
  const numericParts = keys.map((key) => {
    const first = key.split(' · ')[0].trim().replace(/,/g, '');
    return /^\d+(?:\.\d+)?$/.test(first) ? Number(first) : null;
  }).filter((v): v is number => v !== null);

  // Jewelry uploads commonly use small decimal carats (0.01–5). Larger
  // numeric bands are treated as amount/value bands for presentation.
  const largeNumericBand = numericParts.length >= Math.max(1, Math.ceil(keys.length * 0.6))
    && numericParts.some((n) => n >= 10);

  const isAmount = explicitAmount || largeNumericBand;
  if (isAmount) return { label: 'Amount', unit: config?.currencySymbol || '৳', isAmount: true };
  return { label: 'Carat', unit: config?.itemUnit || 'ct', isAmount: false };
}
