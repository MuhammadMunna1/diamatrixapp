/**
 * Software-format exports: coloured Excel + reliable PDF (no popup required).
 */
import type { RedistributionReport } from '../types';
import { getReportDimension } from './reportDimension';
import { getBranchDisplayName, isOnlineBranch, isExcludedOutlet, isWarehouseBranchCode } from './dataIdentityEngine';
import * as ExcelJS from 'exceljs';
import { jsPDF } from 'jspdf';
import html2canvas from 'html2canvas';

const DEFAULT_DATE_RANGE = '01-03-2026 to 19-09-2026';
const BRAND = {
  short: 'DiaMatrix',
  full: 'DiaMatrix',
};

export function esc(v: unknown): string {
  return String(v ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

export function downloadBlob(blob: Blob, filename: string) {
  if (!blob || blob.size === 0) throw new Error('The report file is empty.');
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.rel = 'noopener';
  a.style.position = 'fixed';
  a.style.left = '-9999px';
  document.body.appendChild(a);
  a.click();
  a.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 10000);
}

/** Cell styles matching on-screen matrix */
export const CELL = {
  th: 'background:#D9E2EC;color:#0B2545;font-weight:700;border:1px solid #94A3B8;padding:6px 8px;text-align:center;white-space:normal;vertical-align:middle;font-family:Calibri,Arial,sans-serif;font-size:11px;',
  thSub:
    'background:#E8EEF4;color:#0B2545;font-weight:600;border:1px solid #94A3B8;padding:4px 6px;text-align:center;font-size:10px;font-family:Calibri,Arial,sans-serif;',
  td: 'border:1px solid #94a3b8;padding:4px 6px;text-align:center;vertical-align:middle;white-space:normal;font-family:Calibri,Arial,sans-serif;font-size:11px;',
  tdLeft:
    'border:1px solid #94a3b8;padding:4px 8px;text-align:left;font-weight:700;background:#f1f5f9;vertical-align:middle;font-family:Calibri,Arial,sans-serif;font-size:11px;',
  // Keep calculations/formulas/KPIs neutral. Movement uses text-only semantic emphasis.
  moveIn: 'color:#065f46;font-weight:700;',
  moveOut: 'color:#991b1b;font-weight:700;',
  moveInBg: 'background:#c6efce;color:#006100;font-weight:700;',
  moveOutBg: 'background:#ffc7ce;color:#9c0006;font-weight:700;',
  zero: 'color:#64748b;',
  title: 'font-size:16px;font-weight:800;color:#0f172a;padding:8px 0;font-family:Calibri,Arial,sans-serif;',
  meta: 'font-size:11px;color:#475569;padding:2px 0;font-family:Calibri,Arial,sans-serif;',
};

export function netMoveCell(n: number): string {
  const v = Math.round(Number(n) || 0);
  if (v > 0) return `<td style="${CELL.td}${CELL.moveIn}">+${v}</td>`;
  if (v < 0) return `<td style="${CELL.td}${CELL.moveOut}">${v}</td>`;
  return `<td style="${CELL.td}${CELL.zero}">0</td>`;
}

export type StyledSheet = {
  name: string;
  /** Full HTML fragment (tables with inline styles) */
  html: string;
};

/** Multi-table coloured .xls — Excel / Sheets open with borders & colours */
export function downloadStyledExcel(sheets: StyledSheet[], filenameBase: string) {
  void (async () => {
    const wb = new ExcelJS.Workbook();
    wb.creator = 'DiaMatrix';
    wb.company = 'DiaMatrix';
    for (const sheet of sheets) {
      const ws = createSheet(wb, sheet.name.slice(0, 31) || 'Report');
      setupExcelSheet(ws);
      const doc = new DOMParser().parseFromString(`<div>${sheet.html}</div>`, 'text/html');
      const tables = Array.from(doc.querySelectorAll('table'));
      if (!tables.length) {
        const row = ws.addRow([doc.body.textContent?.trim() || 'No data']);
        styleExcelBody(row);
      } else {
        for (const table of tables) {
          for (const tr of Array.from(table.querySelectorAll('tr'))) {
            const values = Array.from(tr.querySelectorAll('th,td')).map((cell) => cell.textContent?.trim() || '');
            const row = ws.addRow(values);
            const hasHeader = tr.querySelector('th') != null;
            if (hasHeader) styleExcelHeader(row, EXECUTION_COLORS.deepBlue);
            else styleExcelBody(row);
          }
          ws.addRow([]);
        }
      }
      for (let i = 1; i <= ws.columnCount; i++) ws.getColumn(i).width = Math.min(42, Math.max(14, i === 1 ? 28 : 16));
      applyGlobalSheetFill(ws);
    }
    const buffer = await wb.xlsx.writeBuffer();
    const name = `${filenameBase.replace(/\.xls[x]?$/i, '')}.xlsx`;
    downloadBlob(new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }), name);
  })().catch((error) => {
    console.error('ExcelJS export failed:', error);
    window.alert('Excel export failed. Please try again.');
  });
}

/**
 * Reliable PDF path:
 * 1) Hidden iframe + print (no popup blocker)
 * 2) Fallback: download printable HTML (user opens → Ctrl+P → Save as PDF)
 */

/**
 * Print an on-screen report root while preserving layout.
 * Marks body + root, invokes window.print, then cleans up.
 * Requires print.css (imported via index.css) and data-dmx-report-print-root on the root node.
 */
export function printDomReportRoot(root?: HTMLElement | null): void {
  const el =
    root ||
    (document.querySelector('[data-dmx-report-print-root="true"]') as HTMLElement | null);
  if (!el) {
    window.print();
    return;
  }
  el.setAttribute('data-dmx-report-print-root', 'true');
  document.body.classList.add('dmx-printing-report');
  const cleanup = () => {
    document.body.classList.remove('dmx-printing-report');
    window.removeEventListener('afterprint', cleanup);
  };
  window.addEventListener('afterprint', cleanup, { once: true });
  // Fallback cleanup if afterprint does not fire
  setTimeout(cleanup, 60_000);
  try {
    window.focus();
    window.print();
  } catch {
    cleanup();
  }
}

/**
 * Wrap arbitrary table/section HTML as one outlet page for multi-page PDF/print.
 */
export function asOutletPrintPage(title: string, innerHtml: string, meta?: string): string {
  return `<section class="dmx-outlet-page" data-dmx-outlet-page="true">
  <h2>${esc(title)}</h2>
  ${meta ? `<div class="dmx-meta">${esc(meta)}</div>` : ''}
  ${innerHtml}
</section>`;
}

/** Shared print CSS injected into printable HTML / iframe documents. */
export const PRINT_DOCUMENT_CSS = `
  @page { size: A4 portrait; margin: 10mm 8mm 12mm 8mm; }
  * { -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; box-sizing: border-box; }
  html, body {
    font-family: Calibri, Arial, Helvetica, sans-serif;
    font-size: 10pt;
    color: #0f172a;
    background: #ffffff;
    margin: 0;
    padding: 0;
  }
  body { padding: 2mm 3mm; }
  h1 { font-size: 14pt; font-weight: 800; margin: 0 0 2mm; color: #0f172a; }
  h2 { font-size: 12pt; font-weight: 700; margin: 0 0 2mm; color: #0f172a; page-break-after: avoid; }
  .dmx-meta, .meta {
    color: #334155;
    font-weight: 600;
    font-size: 9pt;
    margin: 0 0 3mm;
  }
  table {
    width: 100%;
    max-width: 100%;
    border-collapse: collapse;
    table-layout: fixed;
    font-size: 8.5pt;
    margin: 0 0 3mm;
  }
  th, td {
    border: 1px solid #334155;
    padding: 2.5pt 3.5pt;
    vertical-align: top;
    word-break: break-word;
    overflow-wrap: anywhere;
    color: #0f172a;
    background: #ffffff;
  }
  th {
    background: #e2e8f0;
    font-weight: 700;
    font-size: 8pt;
  }
  td.num, th.num { text-align: right; font-variant-numeric: tabular-nums; white-space: nowrap; }
  tr { page-break-inside: avoid; break-inside: avoid; }
  thead { display: table-header-group; }
  .move-in { font-weight: 700; background: #f1f5f9; }
  .move-out { font-weight: 700; background: #e2e8f0; }
  .dmx-outlet-page, .section, [data-dmx-outlet-page="true"] {
    display: block;
    width: 100%;
    break-before: page;
    page-break-before: always;
    break-inside: avoid-page;
    page-break-inside: avoid;
    margin: 0;
    padding: 0 0 3mm;
  }
  .dmx-outlet-page:first-child, .section:first-child, [data-dmx-outlet-page="true"]:first-child {
    break-before: auto;
    page-break-before: auto;
  }
`;

/**
 * Build a complete printable HTML document (A4, outlet page-breaks, readable tables).
 */
export function buildPrintableDocumentHtml(title: string, bodyHtml: string): string {
  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>${esc(title)}</title>
<style>${PRINT_DOCUMENT_CSS}</style>
</head>
<body class="dmx-print-document">
<header>
  <h1>${esc(title)}</h1>
  <div class="dmx-meta">${esc(BRAND.full)} · ${esc(new Date().toLocaleString())}</div>
</header>
${bodyHtml}
</body>
</html>`;
}

/**
 * Reliable PDF path:
 * 1) Hidden iframe + print (no popup blocker)
 * 2) Fallback: download printable HTML (user opens → Ctrl+P → Save as PDF)
 */
export function downloadPrintablePdf(title: string, bodyHtml: string, filenameBase: string) {
  const fullHtml = buildPrintableDocumentHtml(title, bodyHtml);

  // 1) Hidden iframe print
  try {
    const iframe = document.createElement('iframe');
    iframe.setAttribute('title', 'pdf-print');
    iframe.style.cssText =
      'position:fixed;right:0;bottom:0;width:0;height:0;border:0;opacity:0;pointer-events:none;';
    document.body.appendChild(iframe);
    const doc = iframe.contentDocument || iframe.contentWindow?.document;
    if (doc) {
      doc.open();
      doc.write(fullHtml);
      doc.close();
      const win = iframe.contentWindow;
      const cleanup = () => {
        setTimeout(() => {
          try {
            document.body.removeChild(iframe);
          } catch {
            /* ignore */
          }
        }, 1000);
      };
      if (win) {
        setTimeout(() => {
          try {
            win.focus();
            win.print();
          } catch {
            /* fallback below */
          }
          cleanup();
        }, 450);
        // Also offer file download so user always gets something
        setTimeout(() => {
          downloadBlob(
            new Blob([fullHtml], { type: 'text/html;charset=utf-8' }),
            `${filenameBase}_PrintToPDF.html`
          );
        }, 600);
        return;
      }
    }
  } catch {
    /* fall through */
  }

  // 2) Direct HTML download
  downloadBlob(
    new Blob([fullHtml], { type: 'text/html;charset=utf-8' }),
    `${filenameBase}_PrintToPDF.html`
  );
  alert(
    'PDF file downloaded as HTML.\nOpen the file → Ctrl+P (or Cmd+P) → Save as PDF.\n(Print dialog may also open automatically.)'
  );
}

function buildMatrixHtml(report: RedistributionReport, period: string, mode: string): string {
  const branches = (report.matrix?.branches || []).filter(
    (b) => b !== 'WHL' && !isWarehouseBranchCode(b) && !isOnlineBranch(b) && !isExcludedOutlet(b),
  );
  const weights = report.matrix?.weights || [];
  const hasDesignBreakdown = weights.some((w) => String(w).includes(' · '));
  const dimension = getReportDimension(report);
  const dimensionLabel = dimension.label;

  const splitItemKey = (key: string): { dimension: string; design: string } => {
    const parts = String(key || '').split(' · ');
    if (parts.length >= 2) {
      return { dimension: parts[0].trim(), design: parts.slice(1).join(' · ').trim() };
    }
    return { dimension: String(key || '').trim(), design: '' };
  };

  const th = (text: string, cls = CELL.th) => `<th style="${cls}">${esc(text)}</th>`;
  const groupTh = (text: string) => `<th colspan="5" style="${CELL.th}">${esc(getBranchDisplayName(text))}</th>`;

  let thead = '<tr>';
  if (hasDesignBreakdown) {
    thead += th('Design Name') + th(dimensionLabel) + th('DWL\nStock');
  } else {
    thead += th(dimensionLabel === 'Amount' ? 'Amount' : 'Particulars Name') + th('DWL\nStock');
  }
  branches.filter((b) => b !== 'DWL').forEach((b) => { thead += groupTh(b); });
  thead += th('Total\nStock') + th('Total\nSold') + th('Refill\nDemand');
  thead += '</tr><tr>';
  if (hasDesignBreakdown) thead += '<th style="' + CELL.thSub + '"></th><th style="' + CELL.thSub + '"></th><th style="' + CELL.thSub + '">Stock</th>';
  else thead += '<th style="' + CELL.thSub + '"></th><th style="' + CELL.thSub + '">Stock</th>';
  branches.filter((b) => b !== 'DWL').forEach(() => {
    ['SOLD QTY', 'Current Stock', 'Average', 'Contribution %', 'Move IN/OUT'].forEach((h) => {
      thead += th(h, CELL.thSub);
    });
  });
  thead += '<th style="' + CELL.thSub + '"></th><th style="' + CELL.thSub + '"></th><th style="' + CELL.thSub + '"></th></tr>';

  let body = '';
  weights.forEach((w) => {
    const { dimension: dimensionValue, design } = splitItemKey(w);
    const dwlStock = report.matrix.cells['DWL']?.[w]?.stock ?? report.matrix.cells['WHL']?.[w]?.stock ?? 0;
    let totalStock = dwlStock;
    let totalSold = 0;
    const branchRows = branches.filter((b) => b !== 'DWL').map((b) => {
      const cell = report.matrix.cells[b]?.[w];
      const sold = Number(cell?.sold ?? 0);
      const stock = Number(cell?.stock ?? 0);
      const avg = cell?.sales3M ? Math.round(cell.sales3M / 3) : Math.round(sold / 3);
      const net = Number(cell?.netMove ?? 0);
      totalStock += stock;
      totalSold += sold;
      return { sold, stock, avg, net };
    });
    const totalSoldForItem = branchRows.reduce((sum, x) => sum + x.sold, 0);
    const refill = report.weightSummaries.find((x) => x.weight === w)?.unmetShortage || Math.max(0, totalSold - totalStock);

    body += '<tr>';
    if (hasDesignBreakdown) {
      body += `<td style="${CELL.tdLeft}">${esc(design || '—')}</td>`;
      body += `<td style="${CELL.td}">${esc(dimensionValue)}</td>`;
    } else {
      body += `<td style="${CELL.tdLeft}">${esc(dimensionValue)}</td>`;
    }
    body += `<td style="${CELL.td}">${Math.round(dwlStock)}</td>`;
    branchRows.forEach(({ sold, stock, avg, net }) => {
      const contrib = totalSoldForItem > 0 ? Math.round((sold / totalSoldForItem) * 100) : 0;
      body += `<td style="${CELL.td}">${Math.round(sold)}</td>`;
      body += `<td style="${CELL.td}">${Math.round(stock)}</td>`;
      body += `<td style="${CELL.td}">${avg}</td>`;
      body += `<td style="${CELL.td}">${contrib}%</td>`;
      if (net > 0) body += `<td style="${CELL.td}${CELL.moveInBg}">+${Math.round(net)}</td>`;
      else if (net < 0) body += `<td style="${CELL.td}${CELL.moveOutBg}">${Math.round(net)}</td>`;
      else body += `<td style="${CELL.td}">0</td>`;
    });
    body += `<td style="${CELL.td}">${Math.round(totalStock)}</td>`;
    body += `<td style="${CELL.td}">${Math.round(totalSold)}</td>`;
    body += `<td style="${CELL.td}">${Math.round(refill)}</td>`;
    body += '</tr>';
  });

  return `<div style="${CELL.meta}">Period: ${esc(period)} · Mode: ${esc(mode)} · Dimension: ${esc(dimensionLabel)}</div>
  <table style="width:100%;border-collapse:collapse;table-layout:fixed;">
    <thead>${thead}</thead>
    <tbody>${body}</tbody>
  </table>`;
}

function buildBranchSummaryHtml(report: RedistributionReport, period: string): string {
  let rows = `<tr>
    <th style="${CELL.th}">Branch</th>
    <th style="${CELL.th}">Total Sold</th>
    <th style="${CELL.th}">Current Stock</th>
    <th style="${CELL.th}">Move IN</th>
    <th style="${CELL.th}">Move OUT</th>
    <th style="${CELL.th}">Net Change</th>
    <th style="${CELL.th}">Status</th>
  </tr>`;
  (report.branchSummaries || []).forEach((b) => {
    rows += `<tr>
      <td style="${CELL.tdLeft}">${esc(getBranchDisplayName(b.branch))}</td>
      <td style="${CELL.td}">${b.totalSold}</td>
      <td style="${CELL.td}">${b.totalCurrentStock}</td>
      <td style="${CELL.td}${CELL.moveIn}">${b.totalMoveIn}</td>
      <td style="${CELL.td}${CELL.moveOut}">${b.totalMoveOut}</td>
      <td style="${CELL.td}">${b.netChange}</td>
      <td style="${CELL.td}">${esc(b.status)}</td>
    </tr>`;
  });
  return `<div style="${CELL.meta}">Period: ${esc(period)}</div>
  <table><tbody>${rows}</tbody></table>`;
}

function buildTransfersHtml(report: RedistributionReport): string {
  let rows = `<tr>
    <th style="${CELL.th}">Order ID</th>
    <th style="${CELL.th}">Item</th>
    <th style="${CELL.th}">From</th>
    <th style="${CELL.th}">To</th>
    <th style="${CELL.th}">Qty</th>
    <th style="${CELL.th}">Priority</th>
    <th style="${CELL.th}">Reason</th>
  </tr>`;
  (report.transferOrders || []).forEach((t) => {
    rows += `<tr>
      <td style="${CELL.td}">${esc(t.id)}</td>
      <td style="${CELL.td}">${esc(t.weight)}</td>
      <td style="${CELL.td}">${esc(getBranchDisplayName(t.fromBranch))}</td>
      <td style="${CELL.td}">${esc(getBranchDisplayName(t.toBranch))}</td>
      <td style="${CELL.td}">${t.qty}</td>
      <td style="${CELL.td}">${esc(t.priority)}</td>
      <td style="${CELL.tdLeft}">${esc(t.reason)}</td>
    </tr>`;
  });
  return `<table><tbody>${rows}</tbody></table>`;
}

function buildRefillHtml(report: RedistributionReport): string {
  let rows = `<tr>
    <th style="${CELL.th}">Item</th>
    <th style="${CELL.th}">Qty to Buy</th>
    <th style="${CELL.th}">Sold Demand</th>
    <th style="${CELL.th}">Available Stock</th>
    <th style="${CELL.th}">Urgency</th>
    <th style="${CELL.th}">Rationale</th>
  </tr>`;
  (report.procurementOrders || []).forEach((p) => {
    rows += `<tr>
      <td style="${CELL.tdLeft}">${esc(p.weight)}</td>
      <td style="${CELL.td}">${p.qtyToBuy}</td>
      <td style="${CELL.td}">${p.soldDemand}</td>
      <td style="${CELL.td}">${p.availableStock}</td>
      <td style="${CELL.td}">${esc(p.urgency)}</td>
      <td style="${CELL.tdLeft}">${esc(p.rationale)}</td>
    </tr>`;
  });
  return `<table><tbody>${rows}</tbody></table>`;
}

/** Full software-style Excel (matrix + branch + moves + refill) */
export function exportStyledExcelReport(
  report: RedistributionReport,
  period: string,
  allocationMode: string
): void {
  const mode = (['contribution', 'baseline', 'hybrid', 'liquidity', 'demand_backup', 'coverage'].includes(allocationMode)
    ? allocationMode
    : 'contribution') as ExecutionMode;
  void exportExecutionExcelReport(report, mode);
}

/** PDF: print dialog + HTML fallback download */
export function exportReportPdf(
  report: RedistributionReport,
  period: string,
  allocationMode: string
): void {
  const mode = (['contribution', 'baseline', 'hybrid', 'liquidity', 'demand_backup', 'coverage'].includes(allocationMode)
    ? allocationMode
    : 'contribution') as ExecutionMode;
  void exportExecutionPdfReport(report, mode);
}

/**
 * Generic AOA (array of arrays) → software-format styled Excel table.
 * First row = header. Soft light-gray headers + soft green/pink movement cells.
 * netMoveColIndex / movementColIndexes (0-based) get print-friendly Move colours.
 */
export function exportAoaStyledExcel(
  sheets: {
    name: string;
    rows: (string | number | null | undefined)[][];
    netMoveColIndex?: number;
    /** Extra 0-based column indexes to colour as movement (Withdraw / Receive / Move IN…) */
    movementColIndexes?: number[];
  }[],
  filenameBase: string
) {
  void (async () => {
    const wb = new ExcelJS.Workbook();
    wb.creator = 'DiaMatrix';
    wb.company = 'DiaMatrix';
    for (const sheet of sheets) {
      const ws = createSheet(wb, sheet.name.slice(0, 31) || 'Report');
      setupExcelSheet(ws);
      if (!sheet.rows.length) {
        ws.addRow(['No data']);
        continue;
      }
      const [header, ...body] = sheet.rows;
      styleExcelHeader(ws.addRow(header.map((v) => v ?? '')), 'D9E2EC');
      const moveIdx = new Set<number>();
      if (sheet.netMoveColIndex != null) moveIdx.add(sheet.netMoveColIndex);
      (sheet.movementColIndexes || []).forEach((i) => moveIdx.add(i));
      body.forEach((values) => {
        const row = ws.addRow(values.map((v) => v ?? ''));
        styleExcelBody(row);
        moveIdx.forEach((zeroBased) => {
          const index = zeroBased + 1;
          const raw = Number(values[zeroBased]);
          if (Number.isFinite(raw) && values[zeroBased] !== '' && values[zeroBased] != null) {
            styleMovementCell(row.getCell(index), raw);
          }
        });
      });
      for (let i = 1; i <= ws.columnCount; i++) ws.getColumn(i).width = i === 1 ? 28 : 14;
      applyGlobalSheetFill(ws);
      ws.autoFilter = { from: { row: 1, column: 1 }, to: { row: Math.max(1, ws.rowCount), column: ws.columnCount } };
      ws.views = [{ showGridLines: true, state: 'frozen', ySplit: 1 }];
    }
    const buffer = await wb.xlsx.writeBuffer();
    downloadBlob(
      new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }),
      `${filenameBase.replace(/\.xlsx?$/i, '')}.xlsx`
    );
  })();
}

/* --------------------------------------------------------------------------
 * ExcelJS + jsPDF execution export engine
 * -------------------------------------------------------------------------- */
const EXECUTION_COLORS = {
  navy: '0A0F1D', white: 'FFFFFF', slate: 'F4F6F9', deepBlue: '0B3D5C',
  blue: '0F4C81', ice: 'E6F0FA', silver: 'E5E7EB', red: '9B1C1C', gold: '92400E', green: '14532D',
  border: '64748B', text: '0F172A',
  headerBg: 'D9E2EC', headerText: '0B2545',
  bodyBg: 'FFFFFF', bodyText: '0F172A',
};
type ExecutionMode = 'contribution' | 'baseline' | 'hybrid' | 'liquidity' | 'demand_backup' | 'coverage';
const executionModeLabel = (mode: ExecutionMode) =>
  mode === 'contribution' ? 'Contribution'
  : mode === 'baseline' ? '3-Month Baseline'
  : mode === 'hybrid' ? 'Hybrid'
  : mode === 'liquidity' ? 'Capital Liquidity'
  : mode === 'demand_backup' ? 'Demand-Backup & Safety'
  : 'Universal Coverage';

function excelFill(color: string): any { return { type: 'pattern', pattern: 'solid', fgColor: { argb: `FF${color}` } }; }
/** Default: bold Calibri 13pt — larger, high-contrast Excel report typography */
function excelFont(color: string, bold = true, size = 13): any { return { name: 'Calibri', size, bold, color: { argb: `FF${color}` } }; }
function excelBorder(color = EXECUTION_COLORS.border): any {
  const side: any = { style: 'thin', color: { argb: `FF${color}` } };
  return { top: side, bottom: side, left: side, right: side };
}
function shade(hex: string, amt: number): string {
  // mix with white (amt>0) or black (amt<0)
  const n = parseInt(hex, 16); const t = amt < 0 ? 0 : 255; const p = Math.abs(amt);
  const ch = (v: number) => Math.round((t - v) * p + v).toString(16).padStart(2, '0');
  return (ch((n >> 16) & 255) + ch((n >> 8) & 255) + ch(n & 255)).toUpperCase();
}
function gradientFill(top: string, bottom: string): any {
  return { type: 'gradient', gradient: 'angle', degree: 90, stops: [{ position: 0, color: { argb: `FF${top}` } }, { position: 1, color: { argb: `FF${bottom}` } }] };
}
/** Raised "3D" edge: light top/left, dark bottom/right. */
function bevelBorder(light: string, dark: string, style: 'thin' | 'medium' = 'thin'): any {
  const l: any = { style, color: { argb: `FF${light}` } };
  const d: any = { style, color: { argb: `FF${dark}` } };
  return { top: l, left: l, bottom: d, right: d };
}
/** True when fill is light → BLACK text required. */
function isLightFill(hex: string): boolean {
  const h = String(hex || '').replace(/^#/, '').toUpperCase();
  if (!/^[0-9A-F]{6}$/.test(h)) return true;
  const r = parseInt(h.slice(0, 2), 16);
  const g = parseInt(h.slice(2, 4), 16);
  const b = parseInt(h.slice(4, 6), 16);
  return (0.299 * r + 0.587 * g + 0.114 * b) / 255 >= 0.55;
}

function paintHeaderCell(c: any, fill: string) {
  // Light header fills + BOLD BLACK text (never same colour as background)
  let bg = String(fill || EXECUTION_COLORS.headerBg).replace(/^#/, '').toUpperCase();
  if (!isLightFill(bg)) bg = 'D9E2EC';
  c.fill = excelFill(bg);
  c.font = excelFont('000000', true, 12);
  c.alignment = { horizontal: 'center', vertical: 'middle', wrapText: true };
  c.border = bevelBorder('FFFFFF', '64748B', 'thin');
}
function styleExcelHeader(row: any, fill = EXECUTION_COLORS.headerBg) {
  row.height = 38;
  row.eachCell((c: any) => paintHeaderCell(c, fill));
}
function styleExcelBody(row: any) {
  row.height = 26;
  row.eachCell((c: any, col: number) => {
    // Light bg + BOLD BLACK text — maximum contrast
    const bg = col === 1 ? 'E8EEF4' : row.number % 2 === 0 ? 'F8FAFC' : 'FFFFFF';
    c.fill = excelFill(bg);
    c.font = excelFont('000000', true, 12);
    c.alignment = { vertical: 'middle', horizontal: col === 1 ? 'left' : 'center', wrapText: true };
    c.border = bevelBorder('FFFFFF', '64748B');
  });
}
function styleMovementCell(c: any, value: number) {
  // Light green/pink fills + dark opposite bold text
  const v = Math.round(Number(value) || 0);
  c.alignment = { horizontal: 'center', vertical: 'middle' };
  c.border = excelBorder('64748B');
  if (v > 0) {
    c.value = `+${v}`;
    c.fill = excelFill('C6EFCE');
    c.font = excelFont('006100', true, 12);
  } else if (v < 0) {
    c.value = `${v}`;
    c.fill = excelFill('FFC7CE');
    c.font = excelFont('9C0006', true, 12);
  } else {
    c.value = '0';
    c.fill = excelFill('FFFFFF');
    c.font = excelFont('000000', true, 12);
  }
}
/** Excel sheet names: max 31 chars, no \ / ? * [ ] :, unique per workbook (case-insensitive). */
function safeSheetName(wb: any, raw: string): string {
  const base = (String(raw || 'Report').replace(/[\\/?*\[\]:]/g, ' ').replace(/\s+/g, ' ').trim() || 'Report').slice(0, 31);
  const taken = new Set<string>((wb.worksheets || []).map((w: any) => String(w.name).toLowerCase()));
  if (!taken.has(base.toLowerCase())) return base;
  for (let i = 2; i < 1000; i++) {
    const suffix = ` (${i})`;
    const candidate = base.slice(0, 31 - suffix.length) + suffix;
    if (!taken.has(candidate.toLowerCase())) return candidate;
  }
  return base.slice(0, 27) + Date.now().toString().slice(-4);
}
/** Create a worksheet and immediately enable gridlines. */
function createSheet(wb: any, name: string): any {
  const worksheet = wb.addWorksheet(safeSheetName(wb, name));
  worksheet.views = [{ showGridLines: true }];
  return worksheet;
}
function setupExcelSheet(ws: any) {
  ws.views = [{ showGridLines: true, state: 'frozen', xSplit: 1, ySplit: 4 }];
  ws.properties.defaultRowHeight = 22;
  ws.pageSetup = { orientation: 'portrait', fitToPage: true, fitToWidth: 1, fitToHeight: 0, paperSize: 9, horizontalDpi: 300, verticalDpi: 300 };
  ws.pageMargins = { left: 0.25, right: 0.25, top: 0.4, bottom: 0.4, header: 0.2, footer: 0.2 };
}
const MOVE_IN_FILL = 'C6EFCE';
const OVERSTOCK_FILL = 'FFC7CE';
function semanticFillFor(value: unknown): string | null {
  const t = String(value ?? '').trim().toLowerCase();
  if (t === 'move in') return MOVE_IN_FILL;
  if (t === 'overstock') return OVERSTOCK_FILL;
  return null;
}
/** Solid green for "Move IN", solid light red/orange for "Overstock" (cell, or whole row if it is the row label). */
function applySemanticFills(ws: any) {
  ws.eachRow((row: any) => {
    const first = semanticFillFor(row.getCell(1).value);
    row.eachCell({ includeEmpty: false }, (cell: any, col: number) => {
      const color = semanticFillFor(cell.value);
      if (color) { cell.fill = excelFill(color); return; }
      if (first && col > 1) cell.fill = excelFill(first);
    });
    if (first) row.getCell(1).fill = excelFill(first);
  });
}
function applyGlobalSheetFill(ws: any) {
  applySemanticFills(ws);
  // Ensure every cell has fill + border; then force readable bold text.
  const MOVE_ARGB = new Set(['FFC6EFCE', 'FFFFC7CE']);
  ws.eachRow((row: any) => {
    row.eachCell({ includeEmpty: true }, (cell: any) => {
      if (!cell.fill) cell.fill = excelFill(EXECUTION_COLORS.white);
      if (!cell.border) cell.border = excelBorder();
    });
  });
  // Contrast pass: light cells → bold BLACK; movement greens/pinks keep dark green/red
  ws.eachRow((row: any, rowNumber: number) => {
    row.eachCell({ includeEmpty: false }, (cell: any) => {
      const argb = String(cell.fill?.fgColor?.argb || 'FFFFFFFF').toUpperCase();
      const hex = argb.startsWith('FF') && argb.length === 8 ? argb.slice(2) : 'FFFFFF';
      if (argb === 'FFC6EFCE') {
        cell.font = excelFont('006100', true, 12);
        return;
      }
      if (argb === 'FFFFC7CE') {
        cell.font = excelFont('9C0006', true, 12);
        return;
      }
      if (argb === 'FFFFF4CC') {
        cell.font = excelFont('000000', true, 12);
        return;
      }
      // Default: bold black on light surfaces
      if (isLightFill(hex)) {
        const size = cell.font?.size || 12;
        cell.font = excelFont('000000', true, size);
      } else {
        cell.font = excelFont('FFFFFF', true, cell.font?.size || 12);
      }
    });
  });
  // Fix leftover solid dark movement fills
  ws.eachRow((row: any, rowNumber: number) => {
    if (rowNumber <= 4) return;
    row.eachCell({ includeEmpty: false }, (cell: any) => {
      const raw = cell.value;
      const s = String(raw ?? '').trim();
      const m = s.match(/^([+-]?)(\d+)$/);
      if (!m) return;
      const argb = String(cell.fill?.fgColor?.argb || '').toUpperCase();
      if (argb === 'FFC6EFCE' || argb === 'FFFFC7CE') return;
      if (argb === 'FF166534' || argb === 'FF991B1B' || argb === 'FF14532D' || argb === 'FF9B1C1C') {
        styleMovementCell(cell, parseInt(m[1] + m[2], 10));
      }
    });
  });
  ws.views = [{ ...(ws.views?.[0] || {}), showGridLines: true }];
}
async function addExcelMeta(ws: any, report: RedistributionReport, mode: ExecutionMode, workbook: any, lastCol = 8) {
  lastCol = Math.max(8, lastCol);
  // Exact software header: logo at top-left, selected date range at top-right.
  ws.getRow(1).height = 42;
  ws.mergeCells(1, 1, 1, 3); // logo (top-left)
  ws.mergeCells(1, 4, 1, lastCol - 3); // title
  ws.mergeCells(1, lastCol - 2, 1, lastCol); // date range (top-right)
  const title = ws.getCell(1, 4);
  title.value = `${executionModeLabel(mode)} — Execution Report`;
  title.fill = excelFill(EXECUTION_COLORS.silver);
  title.font = excelFont(EXECUTION_COLORS.text, true, 15);
  title.alignment = { horizontal: 'left', vertical: 'middle' };
  const dateCell = ws.getCell(1, lastCol);
  dateCell.value = report.period || DEFAULT_DATE_RANGE;
  dateCell.fill = excelFill(EXECUTION_COLORS.silver);
  dateCell.font = excelFont(EXECUTION_COLORS.text, true, 10);
  dateCell.alignment = { horizontal: 'right', vertical: 'middle' };
  ws.getRow(1).eachCell((c: any) => { c.border = excelBorder('B8C0CC'); });

  const imageId = await getWorkbookLogoId(workbook);
  if (imageId != null) placeLogo(ws, imageId);

  ws.mergeCells(2, 1, 2, lastCol);
  const meta = ws.getCell(2, 1);
  meta.value = `Period: ${report.period || 'Current'} · Mode: ${executionModeLabel(mode)} · Generated: ${new Date().toLocaleString()}`;
  meta.font = excelFont(EXECUTION_COLORS.deepBlue, true);
  meta.fill = excelFill(EXECUTION_COLORS.ice);
  meta.alignment = { horizontal: 'left', vertical: 'middle' };
  ws.mergeCells(3, 1, 3, lastCol);
  ws.getCell(3, 1).value = 'Green = Move-In · Red = Move-Out · Gold = Refill / shortage';
  ws.getCell(3, 1).font = excelFont(EXECUTION_COLORS.text, false, 9);
}

export async function buildExecutionExcelWorkbook(report: RedistributionReport, mode: ExecutionMode): Promise<ArrayBuffer> {
  const wb = new ExcelJS.Workbook(); wb.creator = 'DiaMatrix'; wb.company = 'DiaMatrix'; wb.title = `${executionModeLabel(mode)} Execution Report`;
  const branches = (report.matrix?.branches || []).filter(
    (b) => b !== 'WHL' && !isWarehouseBranchCode(b) && !isOnlineBranch(b) && !isExcludedOutlet(b),
  );
  const weights = report.matrix?.weights || [];
  const designBreakdown = weights.some((w) => String(w).includes(' · '));
  const lead = designBreakdown ? 3 : 2;
  const row1: string[] = designBreakdown ? ['Design Name', 'Carat', 'DWL'] : [report.categoryConfig?.itemLabel || 'Item / Particular', 'DWL'];
  branches.forEach((b) => row1.push(getBranchDisplayName(b), '', '', '', ''));
  row1.push('Total Stock', 'Total Sold', 'Refill Demand');
  const row2: string[] = designBreakdown ? ['', '', 'Stock'] : ['', 'Stock'];
  branches.forEach(() => row2.push('Sold Qty', 'Current Stock', 'Average', 'Contribution %', 'Move IN/OUT'));
  row2.push('', '', '');
  const headerMerges: [number, number, number, number][] = [];
  const branchGroups: { startCol: number; span: number }[] = [];
  let gc = lead + 1;
  branches.forEach(() => { headerMerges.push([1, gc, 1, gc + 4]); branchGroups.push({ startCol: gc, span: 5 }); gc += 5; });
  [0, 1, 2].forEach((i) => headerMerges.push([1, gc + i, 2, gc + i]));
  for (let c = 1; c <= lead - 1; c++) headerMerges.push([1, c, 2, c]);
  const matrixRows = weights.map((w) => {
    const parts = String(w).split(' · '); const dimension = parts[0] || ''; const design = parts.length > 1 ? parts.slice(1).join(' · ') : '';
    const dwl = Number(report.matrix.cells['DWL']?.[w]?.stock ?? report.matrix.cells['WHL']?.[w]?.stock ?? 0);
    let totalStock = dwl; let totalSold = 0;
    const branchRows = branches.map((b) => { const c = report.matrix.cells[b]?.[w]; const sold = Number(c?.sold ?? 0); const stock = Number(c?.stock ?? 0); const avg = c?.sales3M ? Math.round(Number(c.sales3M) / 3) : Math.round(sold / 3); const net = Number(c?.netMove ?? 0); totalStock += stock; totalSold += sold; return { sold, stock, avg, net }; });
    const itemSold = branchRows.reduce((sum, x) => sum + x.sold, 0);
    const refillQty = Number(report.weightSummaries.find((x) => x.weight === w)?.unmetShortage ?? Math.max(0, itemSold - totalStock));
    const values: (string | number)[] = designBreakdown ? [design || '—', dimension, Math.round(dwl)] : [dimension, Math.round(dwl)];
    branchRows.forEach(({ sold, stock, avg, net }) => values.push(Math.round(sold), Math.round(stock), avg, `${itemSold > 0 ? Math.round((sold / itemSold) * 100) : 0}%`, net));
    values.push(Math.round(totalStock), Math.round(totalSold), Math.round(refillQty));
    return values;
  });
  const logoId = await getWorkbookLogoId(wb);
  writeStyledRowsSheet(wb, logoId, {
    name: 'Execution Matrix',
    title: `${executionModeLabel(mode)} — Execution Report`,
    period: report.period,
    headerRows: [row1, row2],
    headerMerges,
    rows: matrixRows,
    movementCols: branches.map((_, bi) => lead + bi * 5 + 5),
    refillCols: [lead + branches.length * 5 + 3],
    branchGroups,
    freezeCols: lead,
    columnWidths: [22, 12, 12],
  });

  const summary = createSheet(wb, 'Branch Summary'); setupExcelSheet(summary); await addExcelMeta(summary, report, mode, wb); styleExcelHeader(summary.addRow(['Branch', 'Total Sold', 'Current Stock', 'Move IN', 'Move OUT', 'Net Change', 'Status']), 'D9E2EC');
  (report.branchSummaries || []).forEach((b) => { const r = summary.addRow([getBranchDisplayName(b.branch), b.totalSold, b.totalCurrentStock, b.totalMoveIn, Math.abs(Number(b.totalMoveOut || 0)), b.netChange, b.status]); styleExcelBody(r); styleMovementCell(r.getCell(4), Number(b.totalMoveIn || 0)); styleMovementCell(r.getCell(5), -Math.abs(Number(b.totalMoveOut || 0))); styleMovementCell(r.getCell(6), Number(b.netChange || 0)); });
  [26, 16, 18, 14, 14, 15, 18].forEach((w, i) => summary.getColumn(i + 1).width = w);
  applyGlobalSheetFill(summary);

  const moves = createSheet(wb, 'Movement Orders'); setupExcelSheet(moves); await addExcelMeta(moves, report, mode, wb); styleExcelHeader(moves.addRow(['Order ID', 'Item', 'From', 'To', 'Qty', 'Priority', 'Reason']), 'D9E2EC');
  (report.transferOrders || []).forEach((t) => { const r = moves.addRow([t.id, t.weight, getBranchDisplayName(t.fromBranch), getBranchDisplayName(t.toBranch), t.qty, t.priority, t.reason]); styleExcelBody(r); if (Number(t.qty) > 0) { r.getCell(5).font = excelFont(EXECUTION_COLORS.green, true); r.getCell(5).fill = excelFill('E8F5E9'); } });
  [22, 18, 20, 20, 12, 14, 44].forEach((w, i) => moves.getColumn(i + 1).width = w);
  applyGlobalSheetFill(moves);

  const refill = createSheet(wb, 'Refill Demand'); setupExcelSheet(refill); await addExcelMeta(refill, report, mode, wb); styleExcelHeader(refill.addRow(['Item', 'Qty to Buy', 'Sold Demand', 'Available Stock', 'Urgency', 'Rationale']), 'D9E2EC');
  (report.procurementOrders || []).forEach((p) => { const r = refill.addRow([p.weight, p.qtyToBuy, p.soldDemand, p.availableStock, p.urgency, p.rationale]); styleExcelBody(r); if (Number(p.qtyToBuy) > 0) { r.getCell(2).font = excelFont(EXECUTION_COLORS.gold, true); r.getCell(2).fill = excelFill('FFF4CC'); } });
  [24, 14, 16, 18, 14, 52].forEach((w, i) => refill.getColumn(i + 1).width = w);
  applyGlobalSheetFill(refill);

  // Use an awaited loop here. `addExcelMeta()` loads the logo asynchronously, so a
  // `forEach(async ...)` callback would leave `await` outside the callback's async
  // boundary and could also write the workbook before the logo is attached.
  for (const branch of branches) {
    const ws = createSheet(wb, `Outlet - ${getBranchDisplayName(branch)}`);
    setupExcelSheet(ws);
    await addExcelMeta(ws, { ...report, period: report.period } as RedistributionReport, mode, wb);
    ws.getCell(4, 1).value = `Outlet: ${getBranchDisplayName(branch)}`;
    ws.getCell(4, 1).font = excelFont(EXECUTION_COLORS.deepBlue, true, 11);
    ws.getCell(1, 1).fill = excelFill(EXECUTION_COLORS.silver);
    ws.getCell(1, 1).font = excelFont(EXECUTION_COLORS.text, true, 14);
    ws.getRow(1).height = 28;
    styleExcelHeader(ws.addRow(['Item', 'Sold Qty', 'Current Stock', 'Average', 'Contribution %', 'Move IN/OUT', 'Refill', 'Status']), 'D9E2EC');
    ws.views = [{ showGridLines: true, state: 'frozen', xSplit: 1, ySplit: 5 }];
    weights.forEach((w) => {
      const c = report.matrix.cells[branch]?.[w];
      const sold = Number(c?.sold ?? 0);
      const stock = Number(c?.stock ?? 0);
      const avg = c?.sales3M ? Math.round(Number(c.sales3M) / 3) : Math.round(sold / 3);
      const net = Number(c?.netMove ?? 0);
      const refillQty = Math.max(0, avg - stock);
      const r = ws.addRow([w, sold, stock, avg, `${sold > 0 ? Math.round((sold / Math.max(1, sold + stock)) * 100) : 0}%`, net, refillQty, net > 0 ? 'Move In' : net < 0 ? 'Move Out' : refillQty > 0 ? 'Refill' : 'Balanced']);
      styleExcelBody(r);
      styleMovementCell(r.getCell(6), net);
      if (refillQty > 0) {
        r.getCell(7).font = excelFont(EXECUTION_COLORS.gold, true);
        r.getCell(7).fill = excelFill('FFF4CC');
      }
    });
    [28, 14, 18, 14, 16, 16, 12, 18].forEach((w, i) => ws.getColumn(i + 1).width = w);
    applyGlobalSheetFill(ws);
  }
  return (await wb.xlsx.writeBuffer()) as ArrayBuffer;
}

export async function exportExecutionExcelReport(report: RedistributionReport, mode: ExecutionMode): Promise<void> {
  const filename = `DiaMatrix_${executionModeLabel(mode).replace(/\s+/g, '_')}_Execution_Report.xlsx`;
  try {
    const buffer = await buildExecutionExcelWorkbook(report, mode);
    downloadBlob(new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }), filename);
  } catch (error) {
    console.error('ExcelJS execution export failed:', error);
    window.alert(`Excel export failed: ${error instanceof Error ? error.message : 'Please try again.'}`);
  }
}

function pdfPageHeader(doc: jsPDF, title: string, period: string, pageNo: number, totalPages: number) {
  doc.setFillColor(10, 15, 29); doc.rect(0, 0, 297, 18, 'F'); doc.setTextColor(255, 255, 255); doc.setFont('helvetica', 'bold'); doc.setFontSize(12); doc.text(title, 10, 11); doc.setFont('helvetica', 'normal'); doc.setFontSize(7.5); doc.text(`${period || 'Current period'} · Page ${pageNo} / ${totalPages}`, 287, 11, { align: 'right' });
}
function pdfCell(doc: jsPDF, text: string, x: number, y: number, w: number, h: number, opts: { fill?: [number, number, number]; text?: [number, number, number]; bold?: boolean } = {}) {
  if (opts.fill) { doc.setFillColor(...opts.fill); doc.rect(x, y, w, h, 'F'); } doc.setDrawColor(190, 205, 218); doc.rect(x, y, w, h); doc.setTextColor(...(opts.text || [20, 33, 61])); doc.setFont('helvetica', opts.bold ? 'bold' : 'normal'); doc.setFontSize(7); const lines = doc.splitTextToSize(String(text ?? ''), Math.max(5, w - 4)); doc.text(lines.slice(0, 2), x + 2, y + 5);
}

export async function exportExecutionPdfReport(report: RedistributionReport, mode: ExecutionMode): Promise<void> {
  const filename = `DiaMatrix_${executionModeLabel(mode).replace(/\s+/g, '_')}_Execution_Report.pdf`;
  const source = document.querySelector<HTMLElement>('[data-dmx-report-print-root=\"true\"]');
  if (!source) {
    // If the detailed report view is not mounted, use the reliable print route.
    printExecutionReport(report, mode);
    return;
  }

  const clone = source.cloneNode(true) as HTMLElement;
  clone.querySelectorAll<HTMLElement>('.dmx-print-hide, button, [role=\"button\"]').forEach((el) => el.remove());
  clone.querySelectorAll<HTMLElement>('.overflow-auto, .overflow-x-auto, .overflow-y-auto').forEach((el) => {
    el.style.overflow = 'visible';
    el.style.maxHeight = 'none';
    el.style.height = 'auto';
  });
  clone.querySelectorAll<HTMLElement>('[style*=\"position: sticky\"], .sticky').forEach((el) => { el.style.position = 'static'; });
  clone.style.cssText = 'position:fixed;left:-100000px;top:0;width:794px;max-width:none;background:#fff;color:#14213D;padding:0;margin:0;';

  const host = document.createElement('div');
  host.style.cssText = 'position:fixed;left:-100000px;top:0;width:794px;background:#fff;z-index:-1;';
  host.appendChild(clone);
  document.body.appendChild(host);

  try {
    await new Promise<void>((resolve) => requestAnimationFrame(() => requestAnimationFrame(() => resolve())));
    const canvas = await html2canvas(clone, {
      scale: Math.min(2, window.devicePixelRatio || 1.5),
      backgroundColor: '#ffffff',
      useCORS: true,
      logging: false,
      windowWidth: 794,
      scrollX: 0,
      scrollY: 0,
    });
    const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
    const pageWidth = 210;
    const pageHeight = 297;
    const margin = 8;
    const usableWidth = pageWidth - margin * 2;
    const imgWidth = usableWidth;
    const imgHeight = (canvas.height * imgWidth) / canvas.width;
    const image = canvas.toDataURL('image/png');
    if (imgHeight <= pageHeight - margin * 2) {
      doc.addImage(image, 'PNG', margin, margin, imgWidth, imgHeight);
    } else {
      // Slice the actual UI image into A4-height pages, preserving the same on-screen design.
      const pagePxHeight = Math.floor(canvas.width * ((pageHeight - margin * 2) / usableWidth));
      let offset = 0;
      let page = 0;
      while (offset < canvas.height) {
        const slice = document.createElement('canvas');
        slice.width = canvas.width;
        slice.height = Math.min(pagePxHeight, canvas.height - offset);
        const ctx = slice.getContext('2d');
        if (!ctx) throw new Error('Unable to create PDF canvas.');
        ctx.fillStyle = '#fff';
        ctx.fillRect(0, 0, slice.width, slice.height);
        ctx.drawImage(canvas, 0, offset, canvas.width, slice.height, 0, 0, canvas.width, slice.height);
        if (page > 0) doc.addPage('a4', 'portrait');
        const sliceHeight = (slice.height * imgWidth) / slice.width;
        doc.addImage(slice.toDataURL('image/png'), 'PNG', margin, margin, imgWidth, sliceHeight);
        offset += slice.height;
        page += 1;
      }
    }
    doc.save(filename);
  } finally {
    host.remove();
  }
}

export function printExecutionReport(_report: RedistributionReport, _mode: ExecutionMode): void {
  // Print the actual on-screen report root — layout preserved via print.css
  printDomReportRoot(
    document.querySelector('[data-dmx-report-print-root="true"]') as HTMLElement | null,
  );
}

export function printExecutionReportHtml(report: RedistributionReport, mode: ExecutionMode): void {
  const branches = (report.matrix?.branches || []).filter((b) => b && !isOnlineBranch(b) && !isExcludedOutlet(b));
  const pages = branches
    .map((branch) => {
      const rows = (report.matrix?.weights || [])
        .map((w) => {
          const c = report.matrix.cells[branch]?.[w];
          const net = Number(c?.netMove ?? 0);
          const avg = c?.sales3M
            ? Math.round(Number(c.sales3M) / 3)
            : Math.round(Number(c?.sold ?? 0) / 3);
          const moveClass = net > 0 ? 'move-in' : net < 0 ? 'move-out' : '';
          return `<tr>
            <td>${esc(w)}</td>
            <td class="num">${Number(c?.sold ?? 0)}</td>
            <td class="num">${Number(c?.stock ?? 0)}</td>
            <td class="num">${avg}</td>
            <td class="num ${moveClass}">${net > 0 ? '+' : ''}${net}</td>
            <td class="num">${Math.max(0, avg - Number(c?.stock ?? 0))}</td>
          </tr>`;
        })
        .join('');
      return `<section class="dmx-outlet-page" data-dmx-outlet-page="true">
        <h2>${esc(executionModeLabel(mode))} — ${esc(getBranchDisplayName(branch))}</h2>
        <div class="dmx-meta">${esc(report.period || '')}</div>
        <table>
          <thead>
            <tr>
              <th>Item</th>
              <th class="num">Sold</th>
              <th class="num">Stock</th>
              <th class="num">Average</th>
              <th class="num">Move IN/OUT</th>
              <th class="num">Refill</th>
            </tr>
          </thead>
          <tbody>${rows}</tbody>
        </table>
      </section>`;
    })
    .join('');
  const html = buildPrintableDocumentHtml(executionModeLabel(mode), pages);
  const w = window.open('', '_blank');
  if (!w) return;
  w.document.write(html);
  w.document.close();
  w.focus();
  setTimeout(() => w.print(), 350);
}

/* --------------------------------------------------------------------------
 * Shared styled-rows engine: UI handlers pass rows here; all styling,
 * gridlines, Move IN / Overstock fills, logo + date-range header,
 * 3D bevel look and freeze panes live here.
 * -------------------------------------------------------------------------- */
export type StyledRowsSheet = {
  name: string;
  title: string;
  /** Date range shown top-right, e.g. "01-03-2026 to 19-09-2026" */
  period?: string;
  /** Header rows (1+), rendered with header styling */
  headerRows: (string | number | null | undefined)[][];
  /** Body rows */
  rows: (string | number | null | undefined)[][];
  /** Merge ranges [r1,c1,r2,c2]; r is relative to first header row (1-based) */
  headerMerges?: [number, number, number, number][];
  /** 1-based column indexes holding numeric net-move values (green/orange) */
  movementCols?: number[];
  /** 1-based column indexes holding refill demand (gold when > 0) */
  refillCols?: number[];
  /** Branch column groups (1-based start column + span) — coloured differently so branches are easy to tell apart */
  branchGroups?: { startCol: number; span: number }[];
  /** Distribution mode shown in the header, e.g. 'Sales Contribution' */
  modeLabel?: string;
  /** 'emerald' = emerald-green headers (distribution / design-wise files). Default alternates blue/teal per branch. */
  theme?: 'default' | 'emerald';
  /** Number of left columns kept frozen (item / design / DWL). Default 1 */
  freezeCols?: number;
  columnWidths?: number[];
};

const GROUP_HEADER = ['D0E4F5', 'C8E8E4'];
const GROUP_TINT = ['F5FAFF', 'F2FAF8'];
const EMERALD_HEADER = ['C6EFCE', 'B8E6C8'];
const EMERALD_TINT = ['F0FBF4', 'F5FCF8'];

/** Logo is 900x194 (4.64:1) — keep aspect ratio inside the 42pt header row. */
function placeLogo(ws: any, imageId: number) {
  ws.addImage(imageId, { tl: { col: 0.1, row: 0.12 }, ext: { width: 226, height: 49 } });
}
const LOGO_CACHE = new WeakMap<object, number | null>();
/** Embed the logo once per workbook and reuse the id on every sheet (keeps file size small). */
async function getWorkbookLogoId(wb: any): Promise<number | null> {
  if (LOGO_CACHE.has(wb)) return LOGO_CACHE.get(wb) ?? null;
  const id = await loadLogoId(wb);
  LOGO_CACHE.set(wb, id);
  return id;
}

async function loadLogoId(wb: any): Promise<number | null> {
  try {
    const res = await fetch('/diamatrix-logo-full.png'); // same logo as the app header: DiaMatrix by Diamond World LTD
    if (!res.ok) return null;
    return wb.addImage({ buffer: await res.arrayBuffer(), extension: 'png' });
  } catch {
    return null; // logo is optional
  }
}

function writeStyledRowsSheet(wb: any, logoId: number | null, sheet: StyledRowsSheet): any {
  const ws = createSheet(wb, sheet.name.slice(0, 31) || 'Report');
  setupExcelSheet(ws);
  const colCount = Math.max(8, ...sheet.headerRows.map((r) => r.length), ...sheet.rows.map((r) => r.length));
  const period = sheet.period || DEFAULT_DATE_RANGE;
  const emerald = sheet.theme === 'emerald';
  const hdrColors = emerald ? EMERALD_HEADER : GROUP_HEADER;
  const tints = emerald ? EMERALD_TINT : GROUP_TINT;
  const baseHeader = emerald ? 'C6EFCE' : 'D9E2EC';

  // Row 1: logo (top-left) · title · date range (top-right)
  ws.getRow(1).height = 42;
  const dateSpan = colCount <= 10 ? 2 : 3; // narrow sheets: give the title more room
  ws.mergeCells(1, 1, 1, 3);
  ws.mergeCells(1, 4, 1, colCount - dateSpan);
  ws.mergeCells(1, colCount - dateSpan + 1, 1, colCount);
  const title = ws.getCell(1, 4);
  title.value = sheet.title;
  title.font = excelFont(EXECUTION_COLORS.text, true, 16);
  title.alignment = { horizontal: 'left', vertical: 'middle' };
  const date = ws.getCell(1, colCount - dateSpan + 1);
  date.value = period;
  date.font = excelFont(EXECUTION_COLORS.text, true, 12);
  date.alignment = { horizontal: 'right', vertical: 'middle' };
  ws.getRow(1).eachCell((c: any) => { c.fill = excelFill(EXECUTION_COLORS.silver); c.border = bevelBorder('FFFFFF', '8A94A3', 'medium'); });
  if (logoId != null) placeLogo(ws, logoId);

  ws.mergeCells(2, 1, 2, colCount);
  ws.getCell(2, 1).value = `${sheet.modeLabel ? `Distribution Mode: ${sheet.modeLabel} · ` : ''}Period: ${period} · Generated: ${new Date().toLocaleString()}`;
  ws.getCell(2, 1).font = excelFont(EXECUTION_COLORS.deepBlue, true, 11);
  ws.getCell(2, 1).fill = excelFill(EXECUTION_COLORS.ice);
  ws.mergeCells(3, 1, 3, colCount);
  ws.getCell(3, 1).value = 'Soft green = Move IN · Soft pink = Move OUT / Overstock · Gold = Refill / shortage · Print-friendly colours';
  ws.getCell(3, 1).font = excelFont(EXECUTION_COLORS.text, true, 10);
  ws.getCell(3, 1).fill = excelFill('FFFFFF');
  ws.getRow(2).height = 20;
  ws.getRow(3).height = 18;

  // Header rows (branch names row + metric row)
  const headerStart = ws.rowCount + 1;
  const groups = sheet.branchGroups || [];
  sheet.headerRows.forEach((h) => {
    const r = ws.addRow(h.map((v) => v ?? ''));
    styleExcelHeader(r, baseHeader);
    groups.forEach((g, gi) => {
      for (let c = g.startCol; c < g.startCol + g.span; c++) paintHeaderCell(r.getCell(c), hdrColors[gi % 2]);
    });
  });
  (sheet.headerMerges || []).forEach(([r1, c1, r2, c2]) => ws.mergeCells(headerStart + r1 - 1, c1, headerStart + r2 - 1, c2));
  const headerEnd = headerStart + sheet.headerRows.length - 1;

  sheet.rows.forEach((values) => {
    const row = ws.addRow(values.map((v) => v ?? ''));
    styleExcelBody(row);
    groups.forEach((g, gi) => {
      for (let c = g.startCol; c < g.startCol + g.span; c++) {
        const cell = row.getCell(c);
        // Light group tint + ALWAYS bold black text (never same as background)
        const tint = tints[gi % 2];
        cell.fill = excelFill(tint);
        cell.font = excelFont('000000', true, 12);
        if (c === g.startCol) {
          cell.border = {
            ...bevelBorder('FFFFFF', '8FA1B8'),
            left: { style: 'medium', color: { argb: emerald ? 'FF047857' : 'FF0F4C81' } },
          };
        }
      }
    });
    (sheet.movementCols || []).forEach((col) => {
      const raw = Number(values[col - 1]);
      if (values[col - 1] !== '' && Number.isFinite(raw)) styleMovementCell(row.getCell(col), raw);
    });
    (sheet.refillCols || []).forEach((col) => {
      if (Number(values[col - 1]) > 0) {
        const c = row.getCell(col);
        c.fill = excelFill('FFF4CC'); // light gold
        c.font = excelFont('000000', true, 12); // black bold on gold
      }
    });
  });

  for (let i = 1; i <= colCount; i++) ws.getColumn(i).width = sheet.columnWidths?.[i - 1] ?? (i <= 3 ? 18 : 14);
  // Freeze everything down to (and including) the branch/metric header rows, plus the left item columns.
  ws.views = [{ showGridLines: true, state: 'frozen', xSplit: sheet.freezeCols ?? 1, ySplit: headerEnd }];
  ws.autoFilter = { from: { row: headerEnd, column: 1 }, to: { row: Math.max(headerEnd, ws.rowCount), column: colCount } };
  applyGlobalSheetFill(ws);
  return ws;
}

export async function exportStyledRowsExcel(sheets: StyledRowsSheet[], filename: string): Promise<void> {
  const wb = new ExcelJS.Workbook();
  wb.creator = 'DiaMatrix';
  wb.company = 'DiaMatrix';
  const logoId = await getWorkbookLogoId(wb);
  for (const sheet of sheets) writeStyledRowsSheet(wb, logoId, sheet);
  const buffer = await wb.xlsx.writeBuffer();
  downloadBlob(new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }), filename);
}

/* --------------------------------------------------------------------------
 * File 1: distribution_now.xlsx — one customised sheet per outlet
 * -------------------------------------------------------------------------- */
export type DistributionModeKey = 'contribution' | 'baseline' | 'hybrid' | 'liquidity' | 'demand_backup' | 'coverage';
export function distributionModeLabel(mode: string): string {
  return mode === 'baseline' ? '3-Month Baseline'
    : mode === 'hybrid' ? 'Hybrid (Contribution vs 3-Month Baseline)'
    : mode === 'liquidity' ? 'Capital Liquidity (Aging)'
    : mode === 'demand_backup' ? 'Demand-Backup & Safety'
    : mode === 'coverage' ? 'Universal Coverage'
    : 'Sales Contribution';
}
export async function exportDistributionNowExcel(report: RedistributionReport, mode: DistributionModeKey | string = 'contribution'): Promise<void> {
  const modeLabel = distributionModeLabel(mode);
  const wb = new ExcelJS.Workbook();
  wb.creator = 'DiaMatrix';
  wb.company = 'DiaMatrix';
  const logoId = await getWorkbookLogoId(wb);
  const branches = (report.matrix?.branches || []).filter(
    (b) => b !== 'WHL' && !isWarehouseBranchCode(b) && !isOnlineBranch(b) && !isExcludedOutlet(b),
  );
  const weights = report.matrix?.weights || [];
  if (!branches.length) throw new Error('No outlet data found to export.');

  // Loop: one worksheet (addWorksheet via createSheet) per outlet, e.g. Bashundhara City
  for (const branch of branches) {
    const name = getBranchDisplayName(branch);
    const rows = weights.map((w) => {
      const c = report.matrix.cells[branch]?.[w];
      const sold = Number(c?.sold ?? 0);
      const stock = Number(c?.stock ?? 0);
      const avg = c?.sales3M ? Math.round(Number(c.sales3M) / 3) : Math.round(sold / 3);
      const net = Number(c?.netMove ?? 0);
      const refill = Math.max(0, avg - stock);
      const status = net > 0 ? 'Move IN' : net < 0 ? 'Overstock' : refill > 0 ? 'Refill' : 'Balanced';
      const contrib = sold + stock > 0 ? `${Math.round((sold / Math.max(1, sold + stock)) * 100)}%` : '0%';
      return [w, sold, stock, avg, contrib, net, refill, status] as (string | number)[];
    });
    writeStyledRowsSheet(wb, logoId, {
      name,
      title: `Distribution — ${name} · ${modeLabel.split(' (')[0]}`,
      period: report.period,
      modeLabel,
      theme: 'emerald',
      headerRows: [['Item', 'Sold Qty', 'Current Stock', 'Average', 'Contribution %', 'Move IN/OUT', 'Refill', 'Status']],
      rows,
      movementCols: [6],
      refillCols: [7],
      freezeCols: 1,
      columnWidths: [26, 14, 16, 14, 16, 16, 12, 16],
    });
  }
  const buffer = await wb.xlsx.writeBuffer();
  downloadBlob(new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }), 'distribution_now.xlsx');
}

/* --------------------------------------------------------------------------
 * File 2: design_wise_stock_analysis.xlsx — grouped by design / Item_Code, matrix layout
 * -------------------------------------------------------------------------- */
export type DesignWiseExportRow = {
  carat: string;
  stock: number;
  sold: number;
  refill: number;
  byOutlet: Record<string, { stock: number; sold: number; moveIn: number; moveOut: number; netMove: number }>;
};
export type DesignWiseExportGroup = { design: string; rows: DesignWiseExportRow[] };

export async function exportDesignWiseStockExcel(
  groups: DesignWiseExportGroup[],
  outlets: string[],
  period: string | undefined,
  dimensionLabel = 'Carat'
): Promise<void> {
  if (!groups.length) throw new Error('No design data found to export.');
  const wb = new ExcelJS.Workbook();
  wb.creator = 'DiaMatrix';
  wb.company = 'DiaMatrix';
  const logoId = await getWorkbookLogoId(wb);
  const lead = 5; // Design (Item_Code) · dimension · Total Stock · Total Sold · Refill
  const row1: string[] = ['Design (Item_Code)', dimensionLabel, 'Total Stock', 'Total Sold', 'Refill Demand'];
  outlets.forEach((o) => row1.push(getBranchDisplayName(o), '', ''));
  const row2: string[] = ['', '', '', '', ''];
  outlets.forEach(() => row2.push('Stock', 'Sold', 'Move IN/OUT'));
  const headerMerges: [number, number, number, number][] = [];
  for (let c = 1; c <= lead; c++) headerMerges.push([1, c, 2, c]);
  const branchGroups: { startCol: number; span: number }[] = [];
  outlets.forEach((_, i) => { const start = lead + i * 3 + 1; headerMerges.push([1, start, 1, start + 2]); branchGroups.push({ startCol: start, span: 3 }); });

  const rows: (string | number)[][] = [];
  groups.forEach((g) => {
    let tStock = 0; let tSold = 0; let tRefill = 0;
    const outletTotals: Record<string, { stock: number; sold: number; net: number }> = {};
    g.rows.forEach((r) => {
      const values: (string | number)[] = [g.design, r.carat, Math.round(r.stock), Math.round(r.sold), Math.round(r.refill)];
      outlets.forEach((o) => {
        const c = r.byOutlet[o] || { stock: 0, sold: 0, moveIn: 0, moveOut: 0, netMove: 0 };
        const net = c.netMove !== 0 ? c.netMove : c.moveIn - c.moveOut;
        values.push(Math.round(c.stock), Math.round(c.sold), net);
        const t = outletTotals[o] || (outletTotals[o] = { stock: 0, sold: 0, net: 0 });
        t.stock += c.stock; t.sold += c.sold; t.net += net;
      });
      tStock += r.stock; tSold += r.sold; tRefill += r.refill;
      rows.push(values);
    });
    const total: (string | number)[] = [`TOTAL ${g.design}`, '', Math.round(tStock), Math.round(tSold), Math.round(tRefill)];
    outlets.forEach((o) => { const t = outletTotals[o] || { stock: 0, sold: 0, net: 0 }; total.push(Math.round(t.stock), Math.round(t.sold), t.net); });
    rows.push(total);
  });

  writeStyledRowsSheet(wb, logoId, {
    name: 'Design Wise Stock',
    title: 'Design Wise Stock Analysis',
    period,
    theme: 'emerald',
    headerRows: [row1, row2],
    headerMerges,
    rows,
    movementCols: outlets.map((_, i) => lead + i * 3 + 3),
    refillCols: [5],
    branchGroups,
    freezeCols: 2,
    columnWidths: [24, 12, 13, 13, 15],
  });
  const buffer = await wb.xlsx.writeBuffer();
  downloadBlob(new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }), 'design_wise_stock_analysis.xlsx');
}
