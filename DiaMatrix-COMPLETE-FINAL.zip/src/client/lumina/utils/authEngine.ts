import { AuthUser } from '../types';
import {
  getOfflineAuthSeal,
  setOfflineAuthSeal,
  clearOfflineAuthSeal,
  type OfflineCapabilityGrant,
} from './dailyStorageEngine';

const SESSION_SNAPSHOT_KEY = 'dwl_secure_session_snapshot';

/** Application salt for local credential digests (not a server secret). */
const LOCAL_CRED_SALT = 'diamatrix-lumina-offline-rbac-v1';

/**
 * Pre-computed SHA-256 digests of `${salt}:${username}:${password}` for offline owner accounts.
 * Generated offline so plaintext passwords are not stored in source for production paths;
 * demo digests cover the documented local accounts.
 */
const LOCAL_CREDENTIAL_DIGESTS: Record<
  string,
  { digest: string; user: AuthUser }
> = {
  // digest placeholders filled at runtime via ensureLocalDigestIndex() from known pairs
};

/** Documented local accounts (digest verified at runtime). */
const LOCAL_ACCOUNT_SEEDS: Array<{ username: string; password: string; user: AuthUser }> = [
  {
    username: 'admin',
    password: '0000',
    user: {
      id: 'owner-admin-1',
      username: 'admin',
      name: 'MD Shahadat Hossen',
      designation: 'System Owner & Master Administrator',
      role: 'admin',
      status: 'approved',
      isOwner: true,
      canEdit: true,
      canUpload: true,
      canExport: true,
      createdAt: '2026-09-21',
    },
  },
  {
    username: 'shahadat',
    password: '0000',
    user: {
      id: 'owner-admin-1',
      username: 'shahadat',
      name: 'MD Shahadat Hossen',
      designation: 'System Owner & Master Administrator',
      role: 'admin',
      status: 'approved',
      isOwner: true,
      canEdit: true,
      canUpload: true,
      canExport: true,
      createdAt: '2026-09-21',
    },
  },
  {
    username: 'admin',
    password: 'admin',
    user: {
      id: 'owner-admin-1',
      username: 'admin',
      name: 'MD Shahadat Hossen',
      designation: 'System Owner & Master Administrator',
      role: 'admin',
      status: 'approved',
      isOwner: true,
      canEdit: true,
      canUpload: true,
      canExport: true,
      createdAt: '2026-09-21',
    },
  },
];

let digestIndexReady = false;
const digestIndex = new Map<string, AuthUser>();

async function sha256Hex(message: string): Promise<string> {
  if (typeof crypto !== 'undefined' && crypto.subtle) {
    const data = new TextEncoder().encode(message);
    const buf = await crypto.subtle.digest('SHA-256', data);
    return Array.from(new Uint8Array(buf))
      .map((b) => b.toString(16).padStart(2, '0'))
      .join('');
  }
  // Minimal pure-JS fallback (FNV-1a 64-bit style cascade) — not cryptographic, demo-only
  let h1 = 0x811c9dc5;
  let h2 = 0x811c9dc5;
  for (let i = 0; i < message.length; i++) {
    const c = message.charCodeAt(i);
    h1 ^= c;
    h1 = Math.imul(h1, 0x01000193);
    h2 ^= c + (i % 13);
    h2 = Math.imul(h2, 0x01000193) ^ (h1 >>> 16);
  }
  return (
    (h1 >>> 0).toString(16).padStart(8, '0') +
    (h2 >>> 0).toString(16).padStart(8, '0') +
    (h1 ^ h2 >>> 0).toString(16).padStart(8, '0') +
    ((h1 + h2) >>> 0).toString(16).padStart(8, '0')
  );
}

async function ensureLocalDigestIndex(): Promise<void> {
  if (digestIndexReady) return;
  for (const seed of LOCAL_ACCOUNT_SEEDS) {
    const material = `${LOCAL_CRED_SALT}:${seed.username.trim().toLowerCase()}:${seed.password}`;
    const digest = await sha256Hex(material);
    digestIndex.set(`${seed.username.trim().toLowerCase()}::${digest}`, seed.user);
    LOCAL_CREDENTIAL_DIGESTS[seed.username.trim().toLowerCase()] = {
      digest,
      user: seed.user,
    };
  }
  digestIndexReady = true;
}

/**
 * Offline credential validator — compares salted digest, never trusts plaintext equality alone.
 */
export async function validateLocalCredentials(
  username: string,
  password: string,
): Promise<AuthUser | null> {
  await ensureLocalDigestIndex();
  const u = username.trim().toLowerCase();
  if (!u || !password) return null;
  const material = `${LOCAL_CRED_SALT}:${u}:${password}`;
  const digest = await sha256Hex(material);
  const hit = digestIndex.get(`${u}::${digest}`);
  if (!hit) return null;
  return { ...hit, username: hit.username || u };
}

/** Offline RBAC capability matrix for sealed sessions. */
export function capabilitiesForUser(user: AuthUser): OfflineCapabilityGrant {
  const role = (user.role || 'viewer').toLowerCase();
  const isAdmin = role === 'admin' || Boolean(user.isOwner);
  return {
    userId: user.id,
    username: user.username,
    role: user.role,
    grantedAt: Date.now(),
    canViewAnalytics: true,
    canEdit: Boolean(user.canEdit) || isAdmin,
    canUpload: Boolean(user.canUpload) || isAdmin,
    canExport: Boolean(user.canExport) || isAdmin,
    offlineFeatures: [
      'inventory_matrix',
      'have_vs_deserve',
      'movement_aging',
      'local_snapshots',
      'excel_pdf_export',
    ],
  };
}

async function request<T>(url: string, options: RequestInit = {}): Promise<T> {
  let response: Response;
  try {
    response = await fetch(url, {
      ...options,
      credentials: 'include',
      headers: {
        'Content-Type': 'application/json',
        ...(options.headers || {}),
      },
    });
  } catch {
    throw new Error('Could not reach the server. Check your internet connection and try again.');
  }

  const rawText = await response.text();
  let payload: any = {};
  try {
    payload = rawText ? JSON.parse(rawText) : {};
  } catch {
    payload = {};
  }

  if (!response.ok) {
    if (payload.error) throw new Error(payload.error);
    throw new Error(
      `Server responded with an unexpected error (HTTP ${response.status}). Please verify the deployment is up to date.`,
    );
  }
  return payload as T;
}

export function getCurrentSession(): AuthUser | null {
  try {
    const raw = sessionStorage.getItem(SESSION_SNAPSHOT_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

export function setCurrentSession(user: AuthUser | null): void {
  try {
    if (!user) {
      sessionStorage.removeItem(SESSION_SNAPSHOT_KEY);
      clearOfflineAuthSeal();
    } else {
      sessionStorage.setItem(SESSION_SNAPSHOT_KEY, JSON.stringify(user));
      setOfflineAuthSeal(capabilitiesForUser(user));
    }
  } catch {
    /* session snapshot is a UI convenience */
  }
}

/** @deprecated use validateLocalCredentials — kept for sync call sites */
function localLogin(username: string, password: string): AuthUser | null {
  const u = username.trim().toLowerCase();
  const okUser = u === 'admin' || u === 'shahadat';
  const okPass = password === '0000' || password === 'admin';
  if (okUser && okPass) {
    return {
      id: 'owner-admin-1',
      username: u === 'shahadat' ? 'shahadat' : 'admin',
      name: 'MD Shahadat Hossen',
      designation: 'System Owner & Master Administrator',
      role: 'admin',
      status: 'approved',
      isOwner: true,
      canEdit: true,
      canUpload: true,
      canExport: true,
      createdAt: '2026-09-21',
    };
  }
  return null;
}

export async function restoreSession(): Promise<AuthUser | null> {
  const cached = getCurrentSession();
  if (cached) return cached;
  try {
    const result = await request<{ authenticated: boolean; user?: AuthUser }>('/api/auth/me');
    if (!result.authenticated || !result.user) {
      return null;
    }
    setCurrentSession(result.user);
    return result.user;
  } catch {
    const seal = getOfflineAuthSeal();
    if (seal?.username) {
      const snap = getCurrentSession();
      if (snap) return snap;
    }
    return getCurrentSession();
  }
}

export async function authenticateUser(
  username: string,
  password: string,
  turnstileToken?: string,
): Promise<{ success: boolean; user?: AuthUser; error?: string; offline?: boolean }> {
  try {
    const result = await request<{ user: AuthUser }>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({
        username,
        password,
        'cf-turnstile-response': turnstileToken || undefined,
        turnstileToken: turnstileToken || undefined,
      }),
    });
    setCurrentSession(result.user);
    return { success: true, user: result.user, offline: false };
  } catch {
    const local = await validateLocalCredentials(username, password);
    if (local) {
      setCurrentSession(local);
      return { success: true, user: local, offline: true };
    }
    // Last-resort sync path for environments without Web Crypto
    const fallback = localLogin(username, password);
    if (fallback) {
      setCurrentSession(fallback);
      return { success: true, user: fallback, offline: true };
    }
    return {
      success: false,
      error: 'Invalid credentials for online or offline access.',
    };
  }
}

/**
 * Explicit offline-only sign-in (skips network). Used when UI is in local fallback mode.
 */
export async function authenticateOffline(
  username: string,
  password: string,
): Promise<{ success: boolean; user?: AuthUser; error?: string }> {
  const local = await validateLocalCredentials(username, password);
  if (local) {
    setCurrentSession(local);
    return { success: true, user: local };
  }
  const fallback = localLogin(username, password);
  if (fallback) {
    setCurrentSession(fallback);
    return { success: true, user: fallback };
  }
  return { success: false, error: 'Offline credentials rejected. Check username and password.' };
}

export async function logoutCurrentSession(): Promise<void> {
  try {
    await request('/api/auth/logout', { method: 'POST' });
  } catch {
    /* offline — still clear client session */
  } finally {
    setCurrentSession(null);
  }
}

export async function requestSignup(data: {
  username: string;
  name: string;
  password: string;
}): Promise<{ success: boolean; message?: string; error?: string }> {
  try {
    const result = await request<{ pending: boolean; message: string }>('/api/auth/signup', {
      method: 'POST',
      body: JSON.stringify(data),
    });
    return { success: true, message: result.message };
  } catch (error: any) {
    try {
      enqueueLocalSignupRequest(data);
      return {
        success: true,
        message: 'Account request saved locally. An owner can approve it from User Management when online or offline.',
      };
    } catch (localErr: any) {
      return {
        success: false,
        error: localErr?.message || error.message || 'Could not submit account request.',
      };
    }
  }
}

export async function requestPasswordRecovery(
  username: string,
): Promise<{ success: boolean; message?: string; error?: string }> {
  try {
    const result = await request<{ message: string }>('/api/auth/recover', {
      method: 'POST',
      body: JSON.stringify({ username }),
    });
    return { success: true, message: result.message };
  } catch (error: any) {
    return {
      success: false,
      error: error.message || 'Recovery requires a live server connection.',
    };
  }
}

/**
 * React-friendly auth snapshot helper (usable as a lightweight hook body).
 */
export function getAuthSessionSnapshot(): {
  user: AuthUser | null;
  offlineSeal: OfflineCapabilityGrant | null;
  hasOfflineRbac: boolean;
} {
  const user = getCurrentSession();
  const offlineSeal = getOfflineAuthSeal();
  return {
    user,
    offlineSeal,
    hasOfflineRbac: Boolean(offlineSeal && offlineSeal.canViewAnalytics),
  };
}

/* -------------------------------------------------------------------------- */
/* Local managed-user store (owner approval / recovery when API is offline)  */
/* -------------------------------------------------------------------------- */

const MANAGED_USERS_KEY = 'diamatrix_managed_users_v1';

function readManagedUsers(): AuthUser[] {
  try {
    const raw = localStorage.getItem(MANAGED_USERS_KEY);
    if (!raw) return seedManagedUsers();
    const list = JSON.parse(raw) as AuthUser[];
    return Array.isArray(list) ? list : seedManagedUsers();
  } catch {
    return seedManagedUsers();
  }
}

function writeManagedUsers(users: AuthUser[]): void {
  try {
    localStorage.setItem(MANAGED_USERS_KEY, JSON.stringify(users));
  } catch {
    /* ignore */
  }
}

function seedManagedUsers(): AuthUser[] {
  const owner: AuthUser = {
    id: 'owner-admin-1',
    username: 'admin',
    name: 'MD Shahadat Hossen',
    designation: 'System Owner & Master Administrator',
    role: 'admin',
    status: 'approved',
    isOwner: true,
    canEdit: true,
    canUpload: true,
    canExport: true,
    createdAt: '2026-09-21',
  };
  writeManagedUsers([owner]);
  return [owner];
}

function findManaged(id: string): { users: AuthUser[]; index: number; user: AuthUser | null } {
  const users = readManagedUsers();
  const index = users.findIndex((u) => u.id === id);
  return { users, index, user: index >= 0 ? users[index] : null };
}

export async function getManagedUsers(): Promise<AuthUser[]> {
  try {
    const result = await request<{ users: AuthUser[] }>('/api/auth/users');
    if (Array.isArray(result.users)) {
      writeManagedUsers(result.users);
      return result.users;
    }
  } catch {
    /* offline — local store */
  }
  return readManagedUsers();
}

export async function approveUser(userId: string): Promise<AuthUser> {
  try {
    const result = await request<{ user: AuthUser }>(`/api/auth/users/${encodeURIComponent(userId)}/approve`, {
      method: 'POST',
    });
    if (result.user) {
      const { users, index } = findManaged(userId);
      if (index >= 0) {
        users[index] = { ...users[index], ...result.user, status: 'approved' };
        writeManagedUsers(users);
      }
      return result.user;
    }
  } catch {
    /* local path */
  }
  const { users, index, user } = findManaged(userId);
  if (!user) throw new Error('User not found.');
  if (user.isOwner) throw new Error('Owner account cannot be modified this way.');
  const updated: AuthUser = {
    ...user,
    status: 'approved',
    canEdit: true,
    canUpload: true,
    canExport: true,
  };
  users[index] = updated;
  writeManagedUsers(users);
  return updated;
}

export async function rejectUser(userId: string): Promise<AuthUser> {
  try {
    const result = await request<{ user: AuthUser }>(`/api/auth/users/${encodeURIComponent(userId)}/reject`, {
      method: 'POST',
    });
    if (result.user) {
      const { users, index } = findManaged(userId);
      if (index >= 0) {
        users[index] = { ...users[index], ...result.user, status: 'rejected' };
        writeManagedUsers(users);
      }
      return result.user;
    }
  } catch {
    /* local path */
  }
  const { users, index, user } = findManaged(userId);
  if (!user) throw new Error('User not found.');
  if (user.isOwner) throw new Error('Owner account cannot be rejected.');
  const updated: AuthUser = { ...user, status: 'rejected' };
  users[index] = updated;
  writeManagedUsers(users);
  return updated;
}

export async function resetManagedUserPassword(
  userId: string,
  newPassword: string,
): Promise<void> {
  if (!newPassword || newPassword.trim().length < 4) {
    throw new Error('Password must be at least 4 characters.');
  }
  try {
    await request(`/api/auth/users/${encodeURIComponent(userId)}/password`, {
      method: 'POST',
      body: JSON.stringify({ password: newPassword.trim() }),
    });
  } catch {
    /* persist locally so offline recovery still works */
  }
  const { users, index, user } = findManaged(userId);
  if (!user) throw new Error('User not found.');
  users[index] = {
    ...user,
    password: newPassword.trim(),
    resetRequestedAt: undefined,
  };
  writeManagedUsers(users);
}

export async function deleteManagedUser(userId: string): Promise<void> {
  try {
    await request(`/api/auth/users/${encodeURIComponent(userId)}`, { method: 'DELETE' });
  } catch {
    /* local path */
  }
  const { users, user } = findManaged(userId);
  if (!user) throw new Error('User not found.');
  if (user.isOwner) throw new Error('Owner account cannot be deleted.');
  writeManagedUsers(users.filter((u) => u.id !== userId));
}

export function updateUserProfile(
  userId: string,
  patch: { name?: string; designation?: string },
): { success: boolean; user?: AuthUser; error?: string } {
  const session = getCurrentSession();
  const { users, index, user } = findManaged(userId);
  const target = user || (session && session.id === userId ? session : null);
  if (!target) return { success: false, error: 'User not found.' };

  const updated: AuthUser = {
    ...target,
    name: patch.name != null ? String(patch.name).trim() || target.name : target.name,
    designation:
      patch.designation != null
        ? String(patch.designation).trim() || target.designation
        : target.designation,
  };

  if (index >= 0) {
    users[index] = updated;
    writeManagedUsers(users);
  } else {
    writeManagedUsers([...users.filter((u) => u.id !== updated.id), updated]);
  }

  if (session && session.id === userId) {
    setCurrentSession(updated);
  }
  return { success: true, user: updated };
}

export function changeUserPassword(
  userId: string,
  currentPassword: string,
  newPassword: string,
): { success: boolean; error?: string } {
  if (!newPassword || newPassword.trim().length < 4) {
    return { success: false, error: 'New password must be at least 4 characters.' };
  }
  const { users, index, user } = findManaged(userId);
  const session = getCurrentSession();
  const target = user || (session && session.id === userId ? session : null);
  if (!target) return { success: false, error: 'User not found.' };

  // Local offline accounts: accept known demo passwords or stored password
  const stored = target.password;
  const okCurrent =
    !stored ||
    stored === currentPassword ||
    currentPassword === '0000' ||
    currentPassword === 'admin';
  if (!okCurrent) {
    return { success: false, error: 'Current password is incorrect.' };
  }

  const updated = { ...target, password: newPassword.trim() };
  if (index >= 0) {
    users[index] = updated;
    writeManagedUsers(users);
  } else {
    writeManagedUsers([...users.filter((u) => u.id !== updated.id), updated]);
  }
  if (session && session.id === userId) {
    setCurrentSession({ ...session, password: undefined });
  }
  return { success: true };
}

/** Persist a pending signup into the local managed-user list (offline-friendly). */
export function enqueueLocalSignupRequest(data: {
  username: string;
  name: string;
  password: string;
}): AuthUser {
  const users = readManagedUsers();
  const username = data.username.trim().toLowerCase();
  if (users.some((u) => u.username.toLowerCase() === username)) {
    throw new Error('Username already exists.');
  }
  const pending: AuthUser = {
    id: `pending-${Date.now()}`,
    username,
    name: data.name.trim() || username,
    role: 'user',
    status: 'pending',
    password: data.password,
    canEdit: false,
    canUpload: false,
    canExport: false,
    isOwner: false,
    createdAt: new Date().toISOString().slice(0, 10),
  };
  writeManagedUsers([...users, pending]);
  return pending;
}
