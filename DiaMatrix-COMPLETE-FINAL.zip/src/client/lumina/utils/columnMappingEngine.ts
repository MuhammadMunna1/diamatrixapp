/**
 * Column Mapping Engine — Fuzzy + Synonym intelligence
 *
 * Handles manual-report header drift:
 *   Branch → Branch_Name, Store, Outlet, Showroom, Brnch, SHOP_CD …
 * Once the user maps a rare header, it is remembered forever (localStorage).
 */

export type CanonicalField =
  | 'branch'
  | 'weight'
  | 'design'
  | 'category'
  | 'sold'
  | 'stock'
  | 'ignore';

export interface CanonicalFieldDef {
  id: CanonicalField;
  label: string;
  labelBn: string;
  description: string;
  required?: boolean;
  /** Exact / substring synonyms (normalized — no spaces/underscores) */
  synonyms: string[];
}

/**
 * Rich synonym banks for jewelry ERP / Oracle / Excel exports.
 * Keep normalized forms only (lowercase, no separators).
 */
export const CANONICAL_FIELDS: CanonicalFieldDef[] = [
  {
    id: 'branch',
    label: 'Branch',
    labelBn: 'ব্রাঞ্চ / শোরুম',
    description: 'Showroom / outlet / store code',
    required: true,
    synonyms: [
      'branch', 'branchname', 'branchcode', 'branchcd', 'branchid', 'branchno',
      'brnch', 'brnchid', 'brcode', 'brname', 'br',
      'store', 'storename', 'storecode', 'storecd', 'storeid',
      'outlet', 'outletname', 'outletcode', 'outletcd', 'outletid',
      'showroom', 'showroomname', 'showroomcode',
      'shop', 'shopname', 'shopcode', 'shopcd',
      'location', 'locationname', 'loc', 'loccode', 'loccd',
      'warehouse', 'wh', 'whcode', 'depot', 'site', 'sitecode',
      'costcenter', 'costcentre', 'ccode',
      'unit', 'unitname', 'unitcode',
      'counter', 'countername',
      'place', 'area', 'region',
    ],
  },
  {
    id: 'weight',
    label: 'Weight / Carat',
    labelBn: 'ওয়েট / ক্যারেট',
    description: 'Carat, CT, size, range',
    required: true,
    synonyms: [
      'weight', 'wt', 'wts', 'netwt', 'netweight', 'grosswt',
      'carat', 'carats', 'ct', 'cts', 'crt', 'crts', 'karat', 'kt',
      'size', 'sizes', 'ringsize',
      'range', 'wtange', 'wtrange', 'caratrange', 'ctrage',
      'diamondwt', 'diawt', 'diacarat', 'caratwt', 'diamondcarat',
      'gram', 'grams', 'gm', 'gms',
    ],
  },
  {
    id: 'design',
    label: 'Design / Model / SKU',
    labelBn: 'ডিজাইন / মডেল',
    description: 'Style, model, item code',
    synonyms: [
      'design', 'designname', 'designcode', 'designno', 'designnumber', 'designo',
      'model', 'modelname', 'modelcode', 'modelno', 'modelnumber',
      'sku', 'skucode', 'skuid',
      'style', 'stylename', 'stylecode', 'styleno',
      'itemcode', 'itemcd', 'itemno', 'itemnumber', 'itemid', 'item',
      'productcode', 'productcd', 'productid', 'prodcode',
      'code', 'variant', 'variantcode', 'variantname',
      'article', 'articlecode', 'articleno',
      'partno', 'partnumber', 'partcode',
    ],
  },
  {
    id: 'category',
    label: 'Category',
    labelBn: 'ক্যাটাগরি',
    description: 'Product type / particular',
    synonyms: [
      'category', 'categoryname', 'cat', 'catname', 'catcode',
      'particular', 'particulars',
      'product', 'productname', 'producttype', 'prodtype',
      'description', 'desc', 'itemdesc', 'productdesc',
      'type', 'typename', 'itemtype',
      'group', 'groupname', 'family', 'class', 'classname',
      'segment', 'line', 'collection',
    ],
  },
  {
    id: 'sold',
    label: 'Sold Qty',
    labelBn: 'বিক্রি পরিমাণ',
    description: 'Sales / sold-out quantity',
    synonyms: [
      'sold', 'soldqty', 'soldquantity', 'soldout', 'soldoutqty',
      'sale', 'sales', 'salesqty', 'saleqty', 'salesquantity',
      'demand', 'demandqty',
      'outflow', 'outqty', 'issued', 'issueqty',
      'dispatch', 'dispatchqty',
      'billed', 'billqty', 'invoiceqty',
      'quantitysold', 'qtysold', 'pcs sold', 'pcssold',
    ],
  },
  {
    id: 'stock',
    label: 'Stock Qty',
    labelBn: 'স্টক পরিমাণ',
    description: 'Current / on-hand inventory',
    synonyms: [
      'stock', 'stockqty', 'stockquantity', 'currentstock', 'curstock',
      'inventory', 'invqty', 'inv',
      'balance', 'bal', 'balqty', 'closing', 'closingstock', 'closingqty',
      'onhand', 'onhandqty', 'ohqty', 'oh',
      'available', 'avail', 'availqty', 'availableqty',
      'qty', 'quantity', 'pcs', 'pieces', 'pc',
      'opening', 'openingstock', 'openingqty',
      'qoh', 'soh',
    ],
  },
  {
    id: 'ignore',
    label: 'Ignore column',
    labelBn: 'বাদ দিন',
    description: 'Do not import this column',
    synonyms: [],
  },
];

export type ColumnMapDict = Record<string, CanonicalField>;

const STORAGE_KEY = 'diamatrix_column_maps_v1';
const FUZZY_THRESHOLD = 0.72; // 0–1 similarity

/** Strip separators, lower-case */
export function normalizeHeader(h: string): string {
  return String(h || '')
    .trim()
    .toLowerCase()
    .replace(/[\s_#./\\-]+/g, '');
}

/** Levenshtein distance */
function levenshtein(a: string, b: string): number {
  const m = a.length;
  const n = b.length;
  if (m === 0) return n;
  if (n === 0) return m;
  const dp = new Array(n + 1);
  for (let j = 0; j <= n; j++) dp[j] = j;
  for (let i = 1; i <= m; i++) {
    let prev = dp[0];
    dp[0] = i;
    for (let j = 1; j <= n; j++) {
      const tmp = dp[j];
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      dp[j] = Math.min(dp[j] + 1, dp[j - 1] + 1, prev + cost);
      prev = tmp;
    }
  }
  return dp[n];
}

/** Similarity 0–1 (1 = identical) */
export function stringSimilarity(a: string, b: string): number {
  if (!a && !b) return 1;
  if (!a || !b) return 0;
  if (a === b) return 1;
  const maxLen = Math.max(a.length, b.length);
  if (maxLen === 0) return 1;
  return 1 - levenshtein(a, b) / maxLen;
}

export interface MatchResult {
  field: CanonicalField;
  confidence: number; // 0–1
  method: 'memory' | 'exact' | 'substring' | 'fuzzy' | 'token';
  matchedSynonym?: string;
}

/**
 * Score header against one field's synonym bank.
 */
function scoreAgainstField(normalized: string, field: CanonicalFieldDef): MatchResult | null {
  if (field.id === 'ignore' || !normalized) return null;

  let best: MatchResult | null = null;

  for (const syn of field.synonyms) {
    const s = normalizeHeader(syn);
    if (!s) continue;

    // Exact
    if (normalized === s) {
      return { field: field.id, confidence: 1, method: 'exact', matchedSynonym: syn };
    }

    // Substring either way (Branch_Name contains branch; outletcode contains outlet)
    if (normalized.includes(s) || s.includes(normalized)) {
      // Prefer longer synonym match to avoid "ct" matching everything
      const conf =
        Math.min(normalized.length, s.length) / Math.max(normalized.length, s.length);
      const boosted = Math.max(0.85, conf);
      if (!best || boosted > best.confidence) {
        best = { field: field.id, confidence: boosted, method: 'substring', matchedSynonym: syn };
      }
      continue;
    }

    // Fuzzy
    const sim = stringSimilarity(normalized, s);
    if (sim >= FUZZY_THRESHOLD) {
      if (!best || sim > best.confidence) {
        best = { field: field.id, confidence: sim, method: 'fuzzy', matchedSynonym: syn };
      }
    }
  }

  // Token overlap: branchname → tokens if we split camelCase leftovers
  // Already normalized so try common suffixes stripped
  const stripped = normalized
    .replace(/(name|code|cd|id|no|number|qty|quantity|desc|type)$/i, '');
  if (stripped && stripped !== normalized) {
    for (const syn of field.synonyms) {
      const s = normalizeHeader(syn);
      if (stripped === s || stripped.includes(s) || s.includes(stripped)) {
        const conf = 0.88;
        if (!best || conf > best.confidence) {
          best = { field: field.id, confidence: conf, method: 'token', matchedSynonym: syn };
        }
      }
    }
  }

  return best;
}

/**
 * Detect best canonical field for a header.
 * Priority: user memory → synonym/fuzzy across all fields → null
 */
export function detectFieldForHeader(
  header: string,
  stored: ColumnMapDict = getStoredColumnMaps()
): CanonicalField | null {
  const result = detectFieldWithConfidence(header, stored);
  return result && result.confidence >= 0.7 ? result.field : null;
}

export function detectFieldWithConfidence(
  header: string,
  stored: ColumnMapDict = getStoredColumnMaps()
): MatchResult | null {
  const key = normalizeHeader(header);
  if (!key) return null;

  // 1) User memory (highest priority)
  if (stored[key]) {
    return { field: stored[key], confidence: 1, method: 'memory' };
  }
  const rawKey = String(header || '').trim().toLowerCase();
  if (stored[rawKey]) {
    return { field: stored[rawKey], confidence: 1, method: 'memory' };
  }

  // 2) Score all fields; pick highest confidence (tie-break: required fields first)
  let best: MatchResult | null = null;
  for (const field of CANONICAL_FIELDS) {
    const hit = scoreAgainstField(key, field);
    if (!hit) continue;
    if (
      !best ||
      hit.confidence > best.confidence ||
      (hit.confidence === best.confidence &&
        field.required &&
        !CANONICAL_FIELDS.find((f) => f.id === best!.field)?.required)
    ) {
      best = hit;
    }
  }

  // Avoid weak "qty" / "code" / "item" stealing wrong fields when multiple match
  if (best && best.confidence < 0.7) return null;
  return best;
}

export function getStoredColumnMaps(): ColumnMapDict {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw);
    return parsed && typeof parsed === 'object' ? parsed : {};
  } catch {
    return {};
  }
}

export function saveColumnMaps(maps: ColumnMapDict): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(maps));
  } catch (e) {
    console.error('Failed to save column maps', e);
  }
}

export function rememberColumnMaps(partial: ColumnMapDict): ColumnMapDict {
  const next = { ...getStoredColumnMaps(), ...partial };
  saveColumnMaps(next);
  return next;
}

/** Auto-learn high-confidence fuzzy hits so next upload is instant */
export function autoLearnFromHeaders(headers: string[]): ColumnMapDict {
  const stored = getStoredColumnMaps();
  const learned: ColumnMapDict = {};
  for (const h of headers) {
    if (!h) continue;
    const hit = detectFieldWithConfidence(h, stored);
    if (hit && hit.method !== 'memory' && hit.confidence >= 0.9 && hit.field !== 'ignore') {
      learned[normalizeHeader(h)] = hit.field;
    }
  }
  if (Object.keys(learned).length) {
    return rememberColumnMaps(learned);
  }
  return stored;
}

export function clearColumnMaps(): void {
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch {
    /* ignore */
  }
}

export interface StructuralWarning {
  code:
    | 'MISSING_REQUIRED'
    | 'UNMAPPED_COLUMNS'
    | 'EMPTY_HEADERS'
    | 'SCHEMA_DRIFT'
    | 'AMBIGUOUS_MATCH';
  message: string;
  columns?: string[];
  severity: 'info' | 'warn' | 'error';
}

/** Columns that could not be mapped — captured for review, never crash the parse. */
export interface QuarantinedColumn {
  index: number;
  header: string;
  sampleValues: string[];
  suggestedField: CanonicalField;
}

export interface HeaderAnalysis {
  headers: string[];
  detected: (CanonicalField | null)[];
  confidences: (number | null)[];
  methods: ((MatchResult['method']) | null)[];
  unmapped: string[];
  missingRequired: CanonicalField[];
  suggestions: Record<string, CanonicalField>;
  /** Non-fatal structural findings for UI banners */
  structuralWarnings: StructuralWarning[];
  /** Unmapped columns with sample cell values for mapper UI */
  quarantined: QuarantinedColumn[];
}

export function analyzeHeaders(rawHeaders: string[]): HeaderAnalysis {
  const stored = getStoredColumnMaps();
  const headers = rawHeaders.map((h) => String(h ?? '').trim());
  const detected: (CanonicalField | null)[] = [];
  const confidences: (number | null)[] = [];
  const methods: ((MatchResult['method']) | null)[] = [];

  // First pass: detect
  const claimed = new Map<CanonicalField, { idx: number; conf: number }>();

  headers.forEach((h, i) => {
    if (!h) {
      detected.push(null);
      confidences.push(null);
      methods.push(null);
      return;
    }
    const hit = detectFieldWithConfidence(h, stored);
    if (!hit || hit.field === 'ignore') {
      detected.push(null);
      confidences.push(null);
      methods.push(null);
      return;
    }
    // Conflict: two headers map to same field → keep higher confidence
    const prev = claimed.get(hit.field);
    if (prev && prev.conf >= hit.confidence) {
      detected.push(null);
      confidences.push(hit.confidence);
      methods.push(hit.method);
      return;
    }
    if (prev) {
      detected[prev.idx] = null;
      confidences[prev.idx] = null;
      methods[prev.idx] = null;
    }
    claimed.set(hit.field, { idx: i, conf: hit.confidence });
    detected.push(hit.field);
    confidences.push(hit.confidence);
    methods.push(hit.method);
  });

  // Auto-learn strong detections
  autoLearnFromHeaders(headers);

  const used = new Set(detected.filter(Boolean) as CanonicalField[]);
  const unmapped = headers.filter((h, i) => h && !detected[i]);

  const missingRequired: CanonicalField[] = [];
  for (const f of CANONICAL_FIELDS) {
    if (f.required && !used.has(f.id)) missingRequired.push(f.id);
  }

  const suggestions: Record<string, CanonicalField> = {};
  for (const h of unmapped) {
    const low = normalizeHeader(h);
    // Soft suggestions even below threshold
    let soft: MatchResult | null = null;
    for (const field of CANONICAL_FIELDS) {
      const hit = scoreAgainstField(low, field);
      if (hit && (!soft || hit.confidence > soft.confidence)) soft = hit;
    }
    suggestions[h] = soft && soft.confidence >= 0.45 ? soft.field : 'ignore';
  }

  const structuralWarnings: StructuralWarning[] = [];
  if (headers.every((h) => !h)) {
    structuralWarnings.push({
      code: 'EMPTY_HEADERS',
      message: 'No usable column headers were detected in the first rows of the file.',
      severity: 'error',
    });
  }
  if (missingRequired.length) {
    structuralWarnings.push({
      code: 'MISSING_REQUIRED',
      message: `Required fields could not be auto-mapped: ${missingRequired.join(', ')}.`,
      columns: missingRequired,
      severity: 'warn',
    });
  }
  if (unmapped.length) {
    structuralWarnings.push({
      code: 'UNMAPPED_COLUMNS',
      message: `${unmapped.length} column(s) were not mapped and will be quarantined (data is not discarded from the file review).`,
      columns: unmapped,
      severity: unmapped.length >= 3 ? 'warn' : 'info',
    });
  }
  for (let i = 0; i < headers.length; i++) {
    if (detected[i] && confidences[i] != null && (confidences[i] as number) < 0.8 && (confidences[i] as number) >= 0.7) {
      structuralWarnings.push({
        code: 'AMBIGUOUS_MATCH',
        message: `Column "${headers[i]}" matched "${detected[i]}" with moderate confidence (${Math.round((confidences[i] as number) * 100)}%).`,
        columns: [headers[i]],
        severity: 'info',
      });
    }
  }

  // Quarantine entries are filled by callers that have row samples via quarantineUnmappedColumns()
  const quarantined: QuarantinedColumn[] = unmapped.map((h) => {
    const index = headers.indexOf(h);
    return {
      index: index < 0 ? -1 : index,
      header: h,
      sampleValues: [],
      suggestedField: suggestions[h] || 'ignore',
    };
  });

  return {
    headers,
    detected,
    confidences,
    methods,
    unmapped,
    missingRequired,
    suggestions,
    structuralWarnings,
    quarantined,
  };
}

export function resolveColumnIndex(
  headerRow: string[],
  field: CanonicalField,
  stored: ColumnMapDict = getStoredColumnMaps()
): number {
  if (field === 'ignore') return -1;

  let bestIdx = -1;
  let bestConf = 0;

  for (let i = 0; i < headerRow.length; i++) {
    const hit = detectFieldWithConfidence(headerRow[i], stored);
    if (hit && hit.field === field && hit.confidence > bestConf) {
      bestConf = hit.confidence;
      bestIdx = i;
    }
  }
  return bestIdx;
}


/**
 * Resolve all canonical columns as one assignment problem. This prevents two
 * fields from silently selecting the same header and provides a deterministic
 * fallback for ERP exports with drifting names.
 */
export function resolveDynamicColumnMap(
  headerRow: string[],
  stored: ColumnMapDict = getStoredColumnMaps()
): Partial<Record<Exclude<CanonicalField, 'ignore'>, number>> {
  const fields: Exclude<CanonicalField, 'ignore'>[] = ['branch', 'weight', 'design', 'category', 'sold', 'stock'];
  const candidates = fields.flatMap(field => headerRow.map((header, index) => {
    const hit = detectFieldWithConfidence(header, stored);
    return hit?.field === field ? { field, index, confidence: hit.confidence } : null;
  }).filter(Boolean) as { field: Exclude<CanonicalField, 'ignore'>; index: number; confidence: number }[]);

  const result: Partial<Record<Exclude<CanonicalField, 'ignore'>, number>> = {};
  const used = new Set<number>();
  // Highest-confidence matches win first; ties use the canonical field order.
  candidates.sort((a, b) => b.confidence - a.confidence || fields.indexOf(a.field) - fields.indexOf(b.field));
  for (const candidate of candidates) {
    if (used.has(candidate.index) || result[candidate.field] !== undefined) continue;
    result[candidate.field] = candidate.index;
    used.add(candidate.index);
  }

  // Conservative legacy fallback only when the header is genuinely ambiguous.
  const firstUnused = (start: number) => {
    for (let i = start; i < headerRow.length; i += 1) if (!used.has(i)) return i;
    return -1;
  };
  if (result.branch === undefined && headerRow.length) { result.branch = firstUnused(0); if (result.branch !== -1) used.add(result.branch); }
  if (result.weight === undefined && headerRow.length) { result.weight = firstUnused(1); if (result.weight !== -1) used.add(result.weight); }
  return result;
}

export function extractHeaderRow(grid: any[][]): { headerRowIdx: number; headers: string[] } {
  if (!grid?.length) return { headerRowIdx: 0, headers: [] };
  let headerRowIdx = 0;
  for (let i = 0; i < Math.min(8, grid.length); i++) {
    const rowStr = (grid[i] || []).map((c: any) => String(c).toLowerCase()).join(' ');
    if (
      /branch|store|outlet|showroom|shop|weight|particular|sku|product|item|sold|stock|carat|design|category|qty|brnch/i.test(
        rowStr
      )
    ) {
      headerRowIdx = i;
      break;
    }
  }
  const headers = (grid[headerRowIdx] || []).map((c: any) => String(c ?? '').trim());
  return { headerRowIdx, headers };
}

/**
 * Open mapper only when intelligence truly fails on required fields
 * OR many columns remain unknown.
 */
export function needsColumnMapper(analysis: HeaderAnalysis): boolean {
  if (analysis.missingRequired.length > 0) return true;
  // lots of mystery columns
  if (analysis.unmapped.length >= 3) return true;
  return false;
}

/** Back-compat alias used by older UI */
export const CANONICAL_FIELDS_LEGACY_KEYWORDS = CANONICAL_FIELDS;


/**
 * Never-throw header analysis. On unexpected schema failure returns an empty
 * analysis with a SCHEMA_DRIFT warning so the UI can quarantine instead of crash.
 */
export function safeAnalyzeHeaders(rawHeaders: string[] | null | undefined): HeaderAnalysis {
  try {
    return analyzeHeaders(Array.isArray(rawHeaders) ? rawHeaders : []);
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    return {
      headers: Array.isArray(rawHeaders) ? rawHeaders.map((h) => String(h ?? '')) : [],
      detected: [],
      confidences: [],
      methods: [],
      unmapped: Array.isArray(rawHeaders) ? rawHeaders.map((h) => String(h ?? '')).filter(Boolean) : [],
      missingRequired: CANONICAL_FIELDS.filter((f) => f.required).map((f) => f.id),
      suggestions: {},
      structuralWarnings: [
        {
          code: 'SCHEMA_DRIFT',
          message: `Header analysis failed safely: ${message}`,
          severity: 'error',
        },
      ],
      quarantined: [],
    };
  }
}

/**
 * Attach sample cell values to quarantined columns for mapper / review UI.
 */
export function quarantineUnmappedColumns(
  analysis: HeaderAnalysis,
  dataRows: unknown[][],
  sampleLimit = 3,
): HeaderAnalysis {
  const quarantined: QuarantinedColumn[] = analysis.unmapped.map((header) => {
    const index = analysis.headers.findIndex((h) => h === header);
    const sampleValues: string[] = [];
    if (index >= 0 && Array.isArray(dataRows)) {
      for (const row of dataRows) {
        if (!row || sampleValues.length >= sampleLimit) break;
        const cell = row[index];
        if (cell == null || cell === '') continue;
        sampleValues.push(String(cell).slice(0, 80));
      }
    }
    return {
      index,
      header,
      sampleValues,
      suggestedField: analysis.suggestions[header] || 'ignore',
    };
  });
  return { ...analysis, quarantined };
}

/**
 * Safe dynamic map — never throws; returns partial map and lets caller fall back.
 */
export function safeResolveDynamicColumnMap(
  headerRow: string[],
  stored: ColumnMapDict = getStoredColumnMaps(),
): Partial<Record<Exclude<CanonicalField, 'ignore'>, number>> {
  try {
    return resolveDynamicColumnMap(headerRow, stored);
  } catch {
    return {};
  }
}
