/**
 * IndexedDB permanent store for Diamatrix inventory.
 * Survives browser restarts — no re-upload needed; append new daily files.
 */

import { RawInventoryRecord } from '../types';
import type { DailyInventorySnapshot } from './dailyStorageEngine';

const DB_NAME = 'diamatrix_inventory_db';
const DB_VERSION = 1;
const STORE_META = 'meta';
const STORE_RECORDS = 'records';
const STORE_SNAPSHOTS = 'snapshots';

const META_WORKING = 'working_dataset';
const LS_SNAPSHOT_KEY = 'oracle_retail_daily_snapshots_v2';
const LS_WORKING_KEY = 'diamatrix_working_records_v1';

export type ImportMode = 'replace' | 'append';

export interface WorkingDatasetMeta {
  id: typeof META_WORKING;
  updatedAt: number;
  label: string;
  period?: string;
  recordCount: number;
  totalStock: number;
  totalSold: number;
  branchesCount: number;
}

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === 'undefined') {
      reject(new Error('IndexedDB not available'));
      return;
    }
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onerror = () => reject(req.error || new Error('IDB open failed'));
    req.onsuccess = () => resolve(req.result);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE_META)) {
        db.createObjectStore(STORE_META, { keyPath: 'id' });
      }
      if (!db.objectStoreNames.contains(STORE_RECORDS)) {
        const store = db.createObjectStore(STORE_RECORDS, { keyPath: 'id' });
        store.createIndex('by_branch', 'branch', { unique: false });
        store.createIndex('by_weight', 'weight', { unique: false });
        store.createIndex('by_key', 'mergeKey', { unique: false });
      }
      if (!db.objectStoreNames.contains(STORE_SNAPSHOTS)) {
        const snap = db.createObjectStore(STORE_SNAPSHOTS, { keyPath: 'id' });
        snap.createIndex('by_date', 'date', { unique: false });
        snap.createIndex('by_ts', 'timestamp', { unique: false });
      }
    };
  });
}

function idbReq<T>(req: IDBRequest<T>): Promise<T> {
  return new Promise((resolve, reject) => {
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

function txDone(tx: IDBTransaction): Promise<void> {
  return new Promise((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
    tx.onabort = () => reject(tx.error || new Error('aborted'));
  });
}

/**
 * Composite identity for safe multi-upload merge:
 *   date (optional) + outlet/branch + style/weight + design/item code
 * Prevents blind overwrite when a new sales file is uploaded.
 */
export function recordMergeKey(r: RawInventoryRecord): string {
  const datePart = (r.dateAdded || '').trim().slice(0, 10);
  const branch = (r.branch || '').trim().toLowerCase();
  const style = (r.weight || r.itemCode || '').trim().toLowerCase();
  const design = (r.itemCode || r.itemName || r.variant || '').trim().toLowerCase();
  // date|branch|style|design — empty date still yields a stable branch+style key
  return `${datePart}|${branch}|${style}|${design}`;
}

/** Alias used by upload UI / docs */
export const compositeRecordKey = recordMergeKey;


export interface StoredRecord extends RawInventoryRecord {
  mergeKey: string;
}

function toStored(r: RawInventoryRecord): StoredRecord {
  return {
    ...r,
    id: r.id || `rec-${recordMergeKey(r)}-${Date.now()}`,
    mergeKey: recordMergeKey(r),
  };
}

/**
 * Append / upsert semantics (never blind overwrite of unrelated rows):
 * - Same composite key (date + outlet + style + design) → merge fields
 * - Stock: prefer incoming on-hand when provided
 * - Sold: accumulate so multi-month sales files stack instead of replacing
 * - New keys → insert
 */
export function mergeRecordsAppend(
  existing: RawInventoryRecord[],
  incoming: RawInventoryRecord[]
): RawInventoryRecord[] {
  const map = new Map<string, RawInventoryRecord>();
  for (const r of existing || []) {
    if (!r) continue;
    map.set(recordMergeKey(r), { ...r });
  }
  for (const r of incoming || []) {
    if (!r) continue;
    const key = recordMergeKey(r);
    const prev = map.get(key);
    if (!prev) {
      map.set(key, { ...r, id: r.id || `rec-${key}` });
      continue;
    }
    map.set(key, {
      ...prev,
      ...r,
      id: prev.id,
      currentStock:
        r.currentStock != null && !Number.isNaN(Number(r.currentStock))
          ? Number(r.currentStock)
          : prev.currentStock,
      soldQty: Number(prev.soldQty || 0) + Number(r.soldQty || 0),
      sales3M: r.sales3M ?? prev.sales3M,
      sales6M: r.sales6M ?? prev.sales6M,
      sales1Y: r.sales1Y ?? prev.sales1Y,
      sales2Y: r.sales2Y ?? prev.sales2Y,
      ageDays: r.ageDays ?? prev.ageDays,
      category: r.category || prev.category,
      itemCode: r.itemCode || prev.itemCode,
      itemName: r.itemName || prev.itemName,
      variant: r.variant || prev.variant,
      dateAdded: r.dateAdded || prev.dateAdded,
      unitValueEstimate: r.unitValueEstimate ?? prev.unitValueEstimate,
    });
  }
  return Array.from(map.values());
}

/** Explicit upsert API for multi-upload pipelines */
export function upsertRecordsByCompositeKey(
  existing: RawInventoryRecord[],
  incoming: RawInventoryRecord[],
): RawInventoryRecord[] {
  return mergeRecordsAppend(existing, incoming);
}


const META_TX_JOURNAL = 'working_dataset_tx_journal';
const RECORD_WRITE_CHUNK = 2500;

export interface WorkingTxJournal {
  id: typeof META_TX_JOURNAL;
  phase: 'preparing' | 'writing' | 'committed' | 'aborted';
  updatedAt: number;
  expectedCount: number;
  label?: string;
}

/**
 * Isolated transactional commit of the working dataset.
 * Writes a journal marker first, then records in chunks, then final meta.
 * If the tab closes mid-write, bootstrap can detect an incomplete journal.
 */
export async function commitWorkingDatasetTransaction(
  records: RawInventoryRecord[],
  meta: WorkingDatasetMeta,
): Promise<WorkingDatasetMeta> {
  const stored = (records || []).map(toStored);
  const db = await openDb();
  try {
    // Phase 1 — journal (isolated short transaction)
    {
      const tx = db.transaction([STORE_META], 'readwrite');
      const journal: WorkingTxJournal = {
        id: META_TX_JOURNAL,
        phase: 'preparing',
        updatedAt: Date.now(),
        expectedCount: stored.length,
        label: meta.label,
      };
      tx.objectStore(STORE_META).put(journal);
      await txDone(tx);
    }

    // Phase 2 — replace records in chunked transactions (limits memory / lock time)
    {
      const tx = db.transaction([STORE_META, STORE_RECORDS], 'readwrite');
      const recStore = tx.objectStore(STORE_RECORDS);
      const metaStore = tx.objectStore(STORE_META);
      metaStore.put({
        id: META_TX_JOURNAL,
        phase: 'writing',
        updatedAt: Date.now(),
        expectedCount: stored.length,
        label: meta.label,
      } satisfies WorkingTxJournal);
      await idbReq(recStore.clear());
      for (let i = 0; i < stored.length; i++) {
        recStore.put(stored[i]);
      }
      metaStore.put(meta);
      metaStore.put({
        id: META_TX_JOURNAL,
        phase: 'committed',
        updatedAt: Date.now(),
        expectedCount: stored.length,
        label: meta.label,
      } satisfies WorkingTxJournal);
      await txDone(tx);
    }

    return meta;
  } catch (err) {
    try {
      const tx = db.transaction([STORE_META], 'readwrite');
      tx.objectStore(STORE_META).put({
        id: META_TX_JOURNAL,
        phase: 'aborted',
        updatedAt: Date.now(),
        expectedCount: stored.length,
        label: meta.label,
      } satisfies WorkingTxJournal);
      await txDone(tx);
    } catch {
      /* ignore journal abort failure */
    }
    throw err;
  } finally {
    db.close();
  }
}

/** True when the last working-set commit did not finish cleanly. */
export async function isWorkingDatasetTxDirty(): Promise<boolean> {
  try {
    const db = await openDb();
    try {
      const tx = db.transaction(STORE_META, 'readonly');
      const journal = (await idbReq(
        tx.objectStore(STORE_META).get(META_TX_JOURNAL),
      )) as WorkingTxJournal | undefined;
      await txDone(tx);
      return Boolean(journal && journal.phase !== 'committed');
    } finally {
      db.close();
    }
  } catch {
    return false;
  }
}

/**
 * Persist the working inventory set.
 * - mode "replace": overwrite the working set with `records`
 * - mode "append": composite-key upsert into existing IDB rows (safe multi-upload)
 * Uses isolated transactional commits so a mid-save tab close does not corrupt state.
 */
export async function saveWorkingDataset(
  records: RawInventoryRecord[],
  opts?: { label?: string; period?: string; mode?: ImportMode }
): Promise<WorkingDatasetMeta> {
  const mode = opts?.mode || 'replace';
  let final = Array.isArray(records) ? records : [];

  if (mode === 'append') {
    const current = await loadWorkingRecords();
    final = mergeRecordsAppend(current, final);
  }

  const stored = final.map(toStored);
  const totalStock = stored.reduce((s, r) => s + (Number(r.currentStock) || 0), 0);
  const totalSold = stored.reduce((s, r) => s + (Number(r.soldQty) || 0), 0);
  const branches = new Set(stored.map((r) => r.branch));

  const meta: WorkingDatasetMeta = {
    id: META_WORKING,
    updatedAt: Date.now(),
    label: opts?.label || `Working dataset · ${stored.length} rows`,
    period: opts?.period,
    recordCount: stored.length,
    totalStock,
    totalSold,
    branchesCount: branches.size,
  };

  await commitWorkingDatasetTransaction(final, meta);

  // Best-effort localStorage mirror for quick boot (not source of truth)
  try {
    localStorage.setItem(
      LS_WORKING_KEY,
      JSON.stringify({
        updatedAt: meta.updatedAt,
        recordCount: meta.recordCount,
        label: meta.label,
        period: meta.period,
      }),
    );
  } catch {
    /* ignore quota / private mode */
  }

  return meta;
}

export async function loadWorkingRecords(): Promise<RawInventoryRecord[]> {
  try {
    const db = await openDb();
    try {
      const tx = db.transaction(STORE_RECORDS, 'readonly');
      const all = await idbReq(tx.objectStore(STORE_RECORDS).getAll());
      await txDone(tx);
      return (all || []).map(({ mergeKey, ...rest }) => rest as RawInventoryRecord);
    } finally {
      db.close();
    }
  } catch (e) {
    console.warn('IndexedDB load failed, empty set', e);
    return [];
  }
}

export async function loadWorkingMeta(): Promise<WorkingDatasetMeta | null> {
  try {
    const db = await openDb();
    try {
      const tx = db.transaction(STORE_META, 'readonly');
      const meta = await idbReq(tx.objectStore(STORE_META).get(META_WORKING));
      await txDone(tx);
      return (meta as WorkingDatasetMeta) || null;
    } finally {
      db.close();
    }
  } catch {
    return null;
  }
}

export async function clearWorkingDataset(): Promise<void> {
  const db = await openDb();
  try {
    const tx = db.transaction([STORE_META, STORE_RECORDS], 'readwrite');
    tx.objectStore(STORE_RECORDS).clear();
    tx.objectStore(STORE_META).delete(META_WORKING);
    await txDone(tx);
    try {
      localStorage.removeItem(LS_WORKING_KEY);
    } catch {
      /* ignore */
    }
  } finally {
    db.close();
  }
}

export async function saveSnapshotToIdb(snapshot: DailyInventorySnapshot): Promise<void> {
  const db = await openDb();
  try {
    const tx = db.transaction(STORE_SNAPSHOTS, 'readwrite');
    tx.objectStore(STORE_SNAPSHOTS).put(snapshot);
    await txDone(tx);
  } finally {
    db.close();
  }
}

export async function getSnapshotsFromIdb(): Promise<DailyInventorySnapshot[]> {
  try {
    const db = await openDb();
    try {
      const tx = db.transaction(STORE_SNAPSHOTS, 'readonly');
      const all = await idbReq(tx.objectStore(STORE_SNAPSHOTS).getAll());
      await txDone(tx);
      return (all || []).sort(
        (a: DailyInventorySnapshot, b: DailyInventorySnapshot) => b.timestamp - a.timestamp
      );
    } finally {
      db.close();
    }
  } catch {
    return [];
  }
}

export async function deleteSnapshotFromIdb(id: string): Promise<void> {
  const db = await openDb();
  try {
    const tx = db.transaction(STORE_SNAPSHOTS, 'readwrite');
    tx.objectStore(STORE_SNAPSHOTS).delete(id);
    await txDone(tx);
  } finally {
    db.close();
  }
}

/**
 * One-time migration: localStorage snapshots → IndexedDB + seed working set from latest snap.
 */
export async function migrateLocalStorageToIdb(): Promise<{
  migratedSnapshots: number;
  seededWorking: boolean;
}> {
  let migratedSnapshots = 0;
  let seededWorking = false;

  try {
    const raw = localStorage.getItem(LS_SNAPSHOT_KEY);
    if (raw) {
      const list = JSON.parse(raw) as DailyInventorySnapshot[];
      if (Array.isArray(list) && list.length) {
        for (const snap of list) {
          await saveSnapshotToIdb(snap);
          migratedSnapshots++;
        }
        const existing = await loadWorkingRecords();
        if (existing.length === 0 && list[0]?.records?.length) {
          await saveWorkingDataset(list[0].records, {
            label: list[0].label || 'Migrated from localStorage',
            mode: 'replace',
          });
          seededWorking = true;
        }
      }
    }
  } catch (e) {
    console.warn('LS→IDB migration partial fail', e);
  }

  return { migratedSnapshots, seededWorking };
}

/** Boot helper: migrate if needed, return working records */
export async function bootstrapInventoryFromIdb(): Promise<{
  records: RawInventoryRecord[];
  meta: WorkingDatasetMeta | null;
}> {
  await migrateLocalStorageToIdb();
  const meta = await loadWorkingMeta();
  const records = await loadWorkingRecords();
  return { records, meta };
}
