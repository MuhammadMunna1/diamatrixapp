import type { RedistributionReport } from '../types';
import {
  buildExecutionExcelWorkbook,
  exportExecutionExcelReport,
  exportExecutionPdfReport,
} from './styledReportExport';

export type ExecutionReportMode =
  | 'contribution'
  | 'baseline'
  | 'hybrid'
  | 'liquidity'
  | 'demand_backup'
  | 'coverage';

const modeLabel = (mode: ExecutionReportMode) =>
  mode === 'contribution' ? 'Contribution'
  : mode === 'baseline' ? '3-Month Baseline'
  : mode === 'hybrid' ? 'Hybrid'
  : mode === 'liquidity' ? 'Capital Liquidity'
  : mode === 'demand_backup' ? 'Demand-Backup & Safety'
  : 'Universal Coverage';

const safe = (value: unknown) => String(value ?? '').replace(/[\\/:*?"<>|]/g, '-').trim() || 'Report';

export function buildExecutionWorkbook(report: RedistributionReport, mode: ExecutionReportMode): Promise<ArrayBuffer> {
  return buildExecutionExcelWorkbook(report, mode);
}

export async function downloadExecutionWorkbook(report: RedistributionReport, mode: ExecutionReportMode) {
  await exportExecutionExcelReport(report, mode);
}

export async function downloadExecutionPdf(report: RedistributionReport, mode: ExecutionReportMode) {
  await exportExecutionPdfReport(report, mode);
}

/**
 * Creates the requested local folder structure. No cloud storage is used.
 * Browser security requires a user gesture for showDirectoryPicker().
 */
export async function saveExecutionReportsToFolder(
  reports: Record<ExecutionReportMode, RedistributionReport>
) {
  const picker = (window as Window & { showDirectoryPicker?: () => Promise<any> }).showDirectoryPicker;
  if (!picker) {
    throw new Error('Folder save is not supported by this browser. Use the individual Export Excel buttons.');
  }
  const root = await picker();
  const rootFolder = await root.getDirectoryHandle('Execution Report', { create: true });
  for (const mode of ['contribution', 'baseline', 'hybrid', 'liquidity', 'demand_backup', 'coverage'] as ExecutionReportMode[]) {
    const folder = await rootFolder.getDirectoryHandle(modeLabel(mode), { create: true });
    const handle = await folder.getFileHandle(`${safe(modeLabel(mode))}_Report.xlsx`, { create: true });
    const writable = await handle.createWritable();
    await writable.write(await buildExecutionWorkbook(reports[mode], mode));
    await writable.close();
  }
}
