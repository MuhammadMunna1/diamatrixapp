import { createFileRoute } from '@tanstack/react-router';
import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';

const MOCK_DIR = resolve(process.cwd(), 'mocks');
const ALLOWED_MOCK_FILES = new Set([
  'SAMPLE_STOCK_Category_Nosepin7Stone.xlsx',
  'SAMPLE_SOLD_Category_Nosepin7Stone.xlsx',
  'SAMPLE_STOCK_Style_NP7SD1.xlsx',
  'SAMPLE_SOLD_Style_NP7SD1.xlsx',
]);

export const Route = createFileRoute('/api/mocks/$filename')({
  server: {
    handlers: {
      GET: async ({ params }) => {
        const filename = params.filename;

        if (!ALLOWED_MOCK_FILES.has(filename)) {
          return new Response('Mock file not found', { status: 404 });
        }

        try {
          const bytes = await readFile(resolve(MOCK_DIR, filename));
          return new Response(bytes, {
            status: 200,
            headers: {
              'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
              'Content-Disposition': `attachment; filename="${filename}"`,
              'Cache-Control': 'no-store',
              'X-Content-Type-Options': 'nosniff',
            },
          });
        } catch {
          return new Response('Mock file not found', { status: 404 });
        }
      },
    },
  },
});
