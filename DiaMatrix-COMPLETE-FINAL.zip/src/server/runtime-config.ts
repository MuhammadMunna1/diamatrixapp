/**
 * Runtime configuration guard for DiaMatrix.
 *
 * This module is intentionally server-only. It does not expose secret values;
 * it only validates that a deployment is configured safely before auth/database
 * services are used.
 */
export type RuntimeSecurityMode = "development" | "preview" | "production";

function value(key: string): string | undefined {
  const raw = process.env[key];
  const trimmed = typeof raw === "string" ? raw.trim() : "";
  return trimmed || undefined;
}

export function runtimeSecurityMode(): RuntimeSecurityMode {
  if (value("DIAMATRIX_ENV") === "production") return "production";
  if (value("GROK_PROJECT_ID")) return "production";
  if (value("NODE_ENV") === "production" && value("VERCEL")) return "production";
  if (value("GROK_AUTH_ISSUER") || value("GROK_GATE_ORIGIN")) return "preview";
  return "development";
}

export function assertRuntimeConfiguration(): void {
  const mode = runtimeSecurityMode();
  const authEnabled = value("VITE_AUTH_ENABLED") !== "false";
  const databaseUrl = value("DATABASE_URL");
  const secret = value("BETTER_AUTH_SECRET");
  const authClientId = value("GROK_AUTH_CLIENT_ID");
  const authClientSecret = value("GROK_AUTH_CLIENT_SECRET");
  const authUrl = value("BETTER_AUTH_URL");

  if (!authEnabled && databaseUrl) {
    throw new Error(
      "Security configuration error: VITE_AUTH_ENABLED=false cannot be used with DATABASE_URL. Enable real authentication before connecting a shared database.",
    );
  }

  if (secret && secret.length < 32) {
    throw new Error(
      "Security configuration error: BETTER_AUTH_SECRET must contain at least 32 characters.",
    );
  }

  if (authClientId && !authClientSecret) {
    throw new Error(
      "Security configuration error: GROK_AUTH_CLIENT_ID is set but GROK_AUTH_CLIENT_SECRET is missing.",
    );
  }
  if (authClientSecret && !authClientId) {
    throw new Error(
      "Security configuration error: GROK_AUTH_CLIENT_SECRET is set but GROK_AUTH_CLIENT_ID is missing.",
    );
  }

  if (mode !== "production") return;

  const missing: string[] = [];
  if (!authEnabled) missing.push("VITE_AUTH_ENABLED=true");
  if (!secret) missing.push("BETTER_AUTH_SECRET");
  if (!databaseUrl) missing.push("DATABASE_URL");
  if (!authClientId) missing.push("GROK_AUTH_CLIENT_ID");
  if (!authClientSecret) missing.push("GROK_AUTH_CLIENT_SECRET");
  if (!authUrl) missing.push("BETTER_AUTH_URL");
  if (!value("GROK_PROJECT_ID")) missing.push("GROK_PROJECT_ID");

  if (missing.length) {
    throw new Error(
      `Production configuration is incomplete. Missing/invalid: ${missing.join(", ")}. No shared dev fallback is permitted in production.`,
    );
  }

  if (authUrl) {
    let parsed: URL;
    try {
      parsed = new URL(authUrl);
    } catch {
      throw new Error("Security configuration error: BETTER_AUTH_URL must be a valid absolute URL.");
    }
    if (parsed.protocol !== "https:") {
      throw new Error("Security configuration error: production BETTER_AUTH_URL must use HTTPS.");
    }
    if (["localhost", "127.0.0.1", "::1"].includes(parsed.hostname)) {
      throw new Error("Security configuration error: production BETTER_AUTH_URL cannot point to loopback.");
    }
  }
}
