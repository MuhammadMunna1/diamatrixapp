export function assertAppDataServerOnly(
  context = "app-data/client.server",
): void {
  if (typeof window !== "undefined") {
    throw new Error(
      `@shared/app-data/${context} is server-only. Call connector tools from a createServerFn handler (dynamic import of @shared/app-data/client.server), never from a React component, useEffect, or browser fetch. Types and login helpers are client-safe via @shared/app-data.`,
    );
  }
}

assertAppDataServerOnly("app-data/client.server");
