import assert from "node:assert/strict";
import { readdirSync } from "node:fs";
import { join } from "node:path";
import { test } from "node:test";
import { isMigrationFile, migrationName, pendingMigrations } from "./migration-plan.mjs";
import { projectRoot } from "./with-app-env.mjs";

const AUTH_MIGRATION = "0001_auth.sql";

test("_migrations keys on basename, not path", () => {
  assert.equal(migrationName("/server/migrations/0002_todos.sql"), "0002_todos.sql");
  assert.equal(migrationName("server/migrations/auth/0001_auth.sql"), "0001_auth.sql");
  assert.equal(migrationName("0001_auth.sql"), "0001_auth.sql");
});

test("a file already applied from another directory does not re-apply", () => {
  assert.deepEqual(pendingMigrations(["/server/migrations/0001_auth.sql"], ["0001_auth.sql"]), []);
});

test("pending migrations are returned in name order", () => {
  assert.deepEqual(
    pendingMigrations(
      ["/server/migrations/0003_c.sql", "/server/migrations/0001_a.sql", "/server/migrations/0002_b.sql"],
      ["0001_a.sql"],
    ),
    [
      { name: "0002_b.sql", path: "/server/migrations/0002_b.sql" },
      { name: "0003_c.sql", path: "/server/migrations/0003_c.sql" },
    ],
  );
});

test("non-.sql entries are dropped (readdir also yields the auth/ directory)", () => {
  assert.equal(isMigrationFile("auth"), false);
  assert.deepEqual(pendingMigrations(["auth", "README.md"], []), []);
});

test("auth schema remains outside the active migration glob", () => {
  const migrationsDir = join(projectRoot(), "server", "migrations");
  const activeEntries = readdirSync(migrationsDir);
  assert.ok(activeEntries.includes("auth"));
  assert.equal(activeEntries.includes(AUTH_MIGRATION), false);
  assert.deepEqual(pendingMigrations(activeEntries, []), []);
  assert.ok(readdirSync(join(migrationsDir, "auth")).includes(AUTH_MIGRATION));
});
