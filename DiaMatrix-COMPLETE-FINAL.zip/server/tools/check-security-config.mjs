#!/usr/bin/env node
/** Static/runtime environment security audit for DiaMatrix. */
import { existsSync, readFileSync } from "node:fs";

const errors = [];
const warnings = [];
const env = process.env;
const production = env.DIAMATRIX_ENV === "production" || Boolean(env.GROK_PROJECT_ID) || (env.NODE_ENV === "production" && env.VERCEL);

if (env.VITE_AUTH_ENABLED === "false" && env.DATABASE_URL?.trim()) {
  errors.push("VITE_AUTH_ENABLED=false with DATABASE_URL would expose a shared-user configuration.");
}

if (env.BETTER_AUTH_SECRET?.trim() && env.BETTER_AUTH_SECRET.trim().length < 32) {
  errors.push("BETTER_AUTH_SECRET must be at least 32 characters.");
}

if (env.GROK_AUTH_CLIENT_ID && !env.GROK_AUTH_CLIENT_SECRET) errors.push("GROK_AUTH_CLIENT_ID is set without GROK_AUTH_CLIENT_SECRET.");
if (env.GROK_AUTH_CLIENT_SECRET && !env.GROK_AUTH_CLIENT_ID) errors.push("GROK_AUTH_CLIENT_SECRET is set without GROK_AUTH_CLIENT_ID.");

if (production) {
  for (const key of ["BETTER_AUTH_SECRET", "DATABASE_URL", "GROK_PROJECT_ID", "GROK_AUTH_CLIENT_ID", "GROK_AUTH_CLIENT_SECRET", "BETTER_AUTH_URL"]) {
    if (!env[key]?.trim()) errors.push(`Production requires ${key}.`);
  }
  if (env.VITE_AUTH_ENABLED === "false") errors.push("Production authentication cannot be disabled.");
  if (env.BETTER_AUTH_URL) {
    try {
      const url = new URL(env.BETTER_AUTH_URL);
      if (url.protocol !== "https:") errors.push("Production BETTER_AUTH_URL must use HTTPS.");
      if (["localhost", "127.0.0.1", "::1"].includes(url.hostname)) errors.push("Production BETTER_AUTH_URL cannot be loopback.");
    } catch { errors.push("BETTER_AUTH_URL is not a valid absolute URL."); }
  }
} else {
  warnings.push("Non-production configuration: real production secrets are not required by this audit.");
}

for (const forbidden of [".env.local", ".env.production", "server/data/auth-users.json"]) {
  if (existsSync(forbidden)) errors.push(`Sensitive runtime file exists in the project tree: ${forbidden}`);
}

const gitignore = readFileSync(".gitignore", "utf8");
for (const rule of [".env", ".env.*", "server/data/auth-users.json"]) {
  if (!gitignore.includes(rule)) errors.push(`.gitignore is missing protection for ${rule}.`);
}

if (errors.length) {
  console.error("[security-check] FAILED");
  for (const error of errors) console.error(`- ${error}`);
  process.exit(1);
}

console.log("[security-check] PASS");
for (const warning of warnings) console.log(`[security-check] warning: ${warning}`);
