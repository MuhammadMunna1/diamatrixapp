#!/usr/bin/env node
/** Static architecture guard for DiaMatrix client/server boundaries. */
import { readdir, readFile } from "node:fs/promises";
import { join, relative, sep } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(fileURLToPath(new URL(".", import.meta.url)), "../..");
const src = join(root, "src");
const clientRoot = join(src, "client");
const forbiddenSpecifiers = [
  "@server/",
  "../../server/",
  "../server/",
  "@/server",
  "better-auth/api",
  "better-auth/tanstack-start",
  "node:crypto",
  "node:fs",
  "node:fs/promises",
  "pg",
  "@electric-sql/pglite",
];
const importPattern = /(?:from\s*["']([^"']+)["']|import\s*\(\s*["']([^"']+)["']\s*\))/g;

async function walk(dir) {
  const out = [];
  for (const entry of await readdir(dir, { withFileTypes: true })) {
    if (entry.name === "node_modules" || entry.name === ".git") continue;
    const path = join(dir, entry.name);
    if (entry.isDirectory()) out.push(...await walk(path));
    else if (/\.(ts|tsx|js|jsx)$/.test(entry.name)) out.push(path);
  }
  return out;
}

const errors = [];
for (const file of await walk(clientRoot)) {
  const text = await readFile(file, "utf8");
  // TanStack Start server routes live in the client route tree but their
  // `server.handlers` block is compiled for the server. Allow Node-only
  // filesystem imports in those explicit server-route modules.
  const isServerRoute = file.startsWith(join(clientRoot, "routes") + sep) && /server\s*:\s*\{/.test(text);
  for (const match of text.matchAll(importPattern)) {
    const spec = match[1] ?? match[2] ?? "";
    const blocked = forbiddenSpecifiers.find((token) => spec === token || spec.startsWith(token));
    if (isServerRoute && (spec === "node:fs" || spec === "node:fs/promises" || spec === "node:path")) continue;
    if (blocked) {
      errors.push(`${relative(root, file).split(sep).join("/")} imports forbidden server dependency: ${spec}`);
    }
  }
}

const requiredToolingPath = join(root, "server", "tools");
try {
  const entries = await readdir(requiredToolingPath);
  if (entries.length === 0) errors.push("server/tools exists but is empty.");
} catch {
  errors.push("Required tooling path is missing: server/tools");
}

const requiredPaths = [join(root, "mocks")];

const legacyPaths = [
  join(root, "scripts"),
  join(root, "public", "samples"),
  join(src, "lumina"),
  join(src, "components"),
  join(src, "routes"),
  join(src, "lib"),
  join(src, "router.tsx"),
  join(src, "routeTree.gen.ts"),
  join(src, "styles.css"),
  join(src, "print.css"),
  join(root, "migrations"),
];
for (const path of legacyPaths) {
  try {
    const entries = await readdir(path);
    if (entries.length > 0) errors.push(`Legacy boundary path still exists: ${relative(root, path).split(sep).join("/")}`);
  } catch {
    // Missing path is the desired state.
  }
}

if (errors.length) {
  console.error("[architecture] FAILED");
  for (const error of errors) console.error(` - ${error}`);
  process.exit(1);
}
console.log("[architecture] OK — client/server boundaries are clean.");
