/**
 * Compatibility re-export. The implementation is shared-safe and lives under
 * src/shared so browser code never imports build/test scripts.
 */
export * from "../../src/shared/auth/sign-out-plan.mjs";
