/**
 * Cloudflare Turnstile server-side verification.
 * Intercepts: POST /api/auth/turnstile/verify
 * Env: TURNSTILE_SECRET_KEY (falls back to Cloudflare always-pass test secret)
 *
 * Nitro auto-registers this file as global middleware (serverDir: "./server").
 * Must export a default middleware function.
 */
const SITEVERIFY = "https://challenges.cloudflare.com/turnstile/v0/siteverify";
const TEST_SECRET = "1x0000000000000000000000000000000AA";
const VERIFY_PATH = "/api/auth/turnstile/verify";

function getTurnstileSecret(): string {
  return (
    process.env.TURNSTILE_SECRET_KEY ||
    process.env.CF_TURNSTILE_SECRET_KEY ||
    TEST_SECRET
  );
}

async function verifyTurnstileWithCloudflare(
  token: string,
  remoteip?: string,
): Promise<{ success: boolean; error?: string; codes?: string[] }> {
  if (!token) return { success: false, error: "Missing Turnstile token" };
  const body = new URLSearchParams();
  body.set("secret", getTurnstileSecret());
  body.set("response", token);
  if (remoteip) body.set("remoteip", remoteip);
  try {
    const res = await fetch(SITEVERIFY, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body,
    });
    const data = (await res.json()) as {
      success?: boolean;
      "error-codes"?: string[];
    };
    if (data.success) return { success: true };
    return {
      success: false,
      error: "Cloudflare security check failed",
      codes: data["error-codes"],
    };
  } catch {
    return { success: false, error: "Could not reach Cloudflare siteverify" };
  }
}

interface TurnstileEvent {
  url: URL;
  req: { method: string; headers: Headers; json?: () => Promise<unknown> };
}

function clientIp(event: TurnstileEvent): string | undefined {
  const h = event.req.headers;
  return (
    h.get("cf-connecting-ip") ||
    h.get("x-forwarded-for")?.split(",")[0]?.trim() ||
    undefined
  );
}

async function readToken(event: TurnstileEvent): Promise<string> {
  try {
    // Nitro / h3 may expose body via req.json()
    if (typeof event.req.json === "function") {
      const data = (await event.req.json()) as Record<string, unknown>;
      return String(
        data?.token || data?.["cf-turnstile-response"] || data?.turnstileToken || "",
      );
    }
  } catch {
    /* ignore */
  }
  return "";
}

/**
 * Nitro middleware: handle Turnstile verify endpoint; otherwise pass through.
 */
export default async function turnstileVerifyMiddleware(
  event: TurnstileEvent,
  next: () => unknown | Promise<unknown>,
): Promise<unknown> {
  const path = event.url.pathname;
  if (path !== VERIFY_PATH) {
    return next();
  }

  if (event.req.method !== "POST") {
    return new Response(JSON.stringify({ success: false, error: "Method not allowed" }), {
      status: 405,
      headers: { "content-type": "application/json" },
    });
  }

  try {
    const token = await readToken(event);
    const result = await verifyTurnstileWithCloudflare(token, clientIp(event));
    return new Response(
      JSON.stringify(
        result.success
          ? { success: true }
          : { success: false, error: result.error, codes: result.codes },
      ),
      {
        status: result.success ? 200 : 403,
        headers: { "content-type": "application/json" },
      },
    );
  } catch (e: unknown) {
    const message = e instanceof Error ? e.message : "Verify failed";
    return new Response(JSON.stringify({ success: false, error: message }), {
      status: 500,
      headers: { "content-type": "application/json" },
    });
  }
}
