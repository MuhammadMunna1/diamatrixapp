/**
 * Baseline HTTP security headers for every deployed DiaMatrix response.
 *
 * Deliberately avoids a static CSP and X-Frame-Options because DiaMatrix may be
 * embedded by the authenticated preview host. Origin isolation for scripted
 * requests is enforced separately by src/server/auth/isolation.server.ts.
 */
interface SecurityEvent {
  url: URL;
  req: { headers: Headers };
}

function isHttps(event: SecurityEvent): boolean {
  const forwarded = event.req.headers.get("x-forwarded-proto");
  return (forwarded ?? event.url.protocol.replace(":", "")).split(",")[0].trim() === "https";
}

export default async function securityMiddleware(
  event: SecurityEvent,
  next: () => unknown | Promise<unknown>,
): Promise<unknown> {
  const result = await next();
  if (!(result instanceof Response)) return result;

  const headers = new Headers(result.headers);
  headers.set("x-content-type-options", "nosniff");
  headers.set("referrer-policy", "strict-origin-when-cross-origin");
  headers.set("permissions-policy", "camera=(), microphone=(), geolocation=(), usb=()");
  headers.set("x-xss-protection", "0");

  if (isHttps(event)) {
    headers.set("strict-transport-security", "max-age=31536000; includeSubDomains");
  }

  const pathname = event.url.pathname;
  if (pathname === "/api/auth" || pathname.startsWith("/api/auth/")) {
    headers.set("cache-control", "no-store, max-age=0");
    headers.set("pragma", "no-cache");
  }

  return new Response(result.body, {
    status: result.status,
    statusText: result.statusText,
    headers,
  });
}
