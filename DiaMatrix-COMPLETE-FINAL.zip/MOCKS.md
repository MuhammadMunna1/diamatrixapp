# Root-level mock workbooks

Repository-only Excel fixtures live under `/mocks`, not under the Vite public directory.

- Vite does not treat `/mocks` as a static public directory, so these `.xlsx` files are not copied into the production asset tree.
- The TanStack Start server route `/api/mocks/$filename` reads an allow-listed workbook from `/mocks` and streams it to the browser.
- `parseMockInventoryData()` in `src/client/lumina/utils/universalParser.ts` uses that route and then delegates to the same `parseUniversalInventoryData()` / `parseExcelBuffer()` pipeline used for uploaded files.
- Only the four checked-in sample workbook names are exposed by the server route.
